# MSX BASIC + Z80 IDE

![MSX BASIC + Z80 IDE — Basic Dignified, Assembly, integrado](msxbasica.png)

![Editor com destaque de sintaxe para o dialeto Basic Dignified](images/msxbasica-01.png)

**Versão atual: 7.33.1** ("`PENTE FINO`") — versão e build (data/hora UTC de compilação, em hexadecimal)
são embutidas no executável pelo `build.ps1` e exibidas em `Ajuda → Sobre...`.

IDE nativa em **PureBasic** para desenvolvimento em MSX BASIC (dialeto "Dignified", sem números de
linha) e Z80 assembly, construída em torno de um editor com highlighting via Scintilla e um
pré-processador/tokenizador reescritos nativamente — sem depender de Python instalado na máquina do
usuário final.

> Documento vivo. O detalhe completo da especificação (escopo, decisões de arquitetura, módulos
> planejados) está em [`docs/SPEC.md`](docs/SPEC.md) — é a fonte de verdade do projeto. Para
> compilar, executar e usar o editor de texto (atalhos de teclado, busca/substituir), veja
> [`docs/MANUAL.md`](docs/MANUAL.md).

## Sobre o projeto

O ponto de partida foi um editor de texto simples para MSX BASIC. A ideia é fazer ele crescer até
virar uma IDE completa cobrindo todo o fluxo de desenvolvimento para MSX: BASIC + assembly Z80 +
assets gráficos/sonoros + build + debug direto no emulador, tudo num único executável PureBasic
autocontido (Windows/Linux), sem exigir Python nem outras dependências externas em tempo de execução.

O dialeto de entrada é o **Basic Dignified** (labels em vez de números de linha, includes, macros,
proto-funções, etc.), inspirado e compatível com o [Basic Dignified Suite](#agradecimentos) original em
Python — que serve de referência de comportamento a ser portada, não de dependência de runtime.

## O que já temos

- **Editor** (`editor/BadigEditor.pb`) — `ScintillaGadget` com lexer próprio para o dialeto Dignified
  e outro para **Z80 Assembly** (`.asm`, dialeto do assembler
  [N80/Nestor80](https://github.com/Konamiman/Nestor80)), abas customizadas (fechar, hover, arrastar
  visual), régua de colunas, margem de números de linha dinâmica, **4 temas claros** (`Configurar →
  Editor...` — os 5 temas escuros foram removidos na 7.33.10, ver [Changelog](#changelog-resumido)) e
  estilo de abas moderno/clássico configuráveis. Teclado padrão Scintilla/Windows (sem
  modo próprio, ver [Changelog](#changelog-resumido) 2026-08-08) — Buscar/Substituir/Ir para linha
  (`Ctrl+F`/`H`/`G`) e mais de 30 atalhos cobrindo o resto da IDE, ver `docs/MANUAL.md`. Menu
  **Arquivo → Novo** (`.dmx`) e **Novo Assembly** (`.asm`, `Ctrl+Shift+N`) — cada aba detecta e lembra
  seu próprio tipo.

  ![Aba de Assembly Z80 com syntax highlight (mnemônicos, registradores, diretivas, rótulos)](images/msxbasica-02.png)
- **Botões tematizados em toda a IDE, com ícones Nerd Font por padrão** (`editor/ThemedButtons.pbi`) —
  botão nativo do Windows (`ButtonGadget`) ignora completamente a cor do tema; os 311 botões da IDE
  (todas as telas de Configurar, editores visuais, gerenciador de disco, console do openMSX, telas de
  Ajuda) são desenhados na hora seguindo o tema escolhido, e mais de 140 trocam o texto por um ícone
  real de uma Nerd Font — a partir da 7.33.10, uma fonte de ícones vem empacotada com o executável
  (`editor/fonts/`) e é usada automaticamente, sem precisar configurar nada (`Configurar → Editor...
  → Fonte de ícones` deixa desligar ou trocar por outra), com tooltip mostrando o nome ao passar o
  mouse.
- **Pré-processador Dignified nativo** (`editor/DignifiedPreprocessor.pbi`) — **cobre 100% do escopo
  do `badig.py` original**: labels, loop labels, `EXIT`, `DEFINE` recursivo, `DECLARE` com redução
  automática de nomes longos, comentários/blocos de comentário, `TRUE`/`FALSE`, operadores compostos,
  proto-funções `FUNC`/`RET`, conversão `?`/`PRINT`, strip `THEN`/`GOTO`, tradução Unicode→charset
  nativo MSX, maiusculização, tamanho de TAB configurável, **`INCLUDE` recursivo** (namespace de
  label/loop/função isolado por arquivo, variáveis compartilhadas) e **remtags**
  (`##BB:arguments=`/`export_file=`/`help=`). Testado de ponta a ponta contra código de produção real
  (não só exemplos sintéticos — ver [`sample/teste.dmx`](sample/teste.dmx), ~900 linhas) e contra
  fixtures de `INCLUDE`/remtags. O `.exe` do editor não depende mais de Python em nenhum fluxo (menus
  legados removidos).
- **Tokenizador MSX-BASIC nativo** (`editor/MsxTokenizer.pbi`) — converte ASCII clássico em binário
  `.bmx`, validado byte a byte contra o tokenizador Python original.
- **Rodar no openMSX** (`RunOnOpenMSX()` em `editor/BadigEditor.pb`) — com a opção "Abrir o openMSX e
  rodar o código após gerar" marcada, tokenizar monta um disquete `.dsk` (`.dmx`+`.amx`+`.bmx` mais um
  `AUTOEXEC.BAS` de autorun) e abre o openMSX já rodando o programa, com a máquina/extensão
  configuradas. **Reaproveita a instância já aberta** em vez de lançar uma nova a cada execução
  (`OMSX_LoadDisk()`, `editor/OpenMSXBridge.pbi`) — igual F5 duas vezes seguidas troca só o disco e
  reinicia, sem abrir uma segunda janela. Rotinas de disco `.dsk` (FAT12) próprias em
  `editor/MSXDisk.pbi` (originalmente vendorizadas do projeto separado `msxDiskUtil`, depois
  incorporadas de vez e o diretório `msxDiskUtil/` removido do repositório — sem dependência externa
  nenhuma) — compiladas direto no executável do editor, sem depender de processo externo para montar
  o disco.
- **Painel de controle remoto do openMSX** (`Executar → openMSX...`, `editor/OpenMSXConsoleGui.pbi` +
  `editor/OpenMSXBridge.pbi`) — 6 abas cobrindo praticamente tudo que o Catapult original oferecia:
  **Console** (mídia, transferir programa, log, comando livre), **Outros comandos** (velocidade com
  Turbo segurando o mouse, Power/Reset/Pause, firmware, portas de joystick, Ren Sha Turbo), **Vídeo**
  (renderer, escala, Modo TV com as 5 opções reais do openMSX, efeitos estilo CRT com reset pro
  padrão, screenshot com numeração sequencial, LEDs visuais + STOP + FPS), **Volume** (mixer com
  **descoberta dinâmica** de dispositivo de som — os nomes reais variam por cartucho/ROM conectado,
  não são fixos —, Volume/Balance, MIDI in/out), **Input Text** (área grande + Type/Clear) e
  **Status Info** (log passivo de tudo que o openMSX reporta). Ver
  [`docs/RELEASE_NOTES.md`](docs/RELEASE_NOTES.md) pro detalhe completo desta leva de features.
- **Telas de configuração nativas**:
  - `Configurar → Basic Dignified...` (`editor/BadigSettings.pbi`) — três abas: pré-processador/
    tokenizador, opções específicas do MSX, e **Emulador** (caminho do openMSX, máquina/extensão com
    botão de busca automática em `share/machines`/`share/extensions`, opção de rodar após gerar).
    Diretório de instalação do toolchain com botão para baixar o Basic Dignified Suite direto do
    GitHub (`git clone` ou `.zip`), tudo persistido em JSON.
  - `Configurar → openMSX...` (`editor/OpenMsxSettingsGui.pbi`) — os mesmos campos da aba "Emulador"
    acima, numa tela própria — lê/grava exatamente o mesmo `BadigCfg`/`badig_settings.json`, então as
    duas telas nunca divergem.
  - `Configurar → Editor...` (`editor/EditorSettings.pbi`) — fonte (só monoespaçadas, com suporte a
    pasta de fontes customizadas carregadas em memória), tema, estilo de abas, caminho de instalação do
    editor.
  - `Configurar → Basic Options...` (`editor/BasicOptionsSettings.pbi`) e `Configurar → Assembly...`
    (`editor/AssemblyOptionsSettings.pbi`) — liga/desliga o auto completar (ver item abaixo), quantidade
    de letras pra ativar e caixa das sugestões, uma tela por modo (BASIC/Dignified e Assembly guardam
    preferência independente).
- **Auto completar** — sugere, conforme você digita, palavras-chave do MSX-BASIC/Basic Dignified
  (incluindo os 87 wrappers `.NB_*` do NestorBASIC) e variáveis já usadas no documento em abas
  `.dmx`/`.bas`; mnemônicos/registradores/diretivas do Z80 e rótulos já definidos no documento em abas
  `.asm`. Navegação 100% nativa do Scintilla (Enter aceita, setas navegam, Esc cancela, digitar mais
  estreita a lista sozinho) — nenhuma tecla nova pra aprender. Caixa das sugestões configurável
  (maiúsculas/minúsculas/"como digitado") separadamente para BASIC e Assembly; variáveis/rótulos/
  `.NB_*` sempre mantêm a grafia original do documento. Ver [`docs/MANUAL.md`](docs/MANUAL.md#auto-completar).
- **CLI de teste de regressão** (`editor/tools/DigTestCli.pb`) — roda o pipeline completo
  (Dignified → ASCII → tokenizado) fora do editor, para validar mudanças no pré-processador/tokenizador.
- **Gerenciador de disco MSX** — `editor/MSXDisk.pbi` (FAT12, incorporado de vez ao editor — o
  diretório separado `msxDiskUtil/` que serviu de origem foi removido do repositório, 2026-07-28)
  agora também é exposto de duas formas prontas para uso, além de montar o disco de "rodar no
  openMSX":
  - **CLI embutida** (`BadigEditor.exe --diskmanipulator <create|list|add|extract|delete> disco.dsk
    ...`) — mesma sintaxe do `msxdisk.exe` original, roda e sai sem abrir janela nenhuma.
  - **Menu Criar → Disco...** (`editor/DiskManagerGui.pbi`) — gerenciador gráfico com dois painéis
    (estilo Norton/Total Commander): esquerda é o sistema de arquivos local, direita é o conteúdo do
    disco. Botões **Adicionar >>**/**<< Extrair** sempre copiam (nunca apagam a origem); **Remover
    local**/**Remover disco** excluem de verdade, com confirmação. Todas as operações acontecem numa
    cópia de rascunho temporária — o `.dsk` escolhido só é gravado de fato em **Salvar**/**Salvar
    como...**/**Duplicar...**; **Cancelar** descarta a sessão sem tocar nele.

  ![Gerenciador gráfico de disco MSX (Criar → Disco...) com painel local à esquerda e disco à direita](images/msxbasica-03.png)
- **Sistema de projeto** (`editor/ProjectDB.pbi`) — um projeto MSX inteiro (por enquanto, Sprites; os
  demais tipos de conteúdo ganham tabela quando tiverem editor próprio) vive num único arquivo SQLite
  (`.msxproject`). Ao abrir sem nenhum parâmetro de linha de comando, a IDE já cria/usa de cara um
  projeto implícito **"noname.msxproject"** num arquivo temporário — tudo que for registrado vai
  sendo gravado nele sem precisar criar um projeto antes. **Arquivo → Novo projeto...** troca para um
  projeto novo e vazio num local escolhido (oferece salvar o atual primeiro, se tiver conteúdo não
  salvo); **Arquivo → Abrir projeto...** abre um `.msxproject` já existente. **Arquivo → Salvar
  projeto**/**Salvar projeto como...** salvam o projeto atual (o primeiro reaproveita o caminho já
  escolhido, sem diálogo; o segundo sempre pergunta um caminho novo, permitindo salvar uma cópia com
  outro nome) — extensão `.msxproject` é acrescentada automaticamente se não digitada. Ao sair, se o
  projeto implícito tiver conteúdo registrado e ainda não tiver sido salvo num arquivo permanente, a
  IDE pergunta se quer salvar (e onde, com nome definitivo) antes de fechar. O projeto também guarda
  uma cópia sempre atualizada do conteúdo de cada aba de texto já salva em disco e o diretório de
  trabalho (pasta do último arquivo salvo, ou o diretório corrente enquanto nada foi salvo ainda).
  **Arquivo → Salvar Tudo** (`Ctrl+Alt+S`) salva todas as abas abertas (uma por uma, na ordem, pedindo
  "Salvar como..." pras que ainda não têm nome) e o projeto atual numa ação só.
- **Editor de sprites** (`editor/SpriteEditorGui.pbi`, menu **Criar → Sprite...**) — grade clicável
  8×8 ou 16×16 com a **palheta original de 16 cores do MSX1** (TMS9918), e radios **MSX1** (sprite
  inteiro com uma única cor) / **MSX2** (uma cor por linha, aplicada automaticamente conforme o
  sprite é pintado). Ferramentas com ícone próprio: lápis, borracha, pincel (bloco 2×2), balde de
  preenchimento, reta, retângulo e elipse/círculo (vazios ou cheios) — as ferramentas de dois pontos
  mostram prévia ao vivo da forma e um marcador piscando no primeiro ponto, com **Esc** ou o botão
  direito do mouse cancelando sem traçar nada. Botões de rotacionar (com quebra nas bordas) e
  deslocar (sem quebra) nas quatro direções, inverter e limpar. Cada sprite é numerado, tem uma tag
  (nome curto, até 16 caracteres) e fica gravado no projeto atual via o botão **Registrar**; **Novo**
  cria o próximo sprite em sequência, os botões de navegação vão para o primeiro/anterior/próximo/
  último sprite já registrado, e **Copiar**/**Colar** duplicam um sprite para outro número.

  ![Editor de sprites (Criar → Sprite...) com grade 16×16, paleta MSX1, barra de projeto (número, navegação, tag) e prévia em escala reduzida](images/msxbasica-04.png)
- **Editor de alfabetos** (`editor/CharsetEditorGui.pbi`, menu **Criar → Alfabeto...**) — edita charsets
  no formato **`.ALF` do Graphos III**: 256 caracteres de 8×8 pixels (2048 bytes), binário MSX clássico
  com cabeçalho de 7 bytes (tipo `&HFE`, endereços inicial/final/execução — carregado originalmente em
  `&H9200`, a Pattern Generator Table da VRAM). Tabela com os 256 caracteres (16 por linha, cabeçalho
  hex de linha/coluna, miniatura de cada glifo) — clicar num caractere carrega seus pixels numa grade
  8×8 bem ampliada, onde dá pra ligar/apagar cada pixel (clique ou arrastar); **Registrar** grava os
  pixels editados de volta no caractere selecionado e atualiza a miniatura na tabela. **Carregar do
  Graphos III...**/**Salvar como...** leem e gravam `.alf` (extensão acrescentada automaticamente se não
  digitada) — carregar sempre importa como um alfabeto novo (nunca sobrescreve um já registrado).
  **Copiar**/**Colar** de um caractere isolado, de um **alfabeto inteiro** (Copiar alfabeto/Colar
  alfabeto) ou de um **intervalo marcado** (Marcar início/Marcar fim de bloco + Copiar bloco/Colar
  bloco) — todos com área de transferência da própria sessão. Com um intervalo marcado, o botão
  **Inverter** passa a inverter todos os caracteres do intervalo de uma vez direto no alfabeto (sem
  bloco marcado, afeta só o caractere atual) — combinado com Copiar/Colar bloco, permite duplicar um
  conjunto de caracteres (ex.: A..Z para a..z) e inverter só a cópia, tendo as duas versões lado a lado.
  Todos os botões de ação são **ícones monocromáticos** desenhados em memória (sem arquivo externo),
  com dica ao passar o mouse explicando cada função. Também integrado ao **sistema de projeto**, igual
  ao editor de sprites: um projeto pode ter vários alfabetos, com barra própria de número/tag/
  **Primeiro**/**Anterior**/**Próximo**/**Último**/**Registrar alfabeto**/**Novo alfabeto** (numera
  automaticamente e sempre parte do charset padrão do MSX, nunca em branco). Esse charset padrão vem de
  um **"projeto 0"** interno (`ProjectDB::EnsureDefaultsOpen()`) — um banco SQLite à parte, sempre em
  memória, nunca salvo, semeado com `alfabetos\msx.alf` **embutido no próprio `.exe`**
  (`editor/DefaultCharsetMsx.pbi`). Ganhou **11 botões de efeito** (todos com **Desfazer**/**Refazer**
  próprios, pilha de até 50 níveis): **All** (marca o alfabeto inteiro como bloco de uma vez),
  **Espelhar horizontal/vertical**, **Girar 90°**, **Apagar**, **Estreitar** (condensa o glifo em 3
  colunas, útil pra caber 64 colunas de texto onde só caberiam 32), **Itálico** (desloca linhas
  progressivamente), **Negrito**, **Largo** (+ variantes **Bold esquerda/direita** e **Largo bold**,
  que combinam alargar com engrossar) — todos seguindo o mesmo padrão dual já usado pelo Inverter: sem
  bloco marcado afetam só o caractere atual (precisa de "Registrar"), com bloco/All aplicam direto em
  todo o intervalo.

  ![Editor de alfabetos (Criar → Alfabeto...) com tabela de 256 caracteres, grade de edição ampliada e botões-ícone](images/msxbasica-05.png)
- **Editor de alfabetos Aquarela** (`editor/AquarelaCharsetEditorGui.pbi`, menu **Criar → Alfabeto
  Aquarela...**) — edita o formato `.FNT` do **Aquarela**, outro editor de fonte MSX (alternativa ao
  Graphos III acima), com engenharia reversa completa documentada em `docs/reference/aquarela.md`.
  Diferente do editor Graphos III, é uma ferramenta **autocontida baseada em arquivo** (Novo/Abrir/
  Salvar/Salvar como), sem integração com o sistema de projeto. Glifo real **16×16** (2 planos de 16
  bytes — coluna esquerda e direita —, cada registro de 32 bytes começando 7 bytes depois do início
  nominal, confirmado pixel a pixel contra o Aquarela rodando de verdade num emulador). **46
  caracteres editáveis** (grade de 8 colunas × 6 linhas): `A-Z`, `&`, `?`, `!`, `"`, `0-9`, `.`, `:`,
  `-`, `(`, `)`, `,` — ordem confirmada por teste real do usuário. Salva sempre no formato de 2304
  bytes (72 registros), preenchendo o restante com o byte de posição-vazia padrão. Botões de ícone
  **Registrar**/**Limpar**/**Inverter**/**Copiar**/**Colar**, mesmo estilo visual do editor Graphos
  III.
- **Editor de som PSG** (`editor/PsgSynth.pbi` + `editor/PsgEditorGui.pbi`, menu **Criar → Som
  (PSG)...**) — editor de efeitos sonoros para o chip de som do MSX (AY-3-8910/YM2149), espelhando
  registrador por registrador o comando `SOUND` do MSX-BASIC. Painel com os 3 canais **A/B/C**
  (frequência em Hz, volume 0-15, "usar envelope", liga/desliga tom e ruído no mixer), **ruído**
  (período compartilhado) e **envelope** (período + as 10 formas de hardware nomeadas). Um "som" é um
  **mini-sequenciador de passos** — cada passo guarda os 14 registradores + uma duração em quadros,
  permitindo desenhar efeitos que variam ao longo do tempo (tiro, explosão etc.), com botões
  **Adicionar/Atualizar/Remover/Mover/Duplicar passo**. **Tocar**/**Parar** sintetizam a sequência
  inteira em PCM (motor próprio por acumulador de fase — osciladores de tom, LFSR de ruído de 17 bits,
  gerador de envelope, tabela de volume logarítmica de 16 níveis) e tocam via `.wav` temporário, sem
  depender de nenhuma biblioteca externa. **Gerar código BASIC** produz `SOUND n,valor` prontos
  (só os registradores que mudaram a cada passo) e **Gerar bytes crus** produz um bloco `DATA` para uma
  futura rotina Z80; **Injetar no cursor**/**Copiar** colocam o código gerado direto na aba de texto
  ativa ou na área de transferência. Integrado ao sistema de projeto, mesma barra de número/tag/
  navegação/Registrar/Novo dos editores de sprite e alfabeto.

  ![Editor de som PSG (Criar → Som (PSG)...) com os 3 canais, ruído/envelope compartilhados, lista de passos e código BASIC gerado](images/msxbasica-06.png)
- **Editor SEE Tracker** (`editor/SeeTrackerEditorGui.pbi` + `editor/SeeTrackerSynth.pbi` +
  `editor/SeeTrackerDriverAsm.pbi`, menu **Criar → SEE Tracker...**) — tracker de efeitos sonoros
  **compatível com o formato `.SEE`** (Sound Effect Editor, Fuzzy Logic 1991/95 — ver **Ajuda → SEE
  Tracker...** para o manual original e o formato de arquivo). Diferente do editor de Som (PSG) acima,
  um efeito aqui é uma sequência de **patterns com comandos de controle** (`HALT`/`FOR`/`NEXT`/`START`/
  `RERUN`/`TMP`/`END`, os mesmos do formato original) — grade clicável (uma linha por pattern) com
  painel de edição completo (evento, frequência/rustle/volume dos 3 canais com slides de afinação,
  envelope de hardware) ao lado. **Tocar**/**Parar** interpretam a sequência quadro a quadro (inclusive
  loops) e sintetizam via o mesmo motor do editor PSG. **Gerar código** monta um **driver de replay Z80
  nativo** (porta de `see/SEE3PLAY.ASC`, corrigida e montada em tempo real pelo assembler Z80 desta IDE)
  junto com o blob binário `.SEE` do efeito atual, prontos como `DATA`/`POKE`/`DEFUSR` para tocar via
  NestorBASIC. **Importar .SEE...** lê um arquivo `.SEE` real gerado pelo editor original (útil pra
  recuperar efeitos de projetos antigos) — lista todos os SFX definidos nele (um arquivo pode ter vários)
  e importa os patterns do escolhido pro SFX atual, andando sequencialmente até o evento `END`. Um
  **cursor de playback** (borda verde na grade) mostra em tempo real qual pattern está soando, com
  auto-scroll se ele sair da área visível. A **forma do envelope** de hardware do PSG (reg. 13) tem um
  preview ao vivo e um seletor visual com as **16 curvas reais do chip** — clicar numa já escolhe, sem
  precisar decorar o número de cada forma. **Limpar**/**Limpar linha**/**Limpar bloco** zeram todos os
  patterns, um só ou um intervalo, sem precisar apagar e reinserir linha por linha. Integrado ao sistema
  de projeto, mesmo padrão de número/tag/navegação/Registrar/Novo dos demais editores.

  ![Editor SEE Tracker (Criar → SEE Tracker...) com um efeito de 8 patterns tocando — cursor de playback verde no pattern 0, botões Limpar/Limpar linha/Limpar bloco e o seletor visual de forma do envelope à direita](images/msxbasica-16.png)
- **Editor de música MML** (`editor/MmlSynth.pbi` + `editor/MmlEditorGui.pbi`, menu **Criar → Música
  (PLAY)...**) — editor de MML (Music Macro Language) para o comando `PLAY` do MSX-BASIC, cobrindo os
  3 canais **A/B/C em paralelo**. Cada canal tem uma "linha atual" editável que os botões vão
  preenchendo — notas **A-G** (sustenido/bemol, duração, pontos de aumento), **pausa (R)**, **nota
  absoluta por número (N)**, **oitava (O, 1-8, com `>`/`<`)**, **duração padrão (L)**, **andamento
  (T)**, **volume (V)** e o **modulador/padrão de envelope (M/S)** — mesmo hardware de envelope
  compartilhado do editor de som. **Inserir nova linha** fecha a linha atual como uma entrada na lista
  do canal (mesmo espírito "sequenciador" do editor de som); **Atualizar**/**Remover**/**Mover** editam
  as linhas já inseridas. **Tocar**/**Parar** sintetizam os 3 canais juntos — o motor reaproveita quase
  integralmente o `PsgSynth.pbi` do editor de som (mesmo chip, mesmo gerador de envelope compartilhado),
  só parseando o MML e mesclando cronologicamente os 3 canais num único fluxo de registradores.
  **Gerar código PLAY** monta o `PLAY "...","...","..."` final (concatenação literal do que foi
  montado); **Injetar no cursor**/**Copiar** colocam o código na aba ativa ou na área de transferência.
  Integrado ao sistema de projeto, mesma barra de número/tag/navegação/Registrar/Novo dos demais
  editores — os botões de ícone (**Novo**/**Registrar**) são os mesmos desenhos já usados no editor de
  sprites, reaproveitados para ficar visualmente uniforme em toda a IDE.

  ![Editor de música MML (Criar → Música (PLAY)...) com os 3 canais em paralelo, lista de linhas por canal e código PLAY gerado](images/msxbasica-07.png)
- **Editor de DRAW Screen 2** (`editor/Screen2Synth.pbi` + `editor/Screen2EditorGui.pbi`, menu **Criar
  → Draw Screen 2...**) — editor gráfico WYSIWYG para o modo **SCREEN 2** (TMS9918 Graphics II,
  256×192), com simulação **fiel ao hardware** do color clash (1 par tinta/fundo por faixa de 8×1
  pixels — pintar 2 cores na mesma faixa faz a faixa inteira "puxar" pra última cor gravada, igual ao
  MSX de verdade, sem lógica de detecção extra: o motor só reproduz o mesmo comportamento da ROM).
  Sete abas de ferramenta — **PSET**/**PRESET** (clique no canvas já liga/apaga o pixel na cor
  selecionada), **LINE** (reta/caixa/caixa cheia, dois cliques: ponto inicial e final, com **linha
  elástica** acompanhando o mouse antes do segundo clique), **CIRCLE** (círculo ou elipse, primeiro
  ponto centro/canto, segundo raio/canto oposto, também com previa elástica), **PAINT** (preenchimento
  por vizinhança), **DRAW** (interpretador completo da mini-linguagem de tartaruga do MSX-BASIC —
  `U D L R E F G H`, `B`/`N`, `M`, `C`, `S`, `A`/`TA`, com rotação exata em passos de 90° e
  arredondamento correto pra ângulos livres) e **TEXTO** (escreve usando um alfabeto do banco do
  projeto — ver editor de alfabetos acima — com um **quadro elástico arrastável** que mostra o texto de
  verdade nas cores escolhidas seguindo o mouse: move de 8 em 8 pixels por padrão para encaixar no grid
  de tiles, ou pixel a pixel segurando **Ctrl**; clique fixa o texto, botão direito cancela). Suporta os
  parâmetros **STEP** (coordenadas relativas ao cursor gráfico, como no MSX-BASIC real) em todos os
  comandos que aceitam, e `LINE -(x,y)` (sem ponto inicial, usa o cursor gráfico como ponto de partida).
  Cada ferramenta com clique-para-adicionar tem seu **mini buffer** próprio (lista filtrada + botão
  Remover, some do canvas junto). Paleta MSX1 completa (16 cores fixas) para Tinta/Fundo. **Gerar
  código** produz `PSET`/`PRESET`/`LINE`/`CIRCLE`/`PAINT`/`DRAW` prontos (mais o carregador `DATA`+
  `VPOKE` do alfabeto e `LOCATE`/`PRINT` para texto alinhado ao grid de 8px — texto posicionado livre
  por pixel vira uma sequência de `PSET`/`PRESET`, já que `LOCATE` só aceita célula de caractere
  inteira); **Injetar no cursor**/**Copiar** como nos demais editores. Integrado ao sistema de projeto
  (tabela `screens`, mesma barra de número/tag/navegação/Registrar/Novo/Copiar/Colar dos outros
  editores) — guarda a **lista de comandos**, não o framebuffer, para poder reordenar/editar depois de
  recarregar.

  ![Editor de DRAW Screen 2 (Criar → Draw Screen 2...) com formas desenhadas, lista de comandos e código BASIC gerado](images/msxbasica-10.png)
- **Graphos III — edição de telas SCREEN 2** (`editor/GraphosScreenGui.pbi`, menu **Criar → Graphos III
  Screen 2...**) — réplica do editor de vídeo clássico do MSX **Graphos III** (Renato Degiovani, 1987;
  manual completo lido de `graphos/graphos.txt`). Cada função do Graphos III original vira uma opção
  **separada** dentro de "Criar" (o editor de alfabetos do Graphos III já existe, ver **Alfabeto Graphos
  III...** acima) e os antigos menus por tecla de função (F1-F5: DESENHO/TEXTO/TELA/AJUSTE/MISCELANEA)
  viram botões/ícones, no mesmo espírito do editor de sprites. **Fase 1** (esta versão): canvas 256×192
  com **color clash idêntico ao MSX de verdade** (reaproveita 100% do motor já validado do editor "Draw
  Screen 2...", `Screen2Synth.pbi` — zero lógica de clash nova), paleta INK/PAPER, **TRAÇO** (Lápis/
  Borracha com arrastar contínuo, alternância mutuamente exclusiva) e **LIMPA TELA**. Resto do menu
  DESENHO (BLOCO/LINHA/RETÂNGULO/RAIO/CÍRCULO/PINTURA/SPRAY/FILL), TEXTO, AJUSTE, MISCELÂNEA (ZOOM/
  SHAPE/CORTE/GRID), shapes e os formatos de arquivo nativos (`.SCR`/`.LAY`/`.VTC`+`.ATC`) ficam para
  os próximos cortes.

  ![Editor Graphos III (Criar → Graphos III Screen 2...) replicando o editor de vídeo clássico do MSX](images/msxbasica-11.png)
- **Assembler Z80 nativo** (`editor/Z80Asm.pbi`, menu **Executar → Montar Assembly (.bin)...**,
  `Ctrl+F5`) — compatível com **M80/L80** (Microsoft MACRO-80/LINK-80), especificação de comportamento
  portada do [**Nestor80**](https://github.com/Konamiman/Nestor80) (assembler C# moderno 100%
  compatível M80/L80). Avaliador de expressão (RPN, precedência idêntica ao Nestor80/M80 —
  `HIGH`/`LOW`/`NOT`/relacionais), tabela de opcodes Z80 completa (documentados + `IXH`/`IXL`/`IYH`/
  `IYL` indocumentados comuns), driver de 2 passes, diretivas de dados (`DB`/`DW`/`DS`/`DC`/`DZ`),
  condicionais (`IF`/`IFDEF`/`IF1`/`IF2`/etc.) e macros básicas (`MACRO`/`ENDM`/`EXITM`/`LOCAL`).
  Validado **byte a byte** contra o próprio `N80.exe` (compilado localmente como oráculo de teste) —
  `sample/teste_opcodes.asm` e `sample/teste2_macros.asm` são a suíte de regressão oficial. Além da
  saída absoluta (`.bin`, **Executar → Montar Assembly (.bin)...**), o motor gera saída **relocável
  `.REL`** de verdade (`ASEG`/`CSEG`/`DSEG`/`COMMON`/`PUBLIC`/`EXTRN`, formato estendido Nestor80,
  validado byte a byte contra o `N80.exe`), agora exposta no editor via **Executar → Montar Assembly
  relocável (.REL)...**. **Linker** (`editor/Z80Link.pbi`, Linkstor80-equivalente — linka múltiplos
  `.REL` e resolve `.REQUEST`/biblioteca com linkagem estática seletiva) e **gerenciador de biblioteca**
  (`editor/Z80Lib.pbi`, Libstor80-equivalente — `create`/`add`/`list`/`remove`), ambos validados byte a
  byte contra `LK80.exe`/`LB80.exe` reais, têm janela própria no editor: **Executar → Linkar (.REL) →
  binário...** (`editor/Z80LinkGui.pbi`) e **Criar → Biblioteca Z80 (.LIB)...** (`editor/Z80LibGui.pbi`).
  A saída (montagem absoluta ou link) passa por um escolhedor comum (`editor/Z80OutputGui.pbi`): `.bin`
  solto no PC (com ou sem cabeçalho MSX BLOAD), **`.COM` (MSX-DOS)** pronto pra rodar **independente do
  MSX-BASIC** (binário cru sem cabeçalho, avisa se o fonte não foi montado pra `0100h`), **disco MSX
  (`.dsk`)** pronto pra rodar via `AUTOEXEC.BAS` (`BLOAD"...",R`, reaproveitando `MSXDisk.pbi`) ou
  **listing BASIC** (`FOR`/`READ`/`POKE` + `DATA` em hexa, mesmo espírito do "Gerar bytes crus" do
  editor de som PSG). Uma nova tabela
  `asm_builds` no sistema de projeto (`ProjectDB.pbi`) guarda o metadado da última exportação de
  binário/disco por origem (caminho do `.asm` ou, numa sessão de link, a lista de `.rel` escolhida).
  **Assembly Sub Project** (**Criar → Assembly Sub Project...**, `editor/Z80SubProject.pbi` motor +
  `editor/Z80SubProjectGui.pbi` janela) — um "Makefile primitivo": lista ordenada de `.asm` (cada um
  vira `.REL` na hora do build) mais bibliotecas referenciadas via `.REQUEST`, botão **Montar tudo
  (Build)...** monta tudo de uma vez e manda pro mesmo escolhedor de saída; botão **Gerar biblioteca a
  partir dos .ASM selecionados...** empacota um subconjunto numa `.LIB`/`.REL` e oferece adicioná-la de
  volta à lista. Registrado no `.msxproject` (tabela `asm_subprojects`), mesma barra de projeto
  (número/tag/navegação/Novo/Registrar) dos demais editores. Detalhe completo do processo de
  implementação em [`docs/resumo-asm.md`](docs/resumo-asm.md).

  ![Assembler Z80 nativo (Executar → Montar Assembly), compatível M80/L80](images/msxbasica-12.png)
- **Sistema de Ajuda MSX BASIC** (`editor/MsxBasicHelpGui.pbi`, menu **Ajuda → MSX BASIC...**) — janela
  de referência não-modal (fica aberta enquanto o usuário continua editando), com árvore navegável,
  busca por nome/palavra e histórico (**Alt+seta-esquerda**/botão "Voltar" desempilha um tópico). Duas
  fontes de dados combinadas numa única lista achatada: **MSX1** — dicionário completo das 141
  palavras reservadas do livro *"Linguagem BASIC MSX"* (Denise Santoro Cruz, Editora Aleph/Gradiente,
  1986) em `editor/MsxBasicDictData.pbi`, mais os tópicos de prosa/tabelas (Parte I, Parte III,
  Apêndices) em `editor/MsxBasicManualData.pbi`; **MSX 2+** — 45 verbetes adicionais (comandos novos do
  cartucho ACVS FM, ex. `COLOR=`, `COLORSPRITE`, `SETPAGE`, `CALL MEMINI`, `CALL MUSIC`/`CALL VOICE` etc.,
  mais um segundo verbete `"NOME (MSX2+)"` para comandos do MSX1 com comportamento estendido, ex.
  `SCREEN`/`COLOR`/`CIRCLE`/`PLAY`) em `editor/MsxBasic2PlusDictData.pbi`, mais 7 tópicos de prosa/
  apêndices (apresentação, sintaxe, FM-Music, Apêndices A-D) do *"Manual MSX 2+ FM"* (Ademir
  Carchano/Flávio Monaco, ACVS Eletrônica) em `editor/MsxBasic2PlusManualData.pbi`, digitalizado em
  `docs/manual_msx2fm_acvs.pdf`. Cada verbete guarda a página do livro/manual de origem; mais uma página
  especial "Cores do MSX" com as 16 cores do VDP renderizadas como faixas coloridas.
- **Suporte a NestorBASIC** (`editor/NestorBasicSupport.pbi` + `editor/NestorBasicHelpData.pbi`/
  `NestorBasicHelpGui.pbi`) — integração com o **NestorBASIC 1.11** (Nestor Soriano/Konami Man): rotinas
  em código de máquina carregadas uma vez via `BLOAD"NBASIC.BIN",R` que dão acesso a memória mapeada,
  VRAM, disco, compressão gráfica, execução de programas/código em RAM, efeitos PSG e tocador
  Moonblaster, tudo através de um único `USR(numero)` e dos arrays `P()`/`F$()`.
  - **Arquivo → Novo Nestor Basic...** cria uma aba nova de Basic Dignified já com o loader (rótulos
    `{NBasicLoad}`/`{VoltaNBasicLoad}`, escrito com `GOTO` puro — achado do usuário: `BLOAD"...",R` mexe
    na pilha do BASIC, então um `GOSUB`/`RETURN` ao redor dessa chamada específica quebra) e a biblioteca
    inteira de wrappers `.NB_*` colada direto no texto (sem `INCLUDE`, já que uma aba nova ainda sem
    salvar não tem de onde puxar um arquivo externo): 87 funções (0-86) cobrindo as três "tiers" do
    manual original — geral/RAM/VRAM/disco (Tier 1, com `func`/`ret`), compressão gráfica/execução de
    programas/código diverso/PSG/Moonblaster (Tier 2) e controle de segmentos/integração com
    NestorMan/InterNestor Suite/Lite (Tier 3). Convenção: cada `.NB_*` devolve só o(s) valor(es)
    principal(is) da chamada com o código de erro por último (`.NB_ErrorText` traduz o código); os
    demais resultados documentados no manual continuam disponíveis em `p()`/`f$()` logo após a chamada.
  - **Executar → Nestor Basic** — idêntico a **Executar → BASIC**, mas também copia `NBASIC.BIN`/
    `NBASIC.DAT` (de `res/`) para o disco `.dsk` gerado antes de abrir o openMSX, já que o programa
    precisa desses arquivos presentes no disco em tempo de execução.
  - **Ajuda → Nestor Basic...** — janela de referência não-modal (mesma UI de árvore + busca + histórico
    do sistema de Ajuda acima) com as 87 funções mais introdução, mostrando pra cada uma o wrapper
    `.NB_*` e um exemplo de chamada já pronto antes do resto do corpo. Fonte única de dados também usada
    para gerar `docs/reference/nestorbasic.md` (exportação Markdown a partir da mesma base).

  ![Suporte a NestorBASIC: template gerado por Arquivo → Novo Nestor Basic... ao lado da janela Ajuda → Nestor Basic...](images/msxbasica-13.png)
- **Ajuda MSX BASIC do Basic Dignified** (`editor/BasicDignifiedHelpData.pbi`/`BasicDignifiedHelpGui.pbi`,
  menu **Ajuda → Basic Dignified...**) — mesma janela de referência não-modal (árvore + busca +
  histórico) compilada a partir da documentação oficial do Basic Dignified Suite original
  (`basic-dignified/documentation/*.md`, baixável pelo botão **Baixar Basic Dignified Suite...** da
  tela de configuração), cruzada com o código real desta IDE. Cobre dois assuntos: a **sintaxe** do
  dialeto Dignified (labels/loop labels, defines, variáveis de nome longo/`DECLARE`, proto-funções
  `FUNC`/`RET`, separação de linhas `:`/`_`, comentários e toggles, tradução Unicode, `INCLUDE`,
  `TRUE`/`FALSE`, operadores compostos) e as **configurações** de `Configurar → Basic Dignified...`
  campo a campo — inclusive dizendo explicitamente quais campos têm efeito real no pipeline nativo
  (`Dig_SyncConfigFromBadigCfg()`) e quais existem só por compatibilidade com o `.ini` original sem
  nenhum consumidor hoje (relatórios da aba Basic Dignified, opções do tokenizador na aba MSX,
  `EmSetting`/`EmMonitor`/`EmNoThrottle`/`EmVerbose` na aba Emulador). Mais dois grupos: **remtags**
  (`##BB:arguments=`/`export_file=`/`help=`, com a lista exata de flags que o remtag `arguments=`
  realmente aplica) e **sobre a suíte original** (ferramentas não portadas pra esta IDE, como o
  DignifieR de conversão reversa, e referência do formato tokenizado `.bmx`).
- **Ajuda SEE Tracker** (`editor/SeeTrackerHelpData.pbi`/`SeeTrackerHelpGui.pbi`, menu **Ajuda → SEE
  Tracker...**) — mesma janela de referência não-modal, desta vez sobre o **SEE** (Sound Effect
  Editor, Fuzzy Logic 1991/95), um editor shareware de efeitos sonoros PSG pra MSX que gera arquivos
  `.SEE`/`.SFX` tocados via um pequeno driver Z80 (mesmo estilo de integração `BLOAD`+`DEFUSR`/`USR()`
  já usado pelo NestorBASIC desta IDE). Cobre o manual original (telas, menus, teclas, os 11 canais de
  um pattern, comandos do canal `event`), o **formato binário `.SEE`** campo a campo e o **mecanismo
  real do driver de replay** (`see/SEE3PLAY.ASC`, lido linha a linha) — inclusive achados que só
  aparecem lendo o driver, não o manual, como o fato de `FOR`/`START` dispararem só uma vez (nunca
  reprocessados nas repetições de um loop) e a fórmula exata de escala por `Max Volume`. Preparação
  para um **tracker de SFX nativo compatível** a construir numa sessão futura — por ora é só estudo,
  nenhum editor/gerador `.SEE` existe ainda nesta IDE.
- **Editor Hexa** (`editor/HexEditorGui.pbi`, menu **Executar → Editor Hexa...**) — editor
  hexadecimal genérico: abre **qualquer arquivo** do disco (não só os do editor de texto), mostra
  offset/hex/ASCII numa grade rolável e permite editar bytes individuais (clique seleciona, campo +
  **Aplicar** grava). **Reconhece automaticamente, sem nenhuma configuração**:
  - **Formatos nativos desta IDE**: binário MSX BLOAD/BSAVE (cabeçalho `FEh` + início/fim/execução),
    MSX-BASIC tokenizado (`FFh`), boot sector FAT12 de imagem `.dsk` (mesmos offsets que `MSXDisk.pbi`
    lê/escreve), texto ASCII puro vs. BASIC MSX clássico numerado (mesma regra de entrada do
    tokenizador).
  - **Executável MSX-DOS** (`.COM`) — código Z80 cru sem cabeçalho, convenção CP/M, carrega/executa
    sempre em `0100h`.
  - **Planilha SuperCalc 2 MSX** (`.CAL`) — assinatura, título e início da seção de dados (ver
    `docs/reference/supercalc2-cal-format.md`).
  - **Banco de dados dBase II** (`.DBF`) — cabeçalho, descritores de campo (nome/tipo/tamanho) e onde os
    registros começam (ver `docs/reference/dbase2-dbf-format.md`).
  - **Os 4 formatos nativos do Graphos III**: **Alfabeto `.ALF`** (256 caracteres × 8 bytes), **Layout
    `.LAY`** (decodifica o RLE+ofuscação de verdade e confere os 6144 bytes), **Tela `.SCR`** (padrão +
    cor de SCREEN 2 completa) e **Banco de shapes `.SHP`** (percorre a cadeia de blocos até o
    terminador `FFh` — o único dos quatro sem cabeçalho BLOAD/BSAVE).

  Além do reconhecimento automático, uma **galeria de templates** (`hexeditor_templates.json`, mesmo
  estilo de persistência de `editor_settings.json`/`badig_settings.json`) deixa o usuário cadastrar
  binários BLOAD/BSAVE próprios (byte de tipo + endereço inicial + tamanho dos dados) pra dar nome
  amigável a qualquer outro formato. Operações de bloco a partir de um intervalo marcado (**Marcar
  início**/**Marcar fim**/**Limpar seleção**) ou, se nada estiver marcado, perguntando endereço
  inicial/final na hora: **Preencher...** (um valor num intervalo), **Inserir bloco...** (desloca o
  resto do arquivo pra frente) e **Sobrepor bloco...** (não desloca), ambos trazendo os bytes de outro
  arquivo inteiro ou gerando bytes em branco (quantidade + valor), e **Excluir bloco...** (desloca de
  verdade, encolhendo o arquivo, ou só sobrescreve com `00` no lugar). Barra de rolagem vertical
  customizada (setas topo/base tradicionais + barra visual com a posição proporcional no arquivo,
  desenhada à mão porque o `ScrollBarGadget` nativo do PureBasic renderizava enorme e com os botões
  trocados nesta configuração) mais rolagem pela roda do mouse.

  ![Editor Hexa (Executar → Editor Hexa...) reconhecendo um alfabeto Graphos III via galeria de templates](images/msxbasica-14.png)
- **Inserir → Caractere Especial...** (`editor/CharMapGui.pbi`, novo menu de topo **Inserir**) — mapa
  de caracteres estilo Windows (`charmap.exe`) com os **159 caracteres** que a opção `-tr` traduz pra
  ASCII nativo MSX (acentos/gregas/gráficos + carinhas/naipes/linhas tipo CP437): grade 16×10 clicável
  com prévia ampliada e código MSX/Unicode do caractere selecionado, campo acumulador (até 80
  caracteres, botões Adicionar/Remover último/Limpar) e botão **Inserir** que copia o texto acumulado
  na posição do cursor da aba ativa. Motivou a correção de dois bugs reais de tradução em
  `DignifiedPreprocessor.pbi` que já afetavam `-tr` antes desta feature existir — ver Changelog e
  `docs/SPEC.md`, módulo 3h.
- **Família de editores de tela de texto MSX** (`Criar → Screen 0.../Screen 1.../Screen 1+2...`), no
  espírito dos clássicos editores de tela ANSI da era BBS (TheDraw/AcidDraw/DarkDraw), mas fiéis ao
  hardware MSX real — cada um cobre um modo de cor de texto diferente, do mais simples ao mais
  complexo: **SCREEN 0** (1 cor pra tela inteira), **SCREEN 0 no modo MSX2+** (80 colunas com uma
  segunda cor real de texto), **SCREEN 1** (1 cor por grupo de 8 caracteres) e **SCREEN 1+2** (SCREEN 2
  de verdade — 3 alfabetos e cor por linha de scanline). Os quatro compartilham a mesma grade fixa de
  32×24 (ou 40/80×24 no SCREEN 0) e a maioria das 6 ferramentas por aba (Texto/Caractere/Quadro/Sombra/
  Bloco/Borracha) — só o modelo de cor e a renderização mudam entre eles.
  - **Screen 0...** (`editor/Screen0EditorGui.pbi`) — grade fixa de **40 ou 80 colunas × 24 linhas**
    (largura escolhida ao criar cada tela) com **uma única cor de tinta/fundo pra tela inteira**
    (equivalente a `COLOR fg,bg` — SCREEN 0 de verdade não tem cor por célula, diferente de um editor
    ANSI de PC), usando a fonte padrão do MSX ou uma fonte customizada já cadastrada no banco de
    alfabetos do projeto (**Criar → Alfabeto Graphos III...**). Ferramentas: **Texto** (digita e clica
    pra posicionar horizontalmente), **Caractere** (grade com os 159 caracteres especiais de
    `Inserir → Caractere Especial...` — clique/arraste estampa), **Quadro** (2 cliques desenham uma
    moldura com linhas simples, unindo automaticamente em T/cruz onde encostar num quadro já
    existente), **Sombra** (2 cliques estampam uma faixa `▒` deslocada, no estilo clássico de sombra de
    editor ANSI), **Bloco** (2 cliques preenchem um retângulo com o caractere atual) e **Borracha**.
    **Gerar código**/**Injetar no cursor**/**Copiar** emitem `SCREEN 0`/`WIDTH`/`COLOR`/`LOCATE`+`PRINT`
    com os glifos Unicode literais — a tradução `-tr` do próprio pipeline Dignified resolve pro byte/
    escape nativo MSX na hora de tokenizar, sem o editor precisar calcular nenhum endereço de VRAM pro
    texto em si (só o carregador de fonte customizada, que usa o endereço real da Pattern Generator
    Table do SCREEN 0 — `&H0800` em 40 colunas, `&H1000` em 80). **Em telas de 80 colunas (modo MSX2+),
    uma sétima ferramenta ("Atributo") liga o recurso real de segunda cor** (modo T2 do VDP): cada
    caractere pode usar um segundo par de tinta/fundo (paletas "Cor 2" próprias), piscando com a cor
    normal num ritmo configurável (0-15, ~1/6s por fase, até 2.5s) ou **travado permanentemente na Cor
    2** (zerando a duração "normal") — dando, na prática, texto com 2 cores fixas em 80 colunas, algo
    que 40 colunas não tem. Gera `VDP(13)`/`VDP(14)` (cor 2 e duração) mais o carregador da tabela de
    "pisca" (1 bit/caractere, `&H0800` nesse modo) junto do resto do código.
  - **Screen 1...** (`editor/Screen1EditorGui.pbi`) — mesma grade fixa **32×24** e as mesmas 6
    ferramentas do SCREEN 0 acima, mas com a diferença real de cor do hardware SCREEN 1: em vez de 1 cor
    pra tela inteira, uma **Color Table** de 32 entradas dá 1 par tinta/fundo por **grupo de 8 códigos de
    caractere** (endereço padrão `&H2000`). A **tabela ASCII do alfabeto** (grade de 256 células) mostra
    o bitmap real de cada código já pintado na cor do seu octeto — clicar escolhe o "byte atual" e as
    paletas Tinta/Fundo do octeto colorem os 8 códigos daquele grupo, refletido ao vivo na tabela e no
    canvas.
  - **Screen 1+2...** (`editor/Screen12EditorGui.pbi`) — terceira e mais complexa da família: gera
    **SCREEN 2** de verdade (não um editor gráfico de pixels como o **Draw Screen 2...** já existente),
    com os dois recursos extras do hardware que o SCREEN 1 não tem — **3 alfabetos**, um por "terço" de
    8 linhas de tela (Pattern `Terço×2048`/Color `&H2000+Terço×2048`), e **cor por LINHA DE SCANLINE de
    cada código de caractere** (8 cores por glifo, o "color clash" real do SCREEN 2 — toda ocorrência do
    mesmo código no mesmo terço usa a mesma cor por linha, não importa onde apareça na tela). A tabela
    ASCII mostra 1 terço por vez (seletor acima da grade que **acompanha sozinho** qualquer clique/
    arraste no canvas, e uma linha-guia preto+branco no canvas marca visualmente onde cada terço começa/
    termina). **Cores do caractere...**/**Cores em bloco...** abrem um editor ampliado por linha de
    scanline (o de bloco escolhido por 2 cliques direto na tabela ASCII, com marca ciano sutil);
    **Copiar/Colar cores** e **Resetar caractere/bloco/todos** (fundo preto/letra branca) completam o
    fluxo. Todos os editores da família são integrados ao sistema de projeto, mesma barra de número/tag/
    navegação/Novo/Registrar dos demais editores.

    ![Editor de tela Screen 1+2 (Criar → Screen 1+2...) mostrando cores diferentes por terço — carinhas amarelas no Terço 1, azuis no Terço 2, texto vermelho no Terço 3](images/msxbasica-15.png)

Ainda não implementado (ver [Lacunas conhecidas](docs/SPEC.md#lacunas-conhecidas-a-preencher-em-conversas-futuras)
e [Próximos passos](docs/SPEC.md#próximos-passos-em-aberto) em `docs/SPEC.md`): `--code`/`--data`/
`--align-*`/detecção de sobreposição de segmento/saída Intel HEX no linker, editor de tile (além do
charset/fonte 8×8), tracker, saída via `msxbas2rom`, input simulado durante a execução e detecção de
erro com retorno à linha no editor (ver "Controle remoto do openMSX" logo abaixo para o que já existe
nessa frente).

**Controle remoto do openMSX — validado e ampliado (2026-07-30)**: menu **Executar → openMSX...**
(`editor/OpenMSXBridge.pbi`/`OpenMSXConsoleGui.pbi`) abre uma instância separada do openMSX com um
named pipe de comando (mesmo mecanismo do Catapult oficial no Windows) e dá uma janela de console para
controlar essa instância manualmente — não mexe no fluxo normal de **Executar → BASIC** (são
instâncias/processos openMSX totalmente separados; a instância aberta por "Executar → BASIC" com o
programa do usuário não fica sob controle desse console a menos que o console seja aberto a partir
dela — ver lacuna registrada abaixo). Validado ao vivo contra um openMSX 21.0 real
(`editor/tools/OpenMsxBridgeTestCli.pb`, harness de linha de comando novo nesta sessão).

A janela ganhou, na mesma sessão de validação:
- **Indicador de estado** ("Ligado/Desligado | Rodando/Pausado") no topo, alimentado por
  `openmsx_update enable setting` (assinado no boot) — reflete o estado real mesmo se ele mudar por um
  caminho que não um comando mandado por esta janela.
- **Área de colar/digitar texto** + botão **"Inserir no openMSX"**, que digita o conteúdo no MSX como
  se fosse teclado de verdade (quebras de linha viram Enter) — mesmo mecanismo do Catapult
  (`InputPage.cpp`/`OnTypeText()`): comando `type -- <texto escapado>`, delegando pro `type_via_keyboard`
  nativo do openMSX.
- Correção de um bug real de exibição: o log da janela fazia release/gravação completa do texto
  (`GetGadgetText`/`SetGadgetText`) a cada 150ms e, depois de alguns comandos, "esvaziava" sozinho
  mesmo com o openMSX respondendo normalmente por baixo — trocado por um acumulador só do nosso lado,
  nunca relido do widget.
- Correção de um bug real de protocolo (achado ao implementar o "Inserir no openMSX", mas que já
  afetava qualquer comando digitado manualmente): comandos não eram escapados como XML antes de
  `<command>...</command>` — um `<`/`&` cru (comum em BASIC: `IF X<10`, `A&B`) quebrava o comando
  silenciosamente no parser real do openMSX, sem erro nenhum. Corrigido com escape XML, igual ao
  Catapult de verdade.

Detalhes técnicos completos (arquitetura, tentativas anteriores, e as pegadinhas reais encontradas
durante a validação) em `docs/SPEC.md`, módulo 12. **O que ainda falta nessa frente** está listado em
`docs/SPEC.md` → [Próximos passos](docs/SPEC.md#próximos-passos-em-aberto).

## Changelog resumido

- **2026-07-13** — Projeto criado; editor base migrado para repositório git com `badig/` como
  submódulo. Pré-processador Dignified e tokenizador MSX-BASIC nativos escritos em PureBasic
  (`DignifiedPreprocessor.pbi`, `MsxTokenizer.pbi`), incluindo proto-funções `FUNC`/`RET`. Primeira
  tela de configuração nativa (`BadigSettings.pbi`). Documentação de referência completa extraída do
  código-fonte Python original em `docs/reference/`.
- **2026-07-14** — Corrigido bug de charset que truncava a saída `.bmx` com caracteres especiais
  (box-drawing, acentos, gregas) em strings. Reforma visual do editor: abas customizadas em formato
  "chip", régua de colunas, tema escuro. Pré-processador nativo ganhou conversão `?`/`PRINT`, strip
  `THEN`/`GOTO`, tradução Unicode→MSX e maiusculização — agora lendo a configuração da tela de opções
  em vez de usar valores fixos.
- **2026-07-15** — Nova tela `Configurar → Editor...` (fonte, tema claro/escuro, estilo de abas,
  fontes customizadas, caminho de instalação). Diretório de instalação do Basic Dignified Suite
  configurável, com botão para baixar o toolchain direto do GitHub (`git clone` ou `.zip`). Botão de
  download de fontes Nerd Fonts direto de `nerdfonts.com` (lista ao vivo, seleção individual ou em
  lote). Script `build.ps1` para compilar via `pbcompiler.exe` (caminho configurável com `-C`/
  `--compiler`, `-R`/`--run` para executar após compilar, `-H`/`--help` para a lista de opções),
  embutindo versão (`5.1.3`) e build (data/hora UTC da compilação em hex) no executável, exibidas em
  `Ajuda → Sobre...`. Editor ganhou teclado estilo WordStar/JOE
  (`WordStarKeys.pbi` — movimento do cursor, apagar texto, bloco marcado com destaque persistente,
  salvar/abrir/fechar, desfazer/refazer; `Ctrl+S` deixou de ser "salvar" e virou "cursor para a
  esquerda", como no WordStar de verdade). Tela de ajuda embutida (`Ctrl+K H`, fecha com qualquer
  tecla) e barra de status no rodapé (modo/prefixo de comando pendente, nome do arquivo, linha e
  coluna). Novo `docs/MANUAL.md` com o guia de uso da IDE. Mais tarde no mesmo dia: `INCLUDE`
  recursivo e remtags (`##BB:...`) implementados no pré-processador nativo, fechando 100% do escopo
  do `badig.py` original — os menus e o código do caminho Python (`SaveTokenized()`,
  `BadigCfg_BuildCliArgs()`) foram removidos, o `.exe` do editor não invoca mais Python em nenhum
  fluxo.
- **2026-07-16** — Botões de busca de máquina/extensão do openMSX (aba "Emulador", listam
  `share/machines`/`share/extensions` a partir do caminho do executável configurado). Opção "Abrir o
  openMSX e rodar o código após gerar" ganhou implementação real: monta um disquete `.dsk` com o
  programa gerado mais um `AUTOEXEC.BAS` de autorun e abre o openMSX direto nele (rotinas de disco
  vendorizadas de `msxDiskUtil/MSXDisk.pbi`, compiladas no próprio executável). Menu **Arquivo → Novo
  Assembly** (`Ctrl+Shift+N`) cria abas `.asm` com syntax highlight do dialeto
  [N80/Nestor80](https://github.com/Konamiman/Nestor80) (mnemônicos, registradores, diretivas,
  literais numéricos em qualquer radix). Versão embutida no executável atualizada para `5.3.1`. Mais
  tarde no mesmo dia: `MSXDisk.pbi` ganhou uma **CLI embutida** (`--diskmanipulator`, mesma sintaxe do
  `msxdisk.exe` original) e um **gerenciador gráfico** completo (menu **Criar → Disco...**, dois
  painéis estilo Norton/Total Commander, botões Adicionar/Extrair sempre por cópia e Remover
  local/disco com confirmação, tudo sobre uma cópia de rascunho — só grava no disco escolhido em
  Salvar/Salvar como/Duplicar, Cancelar descarta sem tocar nele).
- **2026-07-18** — Novo **editor de sprites** (menu **Criar → Sprite...**, `editor/SpriteEditorGui.pbi`):
  grade 8×8/16×16, palheta MSX1 de 16 cores fixas, modos MSX1/MSX2 (uma cor por sprite vs. uma cor por
  linha, aplicados automaticamente), ferramentas com ícone (lápis, borracha, pincel, balde, reta,
  retângulo, elipse — com prévia ao vivo, marcador piscando e cancelamento por Esc/botão direito),
  rotacionar/deslocar, inverter, limpar. Junto veio um **sistema de projeto** novo
  (`editor/ProjectDB.pbi`): cada projeto MSX é um arquivo SQLite único (`.msxproject`); sem nenhum
  parâmetro na linha de comando a IDE já abre um projeto implícito `noname.msxproject` num arquivo
  temporário, com **Arquivo → Novo projeto...**/**Abrir projeto...** para trocar de projeto (oferecendo
  salvar o atual antes, se tiver conteúdo não salvo) e aviso automático ao sair perguntando onde salvar
  em definitivo. O editor de sprites já usa esse sistema: cada sprite tem número sequencial e uma tag
  (até 16 caracteres), com botões **Registrar**/**Novo**/navegação (primeiro/anterior/próximo/último)/
  **Copiar**/**Colar**. Validado com um novo harness de console (`editor/tools/ProjectDBTestCli.pb`)
  cobrindo round-trip completo dos dados (criar, salvar, listar, recarregar byte a byte, promover para
  arquivo permanente, reabrir). Nome padrão de aba sem título mudou de "Sem titulo N" para "nonameN".
  Versão embutida no executável atualizada para `5.5.3`.
- **2026-07-19** — Novos itens **Arquivo → Salvar projeto** / **Salvar projeto como...**: salvar
  reaproveita o caminho já escolhido (sem diálogo, já que o `ProjectDB` grava cada sprite na hora via
  SQLite); "salvar como" sempre pergunta um caminho novo, sugerindo o atual, permitindo salvar uma
  cópia do projeto com outro nome. `OfferSaveProject()` (usado em "Novo projeto..."/ao sair) passou a
  reaproveitar essa mesma rotina em vez de duplicar a lógica de salvar. Se o nome digitado no diálogo
  não tiver extensão, `.msxproject` é acrescentado automaticamente. O projeto SQLite ganhou duas
  novidades: uma cópia sempre atualizada do conteúdo de cada aba de texto já salva em disco (tabela
  `documents`, sincronizada a cada "Salvar"/"Salvar como" de uma aba — além do arquivo `.dmx`/`.amx`/
  `.asm`/tokenizado que já ia pro disco) e o diretório de trabalho (`working_dir`, a pasta do último
  arquivo salvo, ou o diretório corrente enquanto nada foi salvo ainda). Harness `ProjectDBTestCli`
  ganhou cobertura pra essas duas novidades, incluindo round-trip através de `SaveAs`/`OpenExisting`.
  Mais tarde no mesmo dia: novo **editor de alfabetos** (menu **Criar → Alfabeto...**,
  `editor/CharsetEditorGui.pbi`) para o formato `.ALF` do Graphos III (256 caracteres 8×8 = 2048 bytes,
  binário MSX com cabeçalho de 7 bytes carregado em `&H9200`) — tabela com os 256 caracteres (16 por
  linha, cabeçalho hex de linha/coluna), grade grande editável (clique/arrastar liga-desliga pixel),
  botão **Registrar** grava os pixels de volta no caractere e atualiza a miniatura na tabela,
  **Abrir...**/**Salvar como...** leem/gravam `.alf` (extensão automática), carrega
  `alfabetos\msx.alf` como padrão ao abrir. Ainda mais tarde no mesmo dia: **integração com o sistema de
  projeto**, igual ao editor de sprites — tabela `alphabets` no `.msxproject`, barra própria com número/
  tag/**Primeiro**/**Anterior**/**Próximo**/**Último**/**Registrar alfabeto**/**Novo alfabeto** (sempre
  parte do charset padrão do MSX, nunca em branco). Esse padrão passou a vir de um **"projeto 0"**
  interno — segundo banco SQLite, sempre `:memory:`, nunca salvo, semeado com `alfabetos\msx.alf`
  **embutido no `.exe`** (`editor/DefaultCharsetMsx.pbi`, gerado a partir do `.alf` real). Harness
  `ProjectDBTestCli` ganhou cobertura completa de alfabetos, incluindo um teste que compara os bytes
  embutidos contra o arquivo `.alf` real no disco. Versão embutida no executável atualizada para
  `5.7.3` (padrão de `build.ps1` e do fallback de compilação direta em `BadigEditor.pb`), fechando o
  dia de trabalho no editor de alfabetos e no sistema de projeto. Documentação revisada:
  `docs/MANUAL.md` ganhou a seção **Editor de alfabetos** e as novas opções de projeto (Salvar
  projeto/Salvar projeto como..., cópia das abas de texto, diretório de trabalho); a tabela de
  parâmetros do `build.ps1` no manual também foi corrigida (estava documentando nomes de flag
  desatualizados, `-Version`/`-SourceFile`/`-OutputExe`, em vez dos reais `-V`/`-i`/`-o`).

- **2026-07-21** — Editor de alfabetos: o botão genérico "Abrir..." virou **"Carregar do Graphos
  III..."** — além de deixar explícito que o botão importa um `.alf` real do Graphos III, importar
  agora sempre cria um **alfabeto novo** no projeto (numeração automática, igual a "Novo alfabeto") em
  vez de sobrescrever silenciosamente o alfabeto atualmente selecionado; depois de carregar, **Registrar
  alfabeto** grava a importação no `.msxproject`, permitindo vários alfabetos Graphos III diferentes no
  mesmo projeto. Também: **ícone do aplicativo** (`msxbasica.ico`) embutido no `.exe` via `/ICON` do
  `pbcompiler.exe` (novo passo em `build.ps1`) — aparece no Windows Explorer/propriedades do arquivo —
  e reaplicado em tempo de execução (`App_ApplyWindowIcon()`, `editor/BadigEditor.pb`, extraído do
  próprio processo via `ExtractIconEx`, sem depender do `.ico` sobreviver ao lado do `.exe`) em toda
  janela top-level do editor (principal, sprite, alfabeto, disco, configurações, download de fontes),
  cobrindo barra de título/menu de sistema, barra de tarefas e Alt+Tab. Versão embutida no executável
  atualizada para `5.7.4`.

- **2026-07-21 (mais tarde no mesmo dia)** — Editor de alfabetos ganhou clipboard e edição em lote:
  **Copiar/Colar** de um único caractere (área de transferência da sessão, funciona entre caracteres do
  mesmo alfabeto ou de alfabetos diferentes) e **Copiar alfabeto/Colar alfabeto** (os 256 caracteres de
  uma vez, para duplicar um alfabeto inteiro para outro número). Também: **Marcar início de bloco** /
  **Marcar fim de bloco** / **Limpar bloco** — marcam um intervalo de caracteres na tabela (contorno
  azul, ex.: A..Z); com um intervalo marcado, o botão **Inverter** passa a inverter todos os caracteres
  do intervalo de uma vez direto no alfabeto em memória, em vez de só o caractere selecionado (sem
  bloco marcado, "Inverter" continua afetando só o caractere atual, como antes). Verificado por
  compilação limpa, screenshot da janela (layout das novas linhas de botões sem sobreposição) e um
  teste ao vivo do fluxo de marcar bloco + inverter (confirmado via texto de status "Bloco:
  $00..$00 (1 caracteres)" e os bytes do caractere virando `&HFF` após inverter) — clique sintético no
  canvas da tabela para selecionar um caractere específico não se mostrou confiável neste ambiente de
  teste (mesma limitação já registrada para os editores de sprite/alfabeto em sessões anteriores), mas
  a lógica de marcação/inversão de bloco em si foi confirmada funcionando. Versão embutida no
  executável atualizada para `5.7.5`.

- **2026-07-21 (ainda mais tarde no mesmo dia)** — Editor de alfabetos ganhou **Copiar bloco**/**Colar
  bloco**, ao lado de "Limpar bloco": copiam/colam o **intervalo inteiro** marcado (não um caractere
  só). "Colar bloco" cola a partir do caractere selecionado na tabela e remarca o destino como o novo
  bloco, permitindo inverter na sequência sem remarcar — fluxo pedido: marcar A..Z, Copiar bloco,
  selecionar "a", Colar bloco (a..z passam a ter os desenhos de A..Z), Inverter (só a..z) — resultado:
  A..Z normal e a..z invertido, dois conjuntos prontos no mesmo alfabeto. Versão embutida no executável
  atualizada para `5.7.6`.

- **2026-07-21 (fim do dia)** — Todos os botões do editor de alfabetos viraram **ícones
  monocromáticos** desenhados em memória (34×26, cinza sobre branco, sem depender de arquivo externo —
  mesma técnica já usada no editor de sprites, `SpriteEd_CreateXxxIcon`), com dica ao passar o mouse
  explicando cada função: setas de navegação, página+"+" (Novo alfabeto), ficha (Registrar), duas
  folhas (Copiar), prancheta (Colar), pasta (Carregar do Graphos III), disquete (Salvar como),
  colchetes `[`/`]` (Marcar início/fim de bloco), colchetes riscados (Limpar bloco), grade riscada
  (Limpar caractere) e círculo meio preto/meio branco (Inverter). Vários botões de escopo diferente
  (caractere/alfabeto/bloco) reaproveitam o mesmo desenho — só a posição na janela e o tooltip mudam.
  A troca encolheu a janela de ~732px para ~606px de largura. Verificado por compilação limpa,
  screenshots (geral + recortes ampliados de cada grupo de ícones) e um clique real confirmando que os
  botões de imagem continuam disparando os mesmos eventos de antes. Versão embutida no executável
  atualizada para `5.7.7`.

- **2026-07-21 (à noite)** — Novo **editor de som PSG** (menu **Criar → Som (PSG)...**,
  `editor/PsgSynth.pbi` + `editor/PsgEditorGui.pbi`): motor de emulação do AY-3-8910/YM2149 escrito do
  zero (osciladores de tom por acumulador de fase, LFSR de ruído de 17 bits, gerador de envelope com as
  10 formas de hardware, tabela de volume logarítmica de 16 níveis), validado por harness de console
  (`editor/tools/PsgTestCli.pb` — frequência medida bate com a esperada, volume 0 é silêncio). Um "som"
  é um mini-sequenciador de passos (cada um com os 14 registradores do `SOUND` + duração em quadros),
  editável na janela com **Adicionar/Atualizar/Remover/Mover/Duplicar passo**, **Tocar**/**Parar**
  (renderiza para `.wav` temporário e toca) e geração de código (**Gerar código BASIC**/**Gerar bytes
  crus**, com **Injetar no cursor**/**Copiar**). Integrado ao sistema de projeto (tabela `psg_sounds`,
  mesma barra de projeto dos editores de sprite/alfabeto) — coberto por round-trip em
  `editor/tools/ProjectDBTestCli.pb`. Durante o desenvolvimento apareceu um bug real de corrupção de
  heap: `ReDim` no PureBasic só redimensiona a **última** dimensão de um array multi-dimensional, então
  guardar os registradores como matriz 2D (passos × registradores) quebrava ao carregar do projeto —
  corrigido serializando como array 1D achatado. Logo em seguida, teste ao vivo revelou que os campos
  numéricos (Volume, período de ruído/envelope, duração) usavam `SpinGadget` (campo com setinhas ▲▼) e o
  texto do campo nunca atualizava visualmente ao clicar nas setas (confirmado enviando a mensagem nativa
  `UDM_SETPOS32` direto no controle: o valor mudava por dentro, mas a tela continuava mostrando o número
  antigo) — substituídos por campos de texto simples, digitáveis, resolvendo tanto o "spin não funciona"
  quanto o "sem som" (volume ficava preso em 0 sem o usuário conseguir ver/confirmar o ajuste). Versão
  embutida no executável atualizada para `5.9.3`.

- **2026-07-21 (madrugada)** — Novo **editor de música MML** (menu **Criar → Música (PLAY)...**,
  `editor/MmlSynth.pbi` + `editor/MmlEditorGui.pbi`): cobre o dialeto MML do MSX-BASIC completo (notas
  A-G com sustenido/bemol, `L` duração, 8 oitavas `O`/`>`/`<`, pausa `R`, andamento `T`, volume `V`,
  nota absoluta `N`, envelope `M`/`S`, ponto de aumento `.`). O motor reaproveita quase 100% do
  `PsgSynth.pbi` do editor de som — mesmo chip, mesmo gerador de envelope compartilhado pelos 3 canais
  — só adicionando um parser MML por canal e uma mesclagem cronológica dos 3 canais independentes num
  único fluxo de registradores do PSG (chamando `PsgSynth_RenderStep()` sem alterar). UI com os 3 canais
  em paralelo, cada um com uma "linha atual" editável preenchida por botões, lista de linhas por canal
  e a mesma barra de projeto (Registrar/Novo/navegação) dos demais editores. Persistência em nova
  tabela `mml_songs` no `.msxproject`, coberta por round-trip em `ProjectDBTestCli.pb`. Validado por
  `editor/tools/MmlTestCli.pb` (frequências de nota corretas, duração/pontos batendo com a matemática
  esperada, `N` batendo com `O`+nota equivalente) e ao vivo via mensagens do Windows (nunca cursor
  real). Preencheu o módulo 8 do `docs/SPEC.md`, que estava marcado como "Gap" (sem nenhuma
  especificação registrada).

  Logo em seguida, dois ajustes pedidos depois de ver a janela funcionando: **disposição dos botões**
  compactada (notas + pausa numa fileira só; os antigos botões largos "Definir O"/"Definir L"/"Definir
  T"/"Definir V"/"Definir M"/"Definir S"/"Inserir N" viraram um ícone "+" ao lado de cada campo — a
  letra do campo já diz o comando MML; campos relacionados como N+O, L+T e M+S passaram a dividir a
  mesma fileira) — a janela encolheu de ~820px pra ~740px de altura; e os botões **Novo**/**Registrar**
  do editor de música (e também do editor de som, pra ficar uniforme) trocados de texto para os mesmos
  ícones já desenhados no editor de sprites (`SpriteEd_CreateNewSpriteIcon`/`CreateRegisterIcon`,
  reaproveitados sem duplicar nenhum desenho). Nessa checagem apareceu um bug real de
  `HasUnsavedContent()` (a função que decide se avisa "salvar antes de sair"): só contava a tabela de
  sprites, então um projeto só com alfabetos, sons ou músicas nunca disparava o aviso — risco real de
  perder esse conteúdo ao fechar sem salvar. Corrigido somando as 4 tabelas (`sprites`+`alphabets`+
  `psg_sounds`+`mml_songs`). Versão embutida no executável atualizada para `5.9.5`.
- **2026-07-23** — Novo **editor de alfabetos Aquarela** (menu **Criar → Alfabeto Aquarela...**,
  `editor/AquarelaCharsetEditorGui.pbi`): edita o formato `.FNT` de outro editor de fonte MSX
  (alternativa ao Graphos III), com engenharia reversa completa registrada em
  `docs/reference/aquarela.md`. Descoberta principal da sessão: cada registro de 32 bytes **não**
  começa no byte `N×32` do arquivo como a fórmula inicial supunha, mas 7 bytes depois — confirmado
  comparando pixel a pixel a decodificação contra uma screenshot real do Aquarela rodando num
  emulador (sem esse ajuste, cada glifo aparecia com um "floreio" desconexo no topo, na real a ponta
  final do caractere anterior vazando pro caractere seguinte). Glifo real 16×16 (2 planos de 16 bytes,
  coluna esquerda/direita), ferramenta autocontida baseada em arquivo (Novo/Abrir/Salvar/Salvar como),
  sem integração com o sistema de projeto. Tabela inicial cobria 32 caracteres (A-Z + `& ? ! "` +
  `0 1`) — ampliada depois pra **46 caracteres** (`A-Z`, `& ? ! "`, `0-9`, `. : - ( ) ,`), a ordem
  completa confirmada por teste real do usuário e por `LOGO.FNT` (fonte 8×8 completa do disco
  original do Aquarela, que lê perfeitamente até bem depois dos 46 glifos "oficiais").
- **2026-07-23 (mais tarde no mesmo dia)** — Editor de alfabetos Graphos III ganhou **11 botões de
  efeito** novos, todos seguindo o mesmo padrão dual já usado pelo "Inverter" (sem bloco marcado,
  afeta só o caractere em edição; com bloco marcado — ou o novo botão **All** — aplica direto em todo
  o intervalo, sem precisar de "Registrar" por caractere): **All** (marca o alfabeto inteiro de uma
  vez), **Desfazer**/**Refazer** (pilha de instantâneos do alfabeto inteiro, até 50 níveis, zerada ao
  trocar de alfabeto), **Espelhar horizontal**/**Espelhar vertical**, **Girar 90°** (sentido horário),
  **Apagar** (mesmo efeito de "Limpar", com o modo dual), **Estreitar** (condensa as 5 colunas da
  metade esquerda do glifo em 3, truque clássico de MSX pra caber 64 colunas de texto onde só
  caberiam 32), **Itálico** (desloca as linhas do glifo progressivamente — 2 bits nas 2 primeiras, 1
  bit nas 3 seguintes, nenhuma nas 3 últimas), **Negrito** (OR de cada linha com ela mesma deslocada 1
  bit, engrossando os traços) e **Largo** (funde as colunas 0-2 do original com as colunas 3-7 do
  original deslocado, esticando o glifo). Duas rodadas de refinamento a pedido do usuário: os efeitos
  Largo tiveram uma variante "Largo (direita)" que virou, depois de uma correção do próprio pedido,
  **Bold (esquerda)** e **Bold (direita)** (engrossam um lado específico do glifo via OR em vez de só
  deslocar); e **Largo (bold)**, literalmente `Bold(Largo(x))`, reaproveitando as duas transformações
  já existentes em vez de uma fórmula de bits nova. Ícones novos (seta circular, setas de espelhar/
  esticar, quadrado com arco de rotação, barras de itálico/negrito, retângulo pontilhado do "All")
  reaproveitam os mesmos helpers de triângulo preenchido (`CharEd_DrawFilledHTri`/`DrawFilledVTri`)
  extraídos do desenho da seta de navegação já existente.
- **2026-07-24** — Novo **editor de DRAW Screen 2** (menu **Criar → Draw Screen 2...**,
  `editor/Screen2Synth.pbi` motor + `editor/Screen2EditorGui.pbi` janela): editor gráfico WYSIWYG para
  SCREEN 2 com simulação fiel do color clash (1 par tinta/fundo por faixa de 8×1 pixels — o motor
  reproduz o comportamento real da ROM sem lógica extra de detecção). Sete ferramentas — PSET/PRESET
  (clique liga/apaga na hora), LINE (reta/caixa/caixa cheia), CIRCLE (círculo/elipse), PAINT
  (preenchimento), DRAW (interpretador completo da mini-linguagem de tartaruga do MSX-BASIC — `U D L R
  E F G H B N M C S A TA`, rotação exata em passos de 90° e arredondamento correto pra ângulos livres)
  e TEXTO (alfabetos do banco do projeto). Motor verificado por harness `editor/tools/Screen2TestCli.pb`
  (69 casos, incluindo o clash proposital de PAINT). Sessão evoluiu em fases dentro do mesmo dia: (1)
  motor + harness; (2) janela completa com os 7 painéis, paleta MSX1, lista de comandos e geração de
  código; (3) UX — clique no canvas já adiciona PSET/PRESET, gesto de 2 cliques com **linha elástica**
  para LINE/CIRCLE, mini buffers por ferramenta; (4) suporte a **STEP** (coordenadas relativas ao cursor
  gráfico, como no MSX-BASIC real) em todos os comandos que aceitam, e `LINE -(x,y)` (sem ponto inicial)
  — exigiu adicionar um "cursor gráfico" simulado (`Scr2_CursorX/Y`) que o motor atualiza depois de cada
  comando, igual ao MSX de verdade; (5) ferramenta TEXTO redesenhada de campos de coluna/linha para um
  **quadro elástico arrastável** com o texto real renderizado, movendo de 8 em 8 pixels (grid de tiles)
  ou pixel a pixel com Ctrl — como texto fora do grid não cabe em `LOCATE`/`PRINT` (que só endereça
  célula de caractere inteira), a geração de código ganhou um caminho alternativo que "queima" o glifo
  pixel a pixel via `PSET`/`PRESET` nesse caso. Bug pego e corrigido antes de qualquer build: uma
  primeira versão do resolvedor de STEP usava `*Ponteiro.Integer` com `\i` para devolver dois valores por
  ponteiro — sintaxe de dereferência inválida em PureBasic (`\campo` exige ponteiro tipado pra
  `Structure`, não tipo básico); substituída por duas funções `.i` com `ProcedureReturn`, mesmo padrão
  de out-param por `Global` já usado no resto do projeto. Versão embutida no executável atualizada para
  `7.1.1`.
- **2026-07-24 (mesmo dia, sessão seguinte)** — **Assembler Z80 nativo** (módulo 2) saiu do zero pra
  um motor completo: `editor/Z80Asm.pbi` (`DeclareModule Z80Asm`) com avaliador de expressão (RPN,
  precedência idêntica ao Nestor80/M80 — `HIGH`/`LOW`/`NOT`/operadores relacionais), parser de linha,
  tabela de opcodes Z80 inteira (documentados + `IXH`/`IXL`/`IYH`/`IYL` indocumentados comuns), driver
  de 2 passes (saída absoluta), diretivas de dados (`DB`/`DW`/`DS`/`DC`/`DZ`), condicionais
  (`IF`/`IFDEF`/`IF1`/`IF2`/etc.) e macros básicas (`MACRO`/`ENDM`/`EXITM`/`LOCAL`). Especificação de
  comportamento portada do **Nestor80** (Konamiman, assembler C# 100% compatível M80/L80) — clonado
  localmente só como referência de leitura (`nestor80/`, gitignored, mesmo tratamento de `badig/`).
  Como o `dotnet` está disponível no ambiente, o próprio `N80.exe` (Nestor80 compilado localmente)
  virou **oráculo de teste byte-a-byte** durante todo o desenvolvimento — mesma técnica já usada pro
  tokenizador nativo. Dois arquivos de regressão novos, `sample/teste_opcodes.asm` (~190 formas de instrução)
  e `sample/teste2_macros.asm` (condicionais + macro com `LOCAL`), montam **idênticos byte a byte** ao
  `N80.exe` real. Integrado ao editor via **Executar → Montar Assembly (.bin)...** (`Ctrl+F5`).
  Documentação de acompanhamento dedicada em `docs/resumo-asm.md` (decisões técnicas, bugs
  encontrados, gotchas de PureBasic — inclusive um achado real: `Structure` só atravessa fronteira de
  `Module` se declarada dentro do próprio `DeclareModule`, e não pode ser passada por valor como
  parâmetro de `Procedure`, só por ponteiro). Pedido do usuário durante a sessão: Linkstor80 (linker)
  e Libstor80 (biblioteca com linkagem estática seletiva) também entram no escopo do módulo — Fase B,
  ainda não iniciada. Versão embutida no executável atualizada para `7.3.1`.
- **2026-07-24 (mesma sessão, Fase B) — geração de `.REL` real, ponta a ponta**. Escritor de bit-stream
  genérico (`RelW_*`, formato estendido Nestor80, validado byte a byte contra um `.REL` mínimo real do
  `N80.exe`) **integrado a um driver de 2 passes relocável dedicado** (`RunOnePassRel`/
  `AssembleRelocatable`/`NeedsRelocatable`, separado do driver absoluto original — zero mudança de
  comportamento na Fase A). `ASEG`/`CSEG`/`DSEG`/`COMMON`/`PUBLIC`/`ENTRY`/`GLOBAL`/`EXTRN`/`EXT`/
  `EXTERNAL` passam a ter efeito de verdade: contador de localização por área, `PUBLIC` gera
  `EntrySymbol`/`DefineEntryPoint`, `EXTRN` referenciado de forma simples (`CALL externo`, `DW externo`)
  gera o mecanismo de "corrente" `ChainExternal` que o linker usa pra corrigir todas as referências de
  uma vez. A aritmética de expressão (`EvalPostfixExpr`) ganhou as regras reais de soma/subtração entre
  valores relocáveis do Nestor80 — groundwork que a própria Fase A já tinha deixado pronto/documentado
  pra este momento. Validado **byte a byte contra o `N80.exe` real** em 3 programas novos
  (`sample/teste4_rel_public.asm`/`teste5_rel_dseg.asm`/`teste6_rel_extrn.asm`), fixados como suíte de
  regressão self-contained (67/67 testes, sem precisar do `N80.exe` presente pra rodar). Escopo
  deliberadamente fora desta etapa (erro explícito, documentado em `docs/resumo-asm.md`): expressão
  externa composta, valor relocável truncado pra 1 byte, `.PHASE` em modo relocável, biblioteca/
  `.REQUEST` — ficam pro linker (`Z80Link.pbi`) ou pra uma próxima iteração.
- **2026-07-24 (mesma sessão, Fase B) — `editor/Z80Link.pbi`, primeiro corte do linker**: linka
  múltiplos `.REL` (sem biblioteca/`.REQUEST` ainda — isso é o próximo corte, junto de `Z80Lib.pbi`).
  Leitor de bit-stream que é literalmente o escritor `RelW_*` ao contrário, algoritmo de linkagem
  portado direto de `Linker/RelocatableFilesProcessor.cs` do Nestor80 (concatenação de `CSEG`/`DSEG`/
  `COMMON` entre módulos a partir de `0103h`, resolução `PUBLIC`↔`EXTRN` via a mesma corrente
  `ChainExternal`, agora percorrida ao contrário). Só o modo de sequenciamento padrão do LK80 ("dados
  antes de código", sem `--code`/`--data`/`--align-*`). Validado **byte a byte contra o `LK80.exe`
  real** em 3 cenários (módulo único; 2 módulos com `PUBLIC`/`EXTRN` cruzado incl. leitura de dado
  externo via `LD A,(externo)`; 2 módulos compartilhando um bloco `COMMON`) — **os 3 bateram já na
  primeira tentativa completa**, único ajuste necessário foi um bug real pego na validação do lado do
  assembler (`LD A,(externo)` não era reconhecido como referência externa *bare* por causa dos
  parênteses no texto do operando — corrigido). Suíte própria `editor/tools/Z80LinkTestCli.pb` (3/3).
- **2026-07-24 (mesma sessão, Fase B) — `.REQUEST`/biblioteca (corte 2) + `editor/Z80Lib.pbi`**:
  linkagem estática seletiva de verdade — o linker agora resolve `.REQUEST` procurando, **por
  programa** (não por arquivo de biblioteca inteiro), qual programa resolve cada símbolo externo
  pendente, com resolução transitiva (ponto fixo). `editor/Z80Lib.pbi` (novo) gerencia bibliotecas
  `.LIB`: `create`/`add`/`list`/`remove`, validado **byte a byte contra o `LB80.exe` real**. Achado
  notável durante a validação: o `LK80.exe` local tem uma limitação/bug real (só reconhece o símbolo
  público do primeiro programa de uma biblioteca multi-programa pedida via `.REQUEST` — confirmado
  com repro isolado e arquivo `.LIB` decodificado byte a byte, perfeitamente válido) — validado então
  com uma combinação de oráculo direto (onde o `LK80.exe` local funciona) e auto-consistência (onde
  não funciona: comparando contra o binário equivalente com o símbolo pedido reordenado pra ser o
  primeiro). Cadeia transitiva de 3 níveis entre programas de biblioteca também validada. Suíte
  própria: 7/7 (`editor/tools/Z80LinkTestCli.pb`, cobre linker e biblioteca).
- **2026-07-24 (mesma sessão, fechamento) — Fase B do assembler dá por encerrado o motor**: com
  `Z80Link.pbi` e `Z80Lib.pbi` prontos e validados (item anterior), a Fase B fica **motor completo** —
  geração de `.REL`, linkagem multi-módulo com `.REQUEST`/biblioteca e gerenciador de `.LIB`, tudo
  testado byte a byte contra `N80.exe`/`LK80.exe`/`LB80.exe` reais. Falta só a integração de menu no
  editor (hoje é engine + CLI de teste, `editor/tools/Z80LinkTestCli.exe`, sem opção em
  **Executar →**) — próxima etapa, ver checklist Fase B em `docs/resumo-asm.md`. Documentação
  atualizada em todos os `*.md` do projeto (`README.md`, `docs/SPEC.md` módulo 2b, `docs/MANUAL.md`
  seção "Assembler Z80"). Versão embutida no executável atualizada para `7.3.3`.

- **2026-07-25 — Integração de menu do linker/biblioteca + saída MSX-BASIC + sistema de projeto,
  fechando o módulo 2b/2c**: **Executar → Linkar (.REL) → binário...** (`editor/Z80LinkGui.pbi`) linka
  uma lista ordenada de `.REL` (Adicionar/Remover/Subir/Descer) com pasta de biblioteca opcional
  (`.REQUEST`); **Criar → Biblioteca Z80 (.LIB)...** (`editor/Z80LibGui.pbi`) cria/abre uma `.LIB`,
  lista programas com tamanho/símbolos públicos, adiciona `.REL` e remove programa — sem cópia de
  rascunho (`Z80Lib.pbi` já grava atômico no arquivo escolhido). Novo **Executar → Montar Assembly
  relocável (.REL)...** monta a aba `.asm` ativa em `.REL`, o insumo que faltava pro linker/biblioteca a
  partir do editor. A saída (montagem absoluta ou link) passa por um escolhedor comum novo
  (`editor/Z80OutputGui.pbi`): `.bin` no PC, **disco MSX (`.dsk`)** pronto pra rodar via `AUTOEXEC.BAS`
  (`BLOAD"...",R`, reaproveitando `MSXDisk.pbi`/mesmo mecanismo do `RunOnOpenMSX()`), ou **listing
  BASIC** (`Z80Gen_BasicLoader()` — `FOR`/`READ`/`POKE` + `DATA` em hexa, mesmo espírito do "Gerar bytes
  crus" do editor de som PSG). Sistema de projeto ganhou a tabela `asm_builds` (`ProjectDB.pbi`),
  metadado da última exportação por origem (caminho do `.asm`, ou a lista de `.rel` de uma sessão de
  link), coberta por round-trip em `editor/tools/ProjectDBTestCli.pb` (fora da soma de
  `HasUnsavedContent()` de propósito, mesmo motivo de `documents`). Bug real encontrado na integração:
  `Z80Link.pbi` e `Z80Asm.pbi` cada um fazia seu próprio `XIncludeFile "Z80RelFormat.pbi"` de dentro do
  respectivo `DeclareModule`, mas `XIncludeFile` deduplica por caminho de arquivo em todo o programa
  (não por `Module`) — funcionava isolado no CLI de teste (que nunca inclui `Z80Asm.pbi`), mas quebrava
  assim que os dois módulos passaram a coexistir na mesma unidade de compilação (`BadigEditor.pb`);
  corrigido com `editor/Z80RelFormatLink.pbi`, uma cópia dedicada pro `Module Z80Link` (mesmo espírito
  de "cada Module tem sua cópia" já usado pra `Z80LinkItemType`). Versão embutida no executável
  atualizada para `7.3.5`.

- **2026-07-25 (sessão seguinte) — Assembly Sub Project, "Makefile primitivo"**: novo **Criar →
  Assembly Sub Project...** (`editor/Z80SubProject.pbi` motor + `editor/Z80SubProjectGui.pbi` janela) —
  o usuário reúne vários `.asm` (cada um vira `.REL` na hora do build) mais bibliotecas referenciadas
  via `.REQUEST` numa lista **ordenada** (Adicionar/Remover/Subir/Descer), botão **Montar tudo
  (Build)...** monta tudo de uma vez e manda pro escolhedor de saída existente (`.bin`/`.com`, disco
  `.dsk` ou listing BASIC), botão **Gerar biblioteca a partir dos .ASM selecionados...** empacota um
  subconjunto (ou a lista inteira, se nada estiver marcado) numa biblioteca e oferece adicioná-la de
  volta. Registrado no `.msxproject` via nova tabela `asm_subprojects` (`ProjectDB.pbi`, `asm_files`/
  `lib_files` como TEXT unidos por `Chr(10)` na ordem escolhida, mesmo padrão de `mml_songs`) — mesma
  barra de projeto (número/tag/navegação/Novo/Registrar) dos demais editores, reaproveitando os ícones
  do editor de sprites. **Achado real**: `Z80Link::LResolveLibPath()` (motor do linker, sessão anterior)
  sempre resolve um nome de `.REQUEST` bare pra `"<nome>.rel"` — mesmo que já termine em `.lib` (vira
  `"nome.lib.rel"`, nunca encontrado) — então bibliotecas geradas por **Criar → Biblioteca Z80 (.LIB)**
  (que sugere extensão `.lib`) não funcionavam sozinhas via `.REQUEST`. Corrigido no subprojeto, não no
  gerenciador de biblioteca: `Z80SubProj_StageLibraries()` sempre copia+renomeia cada biblioteca pra
  `.rel` numa pasta de trabalho temporária antes de linkar. Suíte própria
  `editor/tools/Z80SubProjectTestCli.pb` (4/4, self-contained) monta pares de `.asm` reais de `sample/`
  DIRETO dos fontes e confere byte a byte contra os mesmos resultados já validados contra o `LK80.exe`
  real, incluindo o fluxo completo "gerar biblioteca a partir de `.asm` → resolver `.REQUEST` no build
  final" (linkagem estática seletiva confirmada de ponta a ponta). Versão embutida no executável
  atualizada para `7.3.7`.

- **2026-07-25 (sessão seguinte) — botão "Gerar .COM"**: pedido explícito do usuário — "vamos criar uma
  opção de gerar .COM, assim o assembler pode trabalhar independente do MSX BASIC". Novo botão **Gerar
  .COM (MSX-DOS, independente do BASIC)...** na janela "Saída da montagem" (`Z80Out_ExportCom()`,
  `editor/Z80OutputGui.pbi`), ao lado de "Salvar .bin no PC.../Gravar disco.../Gerar listing BASIC" —
  vale pra "Montar Assembly (.bin)...", "Linkar (.REL) → binário..." e "Assembly Sub Project → Montar
  tudo". Grava sempre sem cabeçalho (um `.COM` CP/M/MSX-DOS clássico nunca tem) e avisa, sem bloquear,
  se o endereço de montagem não for `0100h` (o MSX-DOS sempre carrega um `.COM` ali, independente do
  `ORG` do fonte). Reaproveita `Z80Out_WriteBinFile()` sem nenhuma mudança — o "binário cru" que esse
  caminho já gravava desde a sessão anterior já era um `.COM` válido, só faltava um atalho dedicado em
  vez de "Salvar .bin" + responder "Não" na pergunta de cabeçalho + digitar a extensão manualmente.
  Versão embutida no executável atualizada para `7.3.9`.

- **2026-07-25 (sessão seguinte) — Graphos III, Fase 1**: pedido explícito do usuário — replicar o
  **Graphos III** (editor de vídeo clássico do MSX, Renato Degiovani 1987, manual lido de
  `graphos/graphos.txt`), começando pela "tela que representa a SCREEN 2" antes do resto do toolset.
  Novo **Criar → Graphos III Screen 2...** (`editor/GraphosScreenGui.pbi`) — zero motor novo, reaproveita
  100% do módulo 5 (`Screen2Synth.pbi`/`Screen2EditorGui.pbi`, já validado por 69 casos de teste) pro
  canvas 256×192 com color clash idêntico ao MSX, mais os ícones/paleta MSX1 do editor de sprites
  (`SpriteEd_FillPalette`/`CreatePencilIcon`/`CreateEraserIcon`/`UnpressOtherTools`). Primeiras
  ferramentas: **TRAÇO** (Lápis liga com INK, Borracha apaga com PAPER, ambos com arrastar contínuo) e
  **LIMPA TELA**. Decisão de escopo, pedido explícito do usuário: o editor de alfabetos do Graphos III
  já existe nesta IDE (**Alfabeto Graphos III...**, módulo 4) e fica de fora — cada função do Graphos III
  original vira uma opção separada dentro de "Criar", em vez de um só editor monolítico; os antigos
  menus por tecla de função (F1-F5) viram botões/ícones. Resto do menu DESENHO, TEXTO, TELA, AJUSTE,
  MISCELÂNEA, shapes e os formatos de arquivo nativos (`.SCR`/`.LAY`/`.VTC`+`.ATC`) ficam para os
  próximos cortes — ainda sem persistência no `.msxproject`. Versão embutida no executável atualizada
  para `7.5.1`.

- **2026-07-25 (mesma sessão) — Graphos III, Fase 2**: completa o resto do menu **DESENHO (F1)** do
  Graphos III original em `editor/GraphosScreenGui.pbi` — **BLOCO** (TRAÇO com cursor Largura×Altura
  ajustável, campos de texto validados na hora do uso), **LINHA** (âncora + prévia elástica + clique
  final, ponto final vira início do próximo segmento — poligonal aberta, igual ao manual original),
  **RETÂNGULO** (vértice fixo + vértice oposto, âncora permanece fixa entre desenhos), **RAIO** (origem
  fixa + ponto final, mesma âncora fixa do RETÂNGULO), **CÍRCULO** (centro fixo + ponto de passagem,
  raio = distância entre os dois), **PINTURA** (só recolore o FUNDO sob o cursor, sem tocar no bit do
  pixel nem na cor de FRENTE — `GraphosScr_PaintBackground`, único ajuste fino que o motor ainda não
  tinha) e **SPRAY** (borrifo aleatório de pixels, `GraphosScr_ApplySpray`). Nenhuma dessas precisou de
  motor novo além de PINTURA/SPRAY — `Scr2_DrawLine`/`Scr2_LineStatement` (modo caixa)/`Scr2_DrawCircle`/
  `Scr2_FloodFill` (todos de `Screen2Synth.pbi`) e as prévias elásticas de LINHA/CÍRCULO
  (`Scr2Ed_DrawLinePreview`/`DrawCirclePreview` de `Screen2EditorGui.pbi`) já existiam prontos, usados
  sem nenhuma mudança. Fiel ao manual original: todas as ferramentas desenham com **INK**, exceto
  PINTURA (sempre **PAPER**); só **TRAÇO/BLOCO/SPRAY** respeitam o alternador **Lápis(INS)/Borracha
  (DEL)** (LINHA/RETÂNGULO/RAIO/CÍRCULO/FILL sempre desenham, nunca apagam) — o alternador fica
  desabilitado (`DisableGadget`) quando a ferramenta ativa não o usa. Botão direito do mouse cancela a
  âncora pendente de LINHA/RETÂNGULO/RAIO/CÍRCULO (equivalente ao ESC do original); trocar de ferramenta
  também cancela. Continuam de fora (próximos cortes): menu TEXTO, TELA, AJUSTE, MISCELÂNEA, shapes,
  formatos nativos `.SCR`/`.LAY`/`.VTC`+`.ATC` e persistência no `.msxproject`. Versão embutida no
  executável atualizada para `7.5.2`.

- **2026-07-25 (mesma sessão) — Graphos III, Fase 3**: implementa o menu **TEXTO (F2)** do Graphos III
  original em `editor/GraphosScreenGui.pbi` — escreve na tela com um alfabeto já registrado no projeto
  (**Criar → Alfabeto Graphos III...**, `ProjectDB::FetchAlphabet`, mesmo formato 256×8 do módulo 4), nas
  6 variações do manual: **NORMAL**, **ITALIC**, **BOLD**, **DUPLO** (dupla altura), **DUPLO BOLD**
  (dupla altura e largura) e **LARGO** (dupla largura). ITALIC/BOLD reaproveitam as mesmas transformações
  de bits já escritas pro editor de alfabetos (`CharEd_ItalicEditGrid`/`BoldEditGrid`, módulo 4c) sem
  duplicar a fórmula — a diferença é que aqui a transformação só afeta o desenho na tela, nunca o
  alfabeto salvo no banco. DUPLO/LARGO/DUPLO BOLD são duplicação geométrica de linha/coluna no
  framebuffer (`GraphosScr_TextScaleX`/`TextScaleY` resolvem as 6 combinações com um só par de loops),
  sem mexer na forma do glifo — o mesmo sentido de "dupla altura/largura" de impressora matricial que dá
  nome às opções originais. Fluxo igual ao "Posicionar → prévia elástica segue o mouse → clique fixa" já
  usado pela ferramenta TEXTO do editor "Draw Screen 2..." (módulo 5) — `GraphosScr_DrawTextPreview`
  reescreve `Scr2Ed_DrawTextPreview` original pra suportar as 6 variações, sem o grid de 8px/STEP (esse
  editor ainda não gera código BASIC, só framebuffer). Botão direito cancela o posicionamento pendente;
  trocar de ferramenta DESENHO também cancela. Versão embutida no executável atualizada para `7.5.3`.

- **2026-07-25 (mesma sessão) — Graphos III, Fase 4 (menu TELA) + reorganização de layout + alfabeto
  padrão**: três pedidos explícitos do usuário na mesma mensagem.
  - **Menu TELA (F3)** completo (exceto IMPRIME TELA, sem suporte a impressora nesta IDE):
    **SALVA TELA**/**Restaurar** (backup/restauração da tela inteira — pixels + Tinta + Fundo — num
    buffer dedicado), **INVERTE VIDEO** (inverte cada pixel sem mexer em cor), **INVERTE ATRIBUTOS**
    (troca Tinta/Fundo de toda a tela sem mexer em pixel), **RETIRA VIDEO**/**REPOE VIDEO** (apaga os
    pixels guardando-os num buffer, e devolve) e **RETIRA ATRIBUTOS**/**REPOE ATRIBUTOS** (idem só para
    as cores — a tela fica só com os pixels setados à vista, cor branco/preto padrão, até repor).
    LIMPA TELA (já existia desde a Fase 1) passou a viver nessa mesma grade de ícones. Cada par
    RETIRA/REPOE usa seu próprio slot de backup independente (vídeo/atributos/tela inteira) em vez do
    "buffer único, sempre atualizado a cada operação" do Graphos III original (isso exigiria um undo
    geral pra qualquer ação da janela — fora de escopo aqui).
  - **Reorganização de layout**: a coluna direita estava crescendo demais a cada fase (chegou a ~800px
    de altura) enquanto a área abaixo do canvas ficava vazia. BLOCO (Largura×Altura) e TEXTO
    (alfabeto/estilo/string/Posicionar) — controles de texto, mais naturais na horizontal — desceram
    pra uma faixa abaixo do canvas, ao lado do botão Fechar; as duas grades de ferramentas (DESENHO e
    a nova TELA) passaram de 3 para 5 ícones por linha, cortando uma linha de cada. Resultado: janela
    bem mais baixa e equilibrada entre canvas e coluna direita.
  - **Ícones em todo botão de ação** (pedido explícito — nada mais só-texto): **RETIRA**/**REPOE**
    (vídeo e atributos, 4 botões) compartilham um único gerador parametrizado
    (`GraphosScr_CreateRetiraRepoeIcon`, xadrez preto/branco = vídeo, laranja sólido = atributos, seta
    pra cima = retira, pra baixo = repõe) em vez de 4 ícones quase-idênticos; **SALVA TELA** ganhou um
    ícone de disquete, **Restaurar** uma seta circular de undo, **INVERTE VIDEO**/**INVERTE ATRIBUTOS**
    ícones próprios (quadrado dividido preto/branco; dois retalhos de cor com setas opostas).
  - **Alfabeto padrão automático**: `editor/BadigEditor.pb` ganhou `App_EnsureDefaultAlphabet()`,
    chamada uma vez no arranque da IDE (junto com `ProjectDB::EnsureOpen()`) — garante que o projeto
    ativo sempre tenha um alfabeto com a tag **"padrao"** (semeado do mesmo charset MSX embutido que
    "Novo alfabeto" já usa, `ProjectDB::FetchDefaultAlphabet(0, ...)`), pra este editor (menu TEXTO) e
    qualquer outro consumidor futuro sempre terem um alfabeto pronto sem passar por **Criar → Alfabeto
    Graphos III...** primeiro. Só cria um novo se nenhum dos já registrados tiver essa tag — não mexe
    em projetos que já têm um "padrao" salvo por uma sessão anterior. Versão embutida no executável
    atualizada para `7.5.4`.

- **2026-07-25 (mesma sessão) — Graphos III: ajuste fino de layout**: dois pedidos explícitos do
  usuário sobre a Fase 4. **BLOCO** (Largura×Altura) voltou pra coluna direita, logo abaixo da grade
  **Ferramenta (DESENHO)** — fica junto da ferramenta que ele configura, em vez de longe dela na faixa
  abaixo do canvas. **TEXTO** passou a ser uma linha por opção (Alfabeto, Estilo, Texto, Posicionar —
  cada um com seu próprio label + campo), em vez de tudo espremido lado a lado numa única linha.
  Versão embutida no executável atualizada para `7.5.5`.

- **2026-07-25 (mesma sessão) — Graphos III, Fase 5: persistência no projeto (Telas/Layouts/Shapes)**:
  pedido explícito do usuário — "colocar os trabalhos do Graphos no arquivo de Projeto também. Telas,
  shapes, layouts... menu similar aos outros onde o usuário pode nomear a tela/shape/layout, adicionar
  novos, registrar, avançar para o próximo, retroceder, ir para o primeiro e para o último". Três
  tabelas novas em `ProjectDB.pbi` (`graphos_screens`/`graphos_layouts`/`graphos_shapes` —
  **diferentes** da tabela `screens` já existente do editor "Draw Screen 2..." módulo 5, que guarda
  lista de comandos em vez de framebuffer), cada uma com o mesmo padrão número/navegação/tag/Novo/
  Registrar já usado pelo editor de sprites/alfabetos (reaproveita `CharEd_CreateNavIcon`/`NewIcon`/
  `RegisterIcon`/`SpriteEd_FindNavTarget` sem nenhuma mudança):
  - **TELA** e **LAYOUT** compartilham o mesmo canvas em edição e a mesma flag de "não registrado" —
    são 2 formatos de salvar o mesmo framebuffer (TELA = pixels + cores; LAYOUT = só pixels,
    equivalente ao `.LAY` original), não 2 documentos independentes. Confirmação antes de descartar
    alterações não registradas, mesmo padrão do editor de alfabetos.
  - **SHAPE** é um recorte retangular de tamanho **variável**, buffer próprio e independente do canvas
    principal — **Marcar área...** arma um modo de 2 cliques igual ao RETANGULO (mesma prévia elástica)
    que captura o recorte marcado do canvas pro buffer do shape. O eixo X da seleção é sempre alinhado
    ao grid de 8px antes de capturar, garantindo que cada célula de cor local do shape corresponda a
    uma célula inteira da tela de origem sem precisar reamostrar cor nenhuma. Uma prévia em miniatura
    (escalada pra caber numa caixa fixa) mostra o recorte capturado.
  - Pattern/Color são empacotados 1 byte por célula de 8 pixels (mesmo layout lógico da Pattern/Color
    Table de verdade do TMS9918 — INK no nibble alto, PAPER no nibble baixo), hex-codificados 2 dígitos
    por byte, mesmo padrão já usado por `StoreAlphabet`.
  - Deliberadamente fora: escolha de máscara/tipo do SHAPE (isso é CRIA SHAPES de verdade, seção 3.8 do
    manual — fica pro carimbo AND/OR/XOR de MISCELÂNEA, fase futura) e os formatos de arquivo nativos
    `.SCR`/`.LAY`/`.VTC`+`.ATC` em disco (a persistência desta fase é só no banco SQLite do projeto).
  Versão embutida no executável atualizada para `7.5.6`.

- **2026-07-25 (mesma sessão) — correção de layout: barras de Tela/Shape colidindo com a coluna
  direita**: pedido explícito do usuário — o botão "Marcar área..." e a prévia do Shape apareciam por
  cima do fim da coluna direita (grade TELA (F3)/status). Causa: a faixa abaixo do canvas (onde ficam
  as barras de projeto Tela/Layout/Shape) estava ancorada só em "fundo do canvas", mas a coluna direita
  é bem mais alta que o canvas sozinho (paleta + DESENHO + BLOCO + Modo + TELA + status) — a barra do
  Shape, que se estende bastante pra direita até a prévia, caía numa faixa Y que a coluna direita ainda
  ocupava. Corrigido ancorando a faixa abaixo do canvas no que for mais baixo entre "fundo do canvas" e
  "fundo da coluna direita". Versão embutida no executável atualizada para `7.5.7`.

- **2026-07-25 (mesma sessão) — refinamento de layout: janela alta demais + INK/PAPER lado a lado**:
  pedido explícito do usuário — a correção da `7.5.7` (ancorar a faixa abaixo do canvas no fim da coluna
  direita) resolvia a colisão mas deixava a janela ocupando quase toda a altura da tela, com muito
  espaço não aproveitado. Causa raiz real: a barra do Shape só colidia com a coluna direita porque
  **"Marcar área..." + a prévia se estendiam demais em X** (até quase encostar em `RightX`) — não porque
  a faixa abaixo do canvas precisasse ficar mais baixa. Correção definitiva: **"Marcar área..." e a
  prévia do Shape ganharam linha própria**, abaixo dos 3 navegadores (Tela/Layout/Shape) — bem mais
  estreita, nunca chega perto da coluna direita — e a faixa abaixo do canvas voltou a ficar ancorada
  logo após o fim do canvas (não mais no fim da coluna direita), subindo tudo de volta pra perto do
  canvas. Aproveitado também: **INK e PAPER lado a lado** em vez de empilhados, economizando uma faixa
  inteira (72px) de altura na coluna direita. Versão embutida no executável atualizada para `7.5.8`.

- **2026-07-25 (mesma sessão) — correção: prévia do Shape ainda sobrepondo os navegadores**: pedido
  explícito do usuário — a linha nova de "Marcar área.../prévia" (`7.5.8`) ainda encostava nos botões de
  navegação da barra do Shape logo acima. Causa: a prévia (70px de altura) estava deslocada 22px pra
  cima da sua própria linha (tentativa de centralizar com o botão, mais baixo), o que a empurrava de
  volta pra dentro da faixa Y que os ícones de navegação ainda ocupavam. Corrigido alinhando o topo da
  prévia com o topo da linha (sem deslocamento negativo) e aumentando a margem entre a barra de
  navegação do Shape e a linha de baixo. Versão embutida no executável atualizada para `7.5.9`.

- **2026-07-25 (mesma sessão) — Graphos III, Fase 6: menu AJUSTE (F4)**: pedido explícito do usuário —
  "scroll pixel a pixel nas 4 direções e scroll de 8 pixels por vez... mais duas opções de rotacionar
  pixel a pixel e 8 pixels por vez". Implementa as 4 operações do manual original em
  `editor/GraphosScreenGui.pbi`:
  - **SCROLL** (1px) — desloca só o **vídeo** (`PatternBit`), a parte que sai da tela é perdida.
  - **SCROLL 8x8** — desloca vídeo **e** atributos juntos (8 pixels/1 célula de cor), a área vazia é
    preenchida com as cores Tinta/Fundo atuais.
  - **ROTAÇÃO** (1px) — igual ao SCROLL, mas a parte que sai **reentra pelo lado oposto** (wraparound),
    sem perder nada.
  - **ROTAÇÃO 8x8** — idem, vídeo e atributos juntos, com wraparound.
  "Vídeo" vs "atributos" segue a mesma distinção já usada por INVERTE VIDEO/INVERTE ATRIBUTOS (Fase 4).
  UI: dois alternadores independentes (**passo** 1px/8px; **modo** SCROLL/ROTAÇÃO) + 4 setas de direção
  — ação única, aplicam a combinação passo+modo atual na hora do clique, sem precisar de "Registrar".
  Ícones das setas reaproveitam `CharEd_DrawFilledHTri`/`VTri` (já usados pelo editor de alfabetos, ver
  módulo 4c) em vez de desenhar triângulos do zero; o ícone do modo SCROLL reaproveita
  `CharEd_CreateNavIcon` com `WithBar=#True` (a "parede" no fim da seta já existia pra Primeiro/Último).
  Versão embutida no executável atualizada para `7.5.10`.

- **2026-07-25 (mesma sessão) — Graphos III, Fase 7: menu MISCELÂNEA (F5)**: pedido explícito do
  usuário — "Zoom, Shape, Corte, Grid". As 4 ferramentas avançadas do manual original em
  `editor/GraphosScreenGui.pbi`:
  - **GRID** — no original altera de verdade a cor de PAPER de toda a tela pra desenhar uma malha
    (destrutivo, limitação de hardware de 1987); aqui é um **overlay não destrutivo** (linhas finas
    desenhadas por cima do canvas a cada redesenho, nunca gravadas em `PatternBit`/`RowFG`/`RowBG`) —
    mais seguro e no espírito de "mostrar/esconder grade" de qualquer editor gráfico moderno. Precisou
    de um redesenho "completo" novo (`GraphosScr_RedrawCanvasFull`) que substitui as 31 chamadas
    diretas a `Scr2Ed_RedrawCanvas` espalhadas pelo arquivo — senão o overlay ficaria desatualizado a
    cada operação de desenho.
  - **CORTE** — marca um retângulo (2 cliques, sem alinhamento de 8px — só mexe em pixels, nunca em
    cor, fiel ao manual) + **Inverter**/**Espelhar horizontal**/**Espelhar vertical**, aplicados direto
    no recorte marcado. Sem o "teclas do cursor deslocam o corte" do original (arrastar uma seleção
    flutuante) — mesma simplificação já usada em TEXTO/SHAPE (clique fixa, sem arrastar-e-confirmar).
  - **SHAPE (carimbo)** — usa o shape **já carregado na barra de projeto Shape** (Fase 5), nenhuma UI de
    seleção nova. **MÁSCARA** cola pixels e cores (substitui tudo); **AND**/**OR**/**XOR** são lógica só
    no bit do pixel (fiel ao manual: "embora os atributos não sejam alterados") — os ícones dos 4 modos
    mostram 2 quadrados sobrepostos (shape/tela) com a região logicamente colorida de cada operação.
    Posicionamento no mesmo padrão "Posicionar → prévia segue o mouse → clique fixa" de TEXTO.
  - **ZOOM** — reinterpretação simplificada (o original tinha 3 quadros TELA/INK/PAPER e modos A/S/R
    por tecla) — marca uma região (2 cliques) e abre uma **janela à parte** com edição ampliada
    (Lápis/Borracha, INK/PAPER herdados da janela principal), escrevendo **direto** nos mesmos arrays
    da janela principal (arrays passados por referência no PureBasic) — fechar o Zoom só precisa de 1
    redesenho pra refletir as edições, sem nenhuma cópia/aplicação de volta.
  Versão embutida no executável atualizada para `7.5.11`.

- **2026-07-25 (mesma sessão) — Graphos III, Fase 9: formatos de arquivo nativos (.ALF/.LAY/.SCR/.SHP)**:
  pedido explícito do usuário — entender os formatos que o Graphos III de verdade grava em disco (usando
  os visualizadores Python de referência `alphabetV.py`/`layoutV.py`/`screenV.py`/`shapeV_2.py`) e permitir
  importar/exportar telas, layouts e shapes nesse formato, além da persistência já existente no projeto
  (Fase 5). Novo `editor/GraphosNativeIO.pbi`:
  - **.ALF** não precisou de nada novo (já correto em `CharsetEditorGui.pbi`).
  - **.LAY** (só padrão/pixels) — RLE restrito (só `$00`/`$FF` viram par marcador+contagem) com
    deslocamento `+$99` em todo byte gravado.
  - **.SCR** (tela completa) — cabeçalho BSAVE + uma rotina de apresentação Z80 de verdade (roda no MSX
    via `BLOAD"nome",R`) + padrão + cor em ordem real de VRAM (3 "terços" × 256 tiles de 8×8). Comparando
    várias amostras reais descobriu-se que essa rotina **varia de tamanho** entre arquivos (129 ou 121
    bytes) — por isso a importação calcula o tamanho a partir do **arquivo real em disco**, nunca do
    cabeçalho, e descarta a rotina sem interpretá-la; a exportação grava uma rotina de 129 bytes
    verificada byte a byte contra amostras reais (`GRAPHOS.SCR`/`STARWARS.SCR`).
  - **.SHP** (banco de shapes) — blocos `[número][tipo][largura][altura em tiles][dados]` terminados por
    `$FF`; importação lê qualquer um dos 4 tipos (máscara é lida e descartada, ainda sem uso nesta IDE);
    exportação sempre grava tipo padrão+cor, um shape por banco.
  - **UI**: 1 botão por barra de projeto (Tela/Layout/Shape — ícone de disquete, sem espaço pra 2 ícones
    separados) abre um menu popup **Importar.../Exportar...** (`CreatePopupMenu`/`DisplayPopupMenu`,
    seleção tratada de forma assíncrona via `#PB_Event_Menu`).
  - Verificado com um novo harness `editor/tools/GraphosNativeIOTestCli.pb`: round-trip completo
    (importa arquivo real → exporta → reimporta → compara bit a bit) contra amostras já presentes no
    repositório, 24/24 checks OK. Cross-validado independentemente com um decodificador Python ad-hoc.
  Versão embutida no executável atualizada para `7.5.12`.

- **2026-07-25 (mesma sessão) — correção: abas "noname" sem extensão**: pedido explícito do usuário —
  as abas de documento novo apareciam como `noname1`/`noname2`/... sem nenhuma extensão. Passaram a
  mostrar a extensão real do modo (`noname1.dmx`, `noname2.dmx`, ... ou `.asm` pra Assembly — `.dmx` e
  não `.bas` pra bater com o que **Salvar** de fato grava, formato Dignified já documentado no módulo 3).
  `editor/BadigEditor.pb`: `Docs()\UntitledName` passou a incluir a extensão (`AddDocumentTab`); a
  sugestão de "Salvar como" (`SaveDocument`) parou de concatenar a extensão de novo em cima (evitava
  duplicar, ex.: `noname1.dmx.dmx`) — os outros 6 pontos que sugerem nome pra exportação (ASCII/
  tokenizado/objeto relocável/etc.) já extraiam o nome base antes de anexar sua própria extensão, então
  não precisaram de nenhuma mudança.

- **2026-07-25 (mesma sessão) — `build.ps1 -D`/`--distribute`**: novo modo que, depois de compilar com
  sucesso, monta o pacote de distribuição na pasta `distribute\` (executável final, `README.md`,
  `docs\MANUAL.md`, `LICENSE`, pasta `sample\`, `msxbasica.ico`, `msxbasica.png`) — primeiro passo em
  direção a empacotar o editor pra usuários finais sem depender do repositório inteiro.
- **2026-07-27 — Suporte a NestorBASIC + sistema de Ajuda MSX BASIC (dicionário + manual, MSX1 e
  MSX2+)**: sessão que fechou duas frentes em paralelo.
  - **NestorBASIC**: `editor/NestorBasicSupport.pbi` (template com loader `BLOAD"NBASIC.BIN",R` +
    biblioteca de 87 wrappers `.NB_*`, três tiers), `editor/NestorBasicHelpData.pbi`/
    `NestorBasicHelpGui.pbi` (janela de ajuda navegável/pesquisável não-modal, exporta também para
    `docs/reference/nestorbasic.md`). Novos itens de menu: **Arquivo → Novo Nestor Basic...**,
    **Executar → Nestor Basic** (copia `NBASIC.BIN`/`NBASIC.DAT` de `res/` pro disco gerado) e
    **Ajuda → Nestor Basic...**. Ver seção "O que já temos" acima para o detalhe completo.
  - **Ajuda → MSX BASIC...**: novo `editor/MsxBasicHelpGui.pbi`, reaproveitando a mesma infraestrutura de
    renderização/navegação/busca já escrita para a ajuda do NestorBASIC. Duas bases de dados: **MSX1**
    (`editor/MsxBasicDictData.pbi` — 141 palavras reservadas; `editor/MsxBasicManualData.pbi` — prosa/
    tabelas do livro *"Linguagem BASIC MSX"*, Ed. Aleph/Gradiente) e **MSX 2+** (`editor/
    MsxBasic2PlusDictData.pbi` — 45 verbetes extras/estendidos; `editor/MsxBasic2PlusManualData.pbi` — 7
    tópicos de prosa/apêndices do manual ACVS FM, digitalizado em `docs/manual_msx2fm_acvs.pdf`), mais a
    página especial "Cores do MSX". Os verbetes MSX2+ entram na mesma lista única do dicionário MSX1
    (não uma seção separada), diferenciados por um campo `Sistema` e, quando é o mesmo comando com
    comportamento estendido, por um segundo verbete `"NOME (MSX2+)"` logo depois do original.
  - Nenhuma das duas frentes teve bump de versão dedicado nesta sessão — o executável commitado junto
    permanece na `7.5.12` já usada desde a Fase 9 do Graphos III.
- **2026-07-28 — Auditoria de dependências externas + remoção de `msxDiskUtil/`**: pedido explícito do
  usuário, em duas partes.
  - Confirmado por auditoria dedicada que `badig/` **não é mais necessário** para o editor funcionar —
    todos os fluxos de menu passam só pelo pipeline nativo (`DignifiedPreprocessor.pbi`/
    `MsxTokenizer.pbi`), sem nenhum caminho residual chamando Python. O botão **Configurar → Basic
    Dignified... → Baixar Basic Dignified Suite...** (já existente, aponta para
    `github.com/farique1/basic-dignified.git`) ganhou uma nota deixando explícito que é **opcional**
    (`editor/BadigSettings.pbi`) — só necessário pra quem quiser rodar o Basic Dignified Suite original
    em Python separadamente.
  - Confirmado que `msxDiskUtil/` também não é mais necessário — `editor/MSXDisk.pbi` é 100%
    self-contained. Antes de remover, um bugfix que só existia na cópia vendorizada (`MatchesFAT11`
    comparando por `Mid()`/`Asc()` em vez de byte cru, quebrando casamento por curinga tipo
    `extract *.BAS` sob Unicode) foi portado de volta pro `msxDiskUtil/MSXDisk.pbi` original, pra não
    perder a correção — só então o diretório foi removido do repositório.
- **2026-07-28 (mesma sessão) — novo Ajuda → Basic Dignified...**: pedido explícito do usuário —
  transformar a documentação completa do Basic Dignified Suite original
  (`basic-dignified/documentation/*.md`, baixada pelo botão de download da tela de configuração) numa
  janela de ajuda navegável dentro do próprio editor, cobrindo tanto a sintaxe do dialeto quanto as
  configurações desta IDE. Novo `editor/BasicDignifiedHelpData.pbi` (21 tópicos em 4 grupos: Sintaxe
  Dignified, Configurações, Remtags, Sobre a suíte original) + `editor/BasicDignifiedHelpGui.pbi`
  (janela não-modal, reaproveitando a mesma infraestrutura de árvore/busca/histórico/renderização
  Markdown mínima já usada por Ajuda → Nestor Basic/MSX BASIC). Cada tópico de configuração foi
  cruzado com o código real (`Dig_SyncConfigFromBadigCfg()`, `RunOnOpenMSX()`, `MsxTokenizer.pbi`) pra
  dizer explicitamente quais campos da tela `Configurar → Basic Dignified...` afetam a conversão hoje
  e quais são vestigiais (sem consumidor no pipeline nativo). Ver a seção "O que já temos" acima.
- **2026-07-28 (mesma sessão) — bump de versão para `7.5.13`**: pedido explícito do usuário, fechando
  a lacuna deixada pela sessão anterior (Nestor BASIC + Ajuda MSX BASIC/MSX2+ + `Ajuda → Basic
  Dignified...`, que não tinham bump dedicado — ficaram todos na `7.5.12` da Fase 9 do Graphos III).
  `build.ps1` (`$Version`) e `#App_Version` (`editor/BadigEditor.pb`) atualizados juntos.
- **2026-07-29 — novo Editor Hexa** (`editor/HexEditorGui.pbi`, menu **Executar → Editor Hexa...**):
  pedido explícito do usuário — editor hexadecimal genérico (offset/hex/ASCII, edição byte a byte) que
  reconhece os formatos binários que a própria IDE produz/consome (BLOAD/BSAVE `FEh`, tokenizado
  `FFh`, boot sector FAT12 de `.dsk`) e traz uma galeria de templates persistida em JSON (semeada com
  Alfabeto/Layout/Tela do Graphos III) pra dar nome amigável a binários reconhecidos. Duas rodadas de
  ajuste pedidas na mesma sessão: (1) correção de um campo de status que sobrepunha o botão "Fechar",
  máscara de largura fixa nos valores hex (`Hex(v,#PB_Byte)` não completa com zero à esquerda neste
  PureBasic — `HexEd_Hex2`/`Hex4`/`Hex6` resolvem isso com `RSet`) e cursor de seleção com borda de
  destaque; (2) barra de rolagem vertical customizada (o `ScrollBarGadget` nativo renderizava enorme e
  com os botões trocados — substituído por setas topo/base tradicionais + barra visual de posição
  proporcional) e operações de bloco completas: **Marcar início/fim**, **Preencher...**, **Inserir
  bloco...** (desloca)/**Sobrepor bloco...** (não desloca, ambos a partir de outro arquivo ou bytes em
  branco) e **Excluir bloco...** (deslocando ou zerando o intervalo).
- **2026-07-29 (mesma sessão) — bump de versão para `7.7.1`, codinome "`BFG9200`"**: pedido explícito
  do usuário, fechando o Editor Hexa (item acima). `build.ps1` (`$Version`) e `#App_Version`
  (`editor/BadigEditor.pb`) atualizados juntos. O codinome também foi pedido explicitamente pelo
  usuário — MSX + Doom + heavy metal: "BFG9200" cruza o BFG9000 (a arma mais brutal do Doom) com o
  `9200h`, o endereço de VRAM que virou praticamente a assinatura desta sessão (base de carga do
  Alfabeto/Layout/Tela do Graphos III, ver galeria de templates do Editor Hexa acima).
- **2026-07-29 (mesma sessão) — controle remoto do openMSX, ⚠ EXPERIMENTAL**: novo menu **Executar →
  openMSX...** (`editor/OpenMSXBridge.pbi`/`OpenMSXConsoleGui.pbi`) abre uma instância do openMSX
  separada do fluxo normal (**Executar → BASIC**/**Nestor Basic** continuam intocados) com uma janela
  de console — campo de comando, log de respostas, botões Reset/Pausar/Continuar/Ligar/Desligar,
  "Mostrar janela" (restaura a janela visível do emulador) e "Ajuda" (abre a Ajuda → openMSX ao lado).
  Primeira tentativa (`-control stdio` + escrita no stdin do processo, seguindo a doc oficial do
  openMSX à risca) não funcionou — nenhum comando surtia efeito. Investigando o código-fonte de
  verdade (openMSX + Catapult, a pedido do usuário) descobriu-se que o Catapult oficial **nunca usa
  `-control stdio` no Windows**: usa um named pipe dedicado (`-control pipe:<nome>`) só para comandos
  de entrada, mantendo stdout/stderr normais só para respostas — arquitetura reescrita para espelhar
  exatamente isso. Ainda não validado ponta a ponta contra o openMSX de verdade pelo autor (sem
  binário disponível no ambiente onde a correção foi escrita) — por isso o rótulo experimental.
  Detalhes completos em `docs/SPEC.md`, módulo 12.
- **2026-07-29 (mesma sessão) — Ajuda → openMSX...**: nova janela de referência (mesma UI de
  busca/árvore/histórico das outras 3 janelas de Ajuda) com os 5 manuais originais do openMSX (Setup
  Guide, User's Manual, Using Diskmanipulator, Controlling openMSX from External Applications,
  Console Command Reference), convertidos para o mini-Markdown interno da IDE — mais de 250 tópicos.
  Também gera `docs/reference/openmsx.md` (`OMSXHelp_ExportMarkdown()`,
  `editor/tools/OpenMsxHelpExportCli.pb`), mesma ideia do NestorBASIC. Diferente do item acima, este
  recurso é só consulta de texto (não depende do controle remoto funcionar) e não é experimental.
- **2026-07-30 — controle remoto do openMSX validado ao vivo**: novo harness
  `editor/tools/OpenMsxBridgeTestCli.pb` (mesmo padrão dos outros `*TestCli.pb`) sobe `OpenMSXBridge.pbi`
  isolado contra um openMSX 21.0 real (`C:\msx\openMSX\openmsx.exe`) sem precisar da GUI do editor. Pipe
  conecta (~300ms), o boot (`unset renderer`/`set power on`) funciona e comandos manuais recebem replies
  reais (`set power off`/`on` → `false`/`true`, `openmsx_info platform` → `mingw32`). No caminho, uma
  primeira rodada de teste (chamada direto de um terminal, sem `FreeConsole_()`) deu 0 bytes de saída
  capturada em tudo — parecia um bug sério no módulo, mas a causa raiz era outra: `main.cc` do openMSX
  (`EnableConsoleOutput()`) faz `AttachConsole(ATTACH_PARENT_PROCESS)` + `freopen("CONOUT$", ...)` em
  `stdout`/`stderr` sempre que o processo que o lança tem um console de verdade anexado, o que **rouba** a
  saída do pipe que `RunProgram(...#PB_Program_Read|Error)` preparou. O `BadigEditor.exe` real nunca bate
  nesse caso (já chama `FreeConsole_()` antes de qualquer janela abrir/chamar `OMSX_Start()`), mas o
  harness de teste precisou do mesmo `FreeConsole_()` pra reproduzir o estado certo — registrado em
  detalhe no comentário de topo do harness e em `docs/SPEC.md`, módulo 12, pra ninguém cair na mesma
  pegadinha ao investigar de novo. Rótulo "experimental" removido do menu/documentação.
- **2026-07-30 (mesma sessão) — indicador de estado, "Inserir no openMSX" e dois bugs reais
  corrigidos**: a pedido do usuário, ao vivo com um openMSX de verdade aberto:
  - **Indicador "Ligado/Desligado | Rodando/Pausado"** no topo da janela do console
    (`OMSX_StatusText()`, `editor/OpenMSXBridge.pbi`). Assina `openmsx_update enable setting` no boot
    (`GlobalCommandController.cc`) pra receber `<update type="setting" name="power|pause">valor</update>`
    de qualquer mudança de estado, não só a resposta do comando que a própria janela mandou.
  - **Bug real relatado pelo usuário**: digitar `set pause on`/`set renderer` e clicar "Enviar" não
    mostrava feedback nenhum, e nenhum comando seguinte parecia funcionar. Isolado por teste direto do
    protocolo (`OpenMSXBridge.pbi` sozinho, sem GUI): o pipe/openMSX continuavam respondendo
    perfeitamente — o bug era só na janela. Causa: `OMSXGui_AppendLog()` fazia `GetGadgetText()`
    (releitura completa do log) + `SetGadgetText()` (regravação completa) a cada tick do timer (150ms);
    em algum momento essa releitura passava a devolver vazio, e a próxima gravação então "sumia" com
    tudo que já estava escrito. Corrigido mantendo o texto acumulado só do nosso lado
    (`editor/OpenMSXConsoleGui.pbi`), nunca dependendo do widget "lembrar" o que já foi escrito -
    elimina a classe do bug, não só o sintoma.
  - **Nova área de colar/digitar texto** + botão **"Inserir no openMSX"** (janela aumentada pra
    900×500) — digita o conteúdo no MSX como se fosse teclado de verdade (quebra de linha vira Enter),
    replicando o mecanismo real do Catapult oficial: `openmsx/catapult/src/InputPage.cpp`,
    `OnTypeText()`, que manda `type -- <texto escapado>` (comando Tcl embutido do openMSX,
    `share/scripts/type.tcl`, delega pro nativo `type_via_keyboard` em `Keyboard.cc`).
  - **Segundo bug real, achado no caminho** (`OMSX_XmlEscape()`, novo em `OpenMSXBridge.pbi`): nenhum
    comando (nem os já existentes, tipo o console manual) escapava `&`/`<`/`>` antes de embrulhar em
    `<command>...</command>`. Lendo o parser de verdade do openMSX
    (`openmsx/openmsx/src/events/AdhocCliCommParser.cc`) - uma máquina de estados byte-a-byte -
    confirmou-se que um `<` cru (comum em BASIC: `IF X<10`) ou um `&` cru fora de uma entidade válida
    faz o parser voltar pro estado "procurando `<command>`", **descartando o resto do comando sem erro
    nenhum**. Corrigido escapando `&`/`<`/`>` (nessa ordem) antes de qualquer `<command>`, igual ao que
    o Catapult de verdade já faz (`openMSXController.cpp`, `WriteCommand()`,
    `xmlEncodeEntitiesReentrant()`). Duas camadas de escape agora, mesma arquitetura do Catapult:
    `OMSX_TclEscapeWord()` (nível Tcl, uma "palavra" só) por dentro, `OMSX_XmlEscape()` (nível
    transporte) por fora.
  - Validado ao vivo (harness `editor/tools/OpenMsxBridgeTestCli.pb`): texto com `<`, `>`, `&` e aspas
    sai corretamente escapado nas duas camadas, e o console continua respondendo normalmente depois de
    digitar esse texto.
- **2026-08-01 — `Executar → BASIC`/`Nestor Basic` (F5) passam a reconhecer MSX-BASIC clássico
  numerado**: pergunta explícita do usuário — o editor já tokenizava ASCII clássico com números de
  linha e `GOTO`/`GOSUB` para linha (menu **"ASCII clássico já aberto → tokenizado nativo (.bmx)..."**,
  `SaveAsTokenizedNative()`, sem depender do pré-processador Dignified nem de Python), mas **rodar**
  esse mesmo código com F5 quebrava: `RunBasicFromActiveTab()`/`RunNestorBasicFromActiveTab()` sempre
  mandavam o texto da aba pro pré-processador Dignified primeiro, que não reconhece números de linha
  como já resolvidos — tratava cada linha como Dignified sem label e prefixava sua própria numeração
  na frente da original (`10 PRINT "OLA"` virava `20 10 PRINT "OLA"`), corrompendo o programa (achado
  reproduzido com `editor/tools/DigTestCli.exe` antes da correção). Corrigida a heurística de detecção
  de `SaveAsTokenizedNative()` (primeira linha com conteúdo começa com dígito) extraída para
  `LooksLikeClassicAscii()` e reusada nos dois fluxos de Executar: se a aba já é ASCII clássico, pula
  o pré-processador e tokeniza direto, senão segue o caminho Dignified normal. Mesmo comportamento que
  o tokenizador original (`msxbatoken.py`/`-asc`) sempre suportou — programas MSX-BASIC tradicionais
  (sem Basic Dignified) agora rodam no openMSX pela IDE tal como um `.bmx` gerado pela suite original.
- **2026-08-01 (mesma sessão) — renumeração nativa e novo menu "criar .BAS"**: pedido explícito do
  usuário — dado um programa MSX-BASIC clássico já numerado, renumerar de verdade (não só empilhar uma
  segunda numeração por cima da original, tipo `10 PRINT` virando `20 10 PRINT`) para a numeração mais
  compacta possível (`1,2,3...`), corrigindo automaticamente todo `GOTO`/`GOSUB`/`THEN`/`ELSE`/
  `RESTORE`/`RESUME`/`RETURN`/`RUN` (inclusive listas `ON...GOTO`/`ON...GOSUB`) para apontar pra linha
  renumerada certa, e removendo espaços redundantes. Novo `Tok_RenumberAscii()`/`Tok_RenumberLineBody()`
  em `editor/MsxTokenizer.pbi`, deliberadamente espelhando o mesmo fluxo de casamento de comando/
  literal/identificador de `Tok_TokenizeLineBody()` (em vez de reimplementar um parser do zero) pra
  garantir que a decisão "isto é um alvo de jump" seja idêntica à que o tokenizador real vai tomar
  depois. **Bug real achado testando contra `sample/teste.dmx`**: `ON ERROR GOTO 0` é um idioma válido
  do MSX-BASIC (`0` = "desliga tratamento de erro", não uma linha real) que a primeira versão rejeitava
  como "GOTO para linha inexistente"; corrigido tratando alvo `0` como sempre intocado. Validado com um
  harness fora do projeto: casos sintéticos (`ON X GOTO 10,,30` com posição vazia preservada, `REM`/
  `DATA` com texto parecido com `GOTO` intocado, variável `TOTAL` não quebrada pelo prefixo `TO`) e o
  arquivo de produção real de ~900 linhas, batendo manualmente as referências cruzadas de
  `ON STOP GOSUB`/`RESUME` contra a posição real de cada linha-alvo. Novo item de menu **"ASCII
  clássico já aberto → renumerar e criar .BAS..."** (`SaveAsRenumberedBas()`) salva o resultado como
  `.bas` (extensão padrão MSX-DOS/MSX-BASIC), `.amx` (convenção interna do projeto) ou, encadeando com
  o tokenizador, `.bmx`.
- **2026-08-01 (mesma sessão) — "Executar → Renumerar...", equivalente nativo do `RENUM`**: pedido
  explícito do usuário — diferente do "criar .BAS" acima (sempre renumera tudo e exporta pra um
  arquivo novo), este renumera o programa **digitado na própria aba, no lugar**, com os mesmos 3
  parâmetros do `RENUM` real do MSX-BASIC (nova linha inicial, incremento, linha antiga a partir de
  qual renumerar — em branco renumera o programa inteiro), coletados por 3 diálogos `InputRequester`
  sequenciais (mesmo padrão já usado no "Ir para linha" do teclado WordStar). `Tok_RenumberAscii()`
  ganhou um parâmetro `OldLineFrom`: linhas antes dela mantêm o número original intocado, mas ainda
  entram no mapa de resolução pra `GOTO`/`GOSUB` que apontam pra elas continuar corretos; se a nova
  numeração escolhida colidisse com a faixa preservada, falha com erro em vez de gerar um programa fora
  de ordem (mesma recusa do `RENUM` real). O motor de resolução de jumps em si não precisou mudar — o
  desenho de duas passadas da correção anterior (mapeia o programa inteiro antes de reescrever qualquer
  linha) já cobria `GOTO`/`GOSUB`/`RESTORE`/`ON X GOTO`/`ON X GOSUB`/`IF...THEN GOTO`, inclusive
  referências que apontam **para a frente** no arquivo. Validado com harness fora do projeto: `RENUM`
  completo com referência pra frente e pra trás, `RENUM` parcial preservando a faixa anterior e suas
  referências, e o caso de colisão rejeitado corretamente. Escreve direto no editor (undo normal do
  Scintilla, aba marcada como modificada) — não salva sozinho, o usuário revisa e salva como de costume.
- **2026-08-01 (mesma sessão) — integração com MSXBas2Rom e N80/LinkStor80/LibStor80 (toolchains
  externas de terceiros)**: pedido explícito do usuário. Novo **Arquivo → Novo MSXBas2Rom...** (arquivo
  `.bas` ASCII clássico numerado — formato que o compilador MSX-BASIC→ROM
  [msxbas2rom](https://github.com/amaurycarvalho/msxbas2rom) espera direto, sem Dignified). Novo
  **Configurar → MSXBas2Rom...** e **Configurar → N80...**: baixam a versão mais recente do GitHub
  (Windows ou Linux conforme o sistema) e geram **Ajuda → MSXBas2Rom...**/**Ajuda → N80...** a partir do
  que foi baixado — `-h`/`--help` de cada binário + páginas reais da wiki/documentação de cada projeto
  (achado: `msxbas2rom -doc` não despeja documentação de verdade, só aponta pra wiki — o conteúdo real
  de Ajuda vem de lá). N80/LinkStor80/LibStor80 são [Nestor80](https://github.com/Konamiman/Nestor80)
  (mesmo autor do NestorBASIC já suportado) — **não confundir com o assembler/linker/biblioteca Z80
  nativo do próprio projeto** (já implementado antes desta sessão), são um caminho externo alternativo
  que convive ao lado, não uma substituição. Achado real durante a pesquisa: LinkStor80 e LibStor80 não
  são repositórios separados, vivem dentro do próprio repo do Nestor80 em release tags diferentes —
  baixar "a versão mais recente de cada um" exigiu varrer o histórico completo de releases, não só
  `/releases/latest` (que só devolve o N80). Também baixa e formata o manual M80L80
  (`docs/MACRO-80.txt` do repositório, "Microsoft M80 DOC") como um tópico de Ajuda próprio.
  - Novo motor de Ajuda compartilhado (`editor/GenericMdHelpGui.pbi`) — ao contrário dos helps
    existentes (conteúdo fixo, escrito à mão), o conteúdo destes dois é **baixado e renderizado ao
    vivo** a partir de `.md` salvos em disco (decisão confirmada com o usuário): "Baixar" de novo no
    futuro atualiza a Ajuda sozinha. Renderizador de Markdown ganhou títulos `#`/`##`/`###`, blocos de
    código ` ``` ` e, a pedido explícito ("com links e tudo mais"), **links clicáveis de verdade**
    (`[texto](url)` abre no navegador) — benefício que também vale pros 3 helps antigos, já que
    usam o mesmo motor por baixo.
  - **Bug real encontrado**: `CreateDirectory()` nativo do PureBasic não cria pastas intermediárias que
    ainda não existem — as pastas novas de instalação (`tools/msxbas2rom/`, `tools/n80/`) são caminhos
    de 2 níveis que nunca existiam antes da primeira execução, então o download extraía "com sucesso"
    sem escrever nenhum arquivo de verdade. Corrigido com um helper de criação recursiva, sem tocar na
    função de extração de zip já existente (usada também pelo download do Basic Dignified Suite).
  - Validado ponta a ponta com harnesses de console fora do projeto, baixando de verdade do GitHub:
    MSXBas2Rom v1.2.1.0 (11 tópicos), N80 1.3.5 + LinkStor80 1.1.0 + LibStor80 1.0 (6 tópicos, incl. o
    manual M80L80 de 91KB) — mesmas versões achadas manualmente durante a pesquisa. Renderização testada
    contra todo o conteúdo real baixado (maior arquivo, 109KB, renderiza em 185ms) sem crash. Aparência
    visual e clique em link **não conferidos ao vivo** (sem ferramenta de screenshot pra app nativo
    nesta sessão) — pendente de teste visual pelo usuário.
- **2026-08-01 (mesma sessão) — destaque de sintaxe estendido pro MSXBas2Rom**: pedido explícito do
  usuário — abas em modo `.bas`/MSXBas2Rom não reconheciam nenhum dos comandos/funções estendidos do
  compilador (`CMD TURBO`, `SCREEN LOAD`, `SET TILE PATTERN`, `HEAP()`, `COLLISION()`, `FILE`/`TEXT`
  etc., extraídos do conteúdo real já baixado em `tools/msxbas2rom/help/`). Três tabelas de palavra-chave
  novas, só consultadas quando a aba está em modo `"BAS"` — de propósito: um programa Dignified comum
  pode ter uma variável chamada `TURBO`, então a extensão não entra nas tabelas globais existentes.
  Validado com harness de console isolado (11 casos, incluindo dois confirmando que essas palavras
  continuam identificador comum fora do modo MSXBas2Rom).
- **2026-08-01 (mesma sessão) — bump de versão para `7.9.1`**: pedido explícito do usuário, fechando
  a sequência de features desta sessão (Renumerar/`RENUM`, integração MSXBas2Rom + N80/LinkStor80/
  LibStor80 com download e Ajuda, destaque de sintaxe estendido) e uma passada de organização na
  documentação — `docs/MANUAL.md` ganhou as seções que faltavam pra essas features (nenhuma delas
  tinha guia de uso até então: pipeline nativo de conversão/tokenização de ASCII clássico, Renumerar,
  Suporte a MSXBAS2ROM, N80/LinkStor80/LibStor80), e um trecho desatualizado (dizia que o motor do
  assembler Z80 "ainda não existe", quando na verdade o resto do próprio manual já documentava o
  assembler nativo em detalhe) foi corrigido. `build.ps1` (`$Version`) e `#App_Version`
  (`editor/BadigEditor.pb`) atualizados juntos, sem codinome novo desta vez.

- **2026-08-04 — `-ss` (strip spaces) removendo bem menos espaços do que deveria**: bug reportado pelo
  usuário — `for linha=0 to 191 step 10` ficava com espaços sobrando em vez de virar
  `forzz=0to191step10`. A reinterpretação pragmática do `-ss` nativo (ver changelog 2026-07-14)
  preservava um espaço entre *qualquer* par de palavras adjacentes, por achar (errado) que era
  necessário pra não gerar `PRINTA` a partir de `PRINT A`. Rastreando o tokenizador de verdade até o
  fim: ele casa palavras-chave em qualquer posição sem exigir fronteira, então `PRINTA` já tokeniza
  certo como `PRINT`+`A` (mesmo truque clássico de `FORI=1TO10` no MSX real) — o risco de verdade é só
  quando colar dois átomos nasce uma palavra-chave **diferente** na fronteira (`X`+`OR`→`XOR`). Corrigido
  com uma checagem de fronteira contra a lista de palavras reservadas, mantendo o espaço só nesse caso.
  Detalhe técnico completo em `docs/SPEC.md`, módulo 3h.
- **2026-08-04 (mesma sessão) — bug real do PureBasic 6.40 instalado, achado verificando a correção
  acima**: `editor/tools/DigTestCli.exe` (harness de regressão) travava (access violation) ao rodar
  contra **qualquer** entrada real, inclusive `sample/teste.dmx` sem tocar em nada — `CopyMap()` num
  mapa vazio de elemento pequeno (`.b()`/`.w()`) trava nesse compilador especificamente; mapas `.i()`/
  `.s()` vazios não têm o problema. `Dig_Keeps()` (controle de toggle-rem) é exatamente esse tipo de
  mapa e começa vazio sempre que o arquivo não usa nenhum `#toggle` — ou seja, o caminho comum. Corrigido
  em `Dig_ProcessSource` só chamando `CopyMap()` quando o mapa de origem não está vazio. Detalhe em
  `docs/SPEC.md`, módulo 3h.
- **2026-08-04 (mesma sessão) — novo menu Inserir → Caractere Especial...**: pedido explícito do
  usuário, um mapa de caracteres estilo Windows pros 159 caracteres que `-tr` traduz pra ASCII nativo
  MSX (`editor/CharMapGui.pbi`, ver "O que já temos" acima para a descrição completa da UI). Construir
  essa feature revelou dois bugs reais e não relacionados entre si em `DignifiedPreprocessor.pbi`,
  ambos afetando `-tr` mesmo sem essa feature nova:
  - **31 símbolos extras (carinhas/naipes/linhas tipo CP437) traduzindo errado**: viravam só uma letra
    solta (`"☺"` → `"A"`) em vez do escape de 2 bytes que o driver de tela do MSX espera (`Chr(1)` +
    letra). Achado comparando byte a byte contra o `badig.py` de referência de verdade (presente no
    repo em `basic-dignified/`) — a causa raiz é que `Chr(1)` é um caractere de controle invisível,
    então sumia sem deixar rastro tanto no Python original quanto neste port, ao serem lidos num
    visualizador de texto normal.
  - **Vários `.pbi` sem BOM UTF-8**: o `pbcompiler.exe` 6.40 instalado detecta a codificação por
    arquivo incluído (não por unidade de compilação inteira) — sem BOM ele decodifica UTF-8 como
    Latin-1, corrompendo qualquer literal não-ASCII. Isso já corrompia **texto de ajuda visível pro
    usuário** antes desta sessão: 121 setas de navegação (`→`) na Ajuda do openMSX e exemplos com
    linhas de caixa na Ajuda do Basic Dignified. Corrigido adicionando BOM a 14 arquivos.
  Detalhe técnico completo (incluindo a lista dos 14 arquivos) em `docs/SPEC.md`, módulo 3h/19.
- **2026-08-04 (sessão seguinte) — continuação da modernização visual ("menos cara de Windows 95")**:
  varredura de padding aplicando a mesma grade de `EditorSettings.pbi` (24px de margem externa, 24px de
  altura de campo, 8px rótulo→campo, ~16-30px entre grupos) a praticamente todos os diálogos restantes
  do editor — `BadigSettings.pbi` (3 abas + diálogo de escolha de máquina/extensão),
  `DiskManagerGui.pbi`, `FontDownloader.pbi`, `N80Support.pbi`, `MsxBas2RomSupport.pbi`,
  `Z80SubProjectGui.pbi`, `Z80OutputGui.pbi`, `Z80LinkGui.pbi`, `Z80LibGui.pbi`,
  `OpenMSXConsoleGui.pbi`, `CharMapGui.pbi`, `MdViewerGui.pbi` e as 5 janelas de Ajuda em árvore
  (Basic Dignified/openMSX/NestorBASIC/MSX BASIC/genérica MD). Ficam de fora, de propósito, os 8
  editores gráficos de canvas (Sprite/Graphos/Screen2/Charset/Aquarela/PSG/MML/Hex) — layout
  fundamentalmente diferente de um formulário, mudança maior e mais arriscada que um ajuste de margem.
  Dois bugs reais encontrados e corrigidos durante a varredura: coordenadas de gadgets dentro de um
  `PanelGadget` são relativas à largura do PRÓPRIO painel, não da janela (um diálogo com abas cortou
  ~40-50px do conteúdo mais à direita até ser corrigido); e um artefato de temporização na técnica de
  screenshot da sessão anterior (`PrintWindow` logo após abrir um diálogo às vezes captura trechos
  inteiros em branco, mesmo com o app renderizando certo por baixo) — corrigido forçando um repaint
  (`RedrawWindow`) antes de capturar.
- **2026-08-04 (mesma sessão) — novo editor de tela Criar → Screen 0...**: pedido explícito do usuário,
  inspirado nos clássicos editores de tela ANSI da era BBS (TheDraw/AcidDraw/DarkDraw) mas adaptado à
  realidade do hardware MSX (`editor/Screen0EditorGui.pbi`, ver "O que já temos" acima pra descrição
  completa). Decisões de design confirmadas com o usuário antes de implementar: cor fiel ao hardware
  (INK/PAPER único pra tela inteira, não por célula) e largura escolhível por tela (40 ou 80 colunas).
  Nova tabela `screen0_screens` em `ProjectDB.pbi`, mesmo padrão de `alphabets`/`screens` já existentes
  — com uma diferença de design real descoberta durante a implementação: a grade guarda o **codepoint
  Unicode** de cada célula (não um byte MSX cru), porque 31 dos 159 caracteres especiais do pipeline
  Dignified (`Dig_TransReplacementOrder` — box-drawing/naipes) só existem via escape de impressão
  `CHR$(1)+CHR$(n)`, não cabem num único byte 0-255 como os outros 128. "Gerar código" emite `PRINT`
  com os glifos Unicode literais direto, deixando a tradução `-tr` já validada resolver pro byte/escape
  nativo MSX na hora de tokenizar — evita ter que calcular endereço de VRAM pro texto em si; só o
  carregador de fonte customizada (quando uma não-padrão é escolhida) precisa do endereço real da
  Pattern Generator Table do SCREEN 0 (`&H0800`, diferente da PGT de SCREEN 1/2 em `&H0000`, endereço de
  hardware não documentado neste repo antes desta sessão). Validado por um harness de auto-teste
  temporário (lógica de moldura/junção via bitmask de 4 direções, sombra, texto, geração de código —
  todos batendo com o esperado) mais screenshot real da janela (grade de caracteres embutida de
  `CharMapGui.pbi`, paletas, abas de ferramenta, sem sobreposição/corte). Versão embutida no executável
  atualizada para `7.10.0`.
- **2026-08-04 (mesma sessão) — Screen 0 WIDTH 80: segunda cor de texto (estática ou piscante),
  ferramenta "Atributo"**: pedido explícito do usuário, que já suspeitava (corretamente) que travar o
  pisca-pisca do modo 80 colunas do MSX2+ dava pra ter 2 cores de texto fixas na tela. Pesquisado a
  fundo antes de implementar (Konamiman MSX2 Technical Handbook + MSX Wiki, ambas já usadas/confiáveis
  neste projeto) em vez de confiar de memória em detalhe de registrador de VDP — confirmado, não é
  folclore: VDP R#12 é um segundo par de cor (BASIC: `VDP(13)=tinta2*16+fundo2`), R#13 controla a
  duração de cada fase do pisca-pisca (BASIC: `VDP(14)=duraçãoNormal*16+duraçãoCor2`, cada unidade
  ~1/6s, até 2.5s por fase — "normal"=0 trava permanentemente na Cor 2), e uma tabela de 240 bytes
  (1 bit/caractere, endereço padrão `&H0800` nesse modo) marca quais células usam o mecanismo. Isso
  revelou um bug real já existente no carregador de fonte customizada: ele sempre usava `&H0800` pra
  Pattern Generator Table, certo só pra 40 colunas — em 80 colunas a PGT padrão é `&H1000` (o `&H0800`
  fica ocupado pela tabela de pisca nesse modo) — corrigido junto. Nova ferramenta **Atributo** (aba a
  mais no editor, 7 no total): clique/arraste liga, botão direito/arraste desliga o atributo de Cor 2
  numa célula, sem mexer no caractere — funciona como uma camada independente. Duas paletas "Cor 2"
  (Tinta2/Fundo2) e dois campos de duração (0-15) somam-se à barra de opções, desabilitados
  automaticamente em telas de 40 colunas (o hardware não tem esse recurso nesse modo). `screen0_screens`
  ganhou 5 colunas novas (`ink2_color`/`paper2_color`/`blink_on_period`/`blink_off_period`/`attr_data`).
  Validado por autoteste temporário (empacotamento de bits do atributo conferido byte a byte contra um
  caso conhecido, valores de `VDP(13)`/`VDP(14)` batendo com o esperado, endereço da PGT saindo certo
  pros dois modos — inclusive a regressão de 40 colunas) mais screenshot real da janela. Versão embutida
  no executável atualizada para `7.11.0`.
- **2026-08-04 (mesma sessão) — reorganização do layout do editor Screen 0**: pedido explícito do
  usuário — a área de edição estava pequena, com todos os controles empilhados numa coluna direita alta
  e um espaço enorme sobrando embaixo do canvas. Canvas dobrado de tamanho (zoom 2→4 em 40 colunas,
  1→2 em 80 — `Scr0Ed_ZoomForWidth`), ferramentas e botões **Injetar/Copiar/Fechar** migraram pra baixo
  do canvas (reaproveitando o espaço que sobrava); só as paletas de cor (Tinta/Fundo/Cor 2) e os campos
  de pisca-pisca continuam na coluna direita, agora bem mais compacta. Verificado por screenshot real.
- **2026-08-04 (mesma sessão) — segundo ajuste de layout do Screen 0: painel de abas menor, grade de
  caractere na coluna direita**: a primeira reorganização deixou o painel de abas (que embutia a grade
  de 159 caracteres da ferramenta Caractere, 544×340px) alto demais, saindo da tela verticalmente.
  Corrigido movendo a grade de caractere pra coluna direita (abaixo da paleta/Cor 2, sempre visível,
  não mais escondida numa aba) — desenhada com célula própria menor (20px, não os 34px originais de
  `CharMapGui.pbi`, `Scr0Ed_DrawCharPicker`) pra caber sem alargar a janela. Sem a grade grande, o
  painel de abas (agora só com texto explicativo em cada aba) encolheu de 420px pra 160px de altura.
  Verificado por screenshot real.
- **2026-08-04 (mesma sessão) — terceiro ajuste de layout do Screen 0: cabe com folga em 1920×1080**:
  usuário reportou que ainda quase não cabia na resolução mínima aceita do projeto (1920×1080). Duas
  mudanças sugeridas pelo próprio usuário: a barra de projeto (número/navegação/tag/Novo/Registrar), que
  ficava acima do canvas, migrou pra baixo da grade de caractere na coluna direita (2 linhas compactas);
  os botões **Injetar no cursor**/**Copiar**/**Fechar**, que ficavam abaixo do painel de abas, migraram
  pro lado dele (empilhados verticalmente à direita, mesma faixa de altura). As duas mudanças juntas
  tiraram a barra de projeto inteira (antes ocupando uma faixa própria no topo) e a faixa de botões
  (antes abaixo do painel) da pilha vertical. Verificado por screenshot real.
- **2026-08-05 — novo editor de tela `Criar → Screen 1...` (`v7.12.0`)**: segunda da família SCREEN 0/1/2
  planejada, mesmo espírito TheDraw/AcidDraw do editor SCREEN 0, mas com a diferença real de cor do
  hardware SCREEN 1 — a Color Table real do TMS9918 guarda 32 pares tinta/fundo, um por **grupo de 8
  códigos de caractere** (endereço padrão `&H2000`, confirmado contra a MSX Wiki antes de escrever
  código), não uma cor única pra tela inteira. A "tabela ASCII do alfabeto" pedida pelo usuário é uma
  grade de 256 células mostrando o bitmap real de cada código da fonte ativa, com o fundo de cada célula
  já pintado na cor do seu octeto — clicar escolhe o byte atual, e as paletas Tinta/Fundo ao lado colorem
  o octeto (8 códigos) daquele byte, refletido ao vivo na tabela e no canvas. Achado real de hardware:
  os 31 caracteres "gráfico" de escape do pipeline Dignified (moldura/naipes/carinhas,
  `Dig_TransReplacementOrder`) são, na verdade, os códigos MSX 1-31 — permitiu guardar a grade como byte
  MSX cru (0-255) em vez de codepoint Unicode como o editor SCREEN 0 faz, e gerar código sem depender da
  tradução `-tr` (literais entre aspas + `CHR$(n)` direto dos bytes). Mesmas 6 ferramentas da primeira
  versão do SCREEN 0 (Texto/Caractere/Quadro/Sombra/Bloco/Borracha). Bug real pego só no screenshot (não
  no harness de lógica pura): `DrawingMode` vazando entre iterações do laço da grade de 256, deixando 255
  das 256 células em branco — corrigido resetando o modo antes de cada glifo.
- **2026-08-05 (mesma sessão) — novo editor de tela `Criar → Screen 1+2...` (`v7.13.0`)**: terceira e mais
  complexa da família SCREEN 0/1/2, pedida explicitamente como "o modo mais complexo". Mesma grade 32×24
  e mesmas 6 ferramentas do editor SCREEN 1, mas gerando `SCREEN 2` de verdade com os dois recursos extras
  do hardware: **3 alfabetos** (um por "terço" de 8 linhas de tela, endereços `Terço*2048`/
  `&H2000+Terço*2048` confirmados contra a MSX Wiki) e **cor por linha de scanline de cada código de
  caractere** (8 cores por glifo, o "color clash" real do SCREEN 2 — toda ocorrência do mesmo código no
  mesmo terço compartilha a mesma cor por linha). Duas decisões de UI confirmadas com o usuário via
  `AskUserQuestion` antes de implementar: o editor de cores por linha abre como janela separada (não
  painel embutido), e o botão de edição em bloco (início/fim) aplica o MESMO padrão de 8 cores a todos os
  códigos do intervalo de uma vez. Reaproveitou direto (sem alteração nenhuma) boa parte do editor SCREEN
  1 — `Scr1Ed_GlyphByteFor`/`StampText`/`DrawBox`/`ApplyShadow`/`FillRect`/`BuildLineExpr` — já que a
  grade e a semântica de byte MSX cru são idênticas; só a renderização/modelo de cor mudou. Aplicando a
  lição do editor SCREEN 1 (bug de `DrawingMode` vazando entre células), a grade de 256 já nasceu
  renderizando certo desde a primeira screenshot. Verificado por harness de auto-teste temporário
  (`--scr12test`, removido) e 2 screenshots reais (janela principal + popup "Cores do caractere..."
  acionado via `SendMessage`/`BM_CLICK` num botão nativo do Win32).
- **2026-08-05 (mesma sessão) — correções de UX e novos recursos no editor Screen 1+2 (`v7.14.0`)**:
  usuário reportou um bug real de UX no editor recém-lançado — colorir um caractere com o seletor
  "Terço" da tabela ASCII num terço não garantia que a cor aparecesse ao carimbar aquele código na área
  real da tela do mesmo terço, porque o seletor nunca teve nenhuma relação com QUAL linha do canvas
  estava sendo tocada, só com o que a tabela mostra (a cor de fato usada sempre vem do terço REAL da
  linha clicada). Corrigido de duas formas (as duas escolhidas pelo usuário via `AskUserQuestion`): uma
  linha-guia preto+branco no canvas marcando os limites de cada terço, e o seletor/tabela ASCII passaram
  a **acompanhar sozinhos** qualquer clique/arraste no canvas (`Scr12Ed_SyncEditThirdToRow`). Na mesma
  sessão, dois pedidos de melhoria: **"Cores em bloco..."** deixou de pedir início/fim num popup
  digitado — agora clica-se o código inicial e final direto na tabela ASCII (marca ciano sutil enquanto
  escolhido, botão direito cancela); e três novos botões **Resetar caractere/Resetar bloco.../Resetar
  TODOS os caracteres do terço** voltam Tinta/Fundo pro padrão (letra branca em fundo preto) no byte
  atual, num intervalo ou nos 256 códigos do terço de uma vez. Verificado com screenshots reais da
  janela completa e do fluxo de escolha de bloco. Versão embutida no executável atualizada para
  `7.14.0`.
- **2026-08-06 — nova Ajuda SEE Tracker, estudo do formato SEE (`v7.15.0`)**: usuário pediu pra ler o
  manual original do **SEE** (`see/SEE3HELP.TXT`) e o driver de replay (`see/SEE3PLAY.ASC`), guardando
  o máximo entendido numa tela de Ajuda nova — preparação para um tracker de SFX nativo compatível com
  `.SEE`, a construir numa sessão futura (`por hora apenas estudo`, nenhum editor/gerador `.SEE`
  implementado ainda). Novo menu **Ajuda → SEE Tracker...** (`editor/SeeTrackerHelpData.pbi`/
  `SeeTrackerHelpGui.pbi`, clone estrutural de `BasicDignifiedHelpGui.pbi`) cobre o manual (telas,
  menus, teclas, os 11 canais de um pattern), o formato binário `.SEE` campo a campo e o mecanismo
  real do driver — lendo o `.ASC` linha a linha (não só o manual) revelou detalhes reais que o manual
  não menciona: os comandos `FOR`/`START` só disparam uma vez (nunca reprocessados nas repetições
  seguintes de um loop — só os dados PSG do pattern são revisitados), o byte de evento só tem 3 bits
  realmente testados pelo player, o bit de "Wave" do volume é literalmente o bit de envelope de
  hardware do próprio PSG, e a fórmula exata de escala por `Max Volume`. Também comparados byte a byte
  (`xxd`) os cabeçalhos dos 4 arquivos `.SEE` de exemplo desta pasta contra o que o manual/driver
  descrevem, com pelo menos uma divergência real deixada como pergunta em aberto (documentada, não
  escondida) para quando a implementação de verdade começar. Versão embutida no executável atualizada
  para `7.15.0`.
- **2026-08-06 (mesma sessão) — usuário insistiu em inferir mais sobre o cabeçalho a partir do driver**:
  rastrear `SEE_IN` (`see/SEE3PLAY.ASC`) byte a byte revelou uma inconsistência real entre a checagem de
  identificação (só 4 bytes) e a cópia dos 4 contadores do cabeçalho, que ficavam encadeadas no arquivo
  original. Testando as duas leituras possíveis contra os 4 `.SEE` reais desta pasta: a leitura "como os
  comentários do próprio driver descrevem" bate perfeitamente nos 4 arquivos (divisão exata, resto
  zero) — resolvendo a dúvida anterior: `$08-$09` é uma constante de capacidade (`$03FF`), não uma
  contagem por arquivo. Achado colateral: os 4 arquivos sobram exatamente os mesmos 1056 bytes no final,
  sugerindo uma área não documentada no manual. Ajuda/SPEC.md atualizados com a correção.
- **2026-08-06 (mesma sessão) — novo editor `Criar → SEE Tracker...` (`v7.16.0`)**: "vamos criar
  Criar->See Tracker". Duas decisões confirmadas via `AskUserQuestion` antes de implementar: grade
  nativa de patterns (não lista de passos) com painel de edição de verdade ao lado, e um **driver de
  replay Z80 nativo embutido** (não só os dados `.SEE`) — a opção mais ambiciosa das duas oferecidas.
  `editor/SeeTrackerDriverAsm.pbi` porta `see/SEE3PLAY.ASC` pro assembler nativo desta IDE (sintaxe de
  hex/rótulos adaptada, checagem de ID desacoplada da cópia do cabeçalho — corrigindo o problema
  encontrado na entrada de changelog anterior —, checagem opcional de overflow via ROM-BIOS removida, e
  um vetor novo `BSETFX` que adapta o argumento de `USR()` pro `SETSFX` cru), montado **em tempo real**
  pelo `Z80Asm::Assemble()` já existente. `editor/SeeTrackerSynth.pbi` interpreta patterns+eventos
  quadro a quadro fiel ao driver (`TEMPO`/`HALT` interagem em dois níveis — achado só visível lendo o
  driver linha a linha) expandindo pra `PsgStepData` e reaproveitando 100% do motor de síntese do editor
  PSG pro preview; monta o blob `.SEE` exato e o código BASIC (`DATA`/`POKE`/`DEFUSR`) prontos.
  `editor/SeeTrackerEditorGui.pbi` é a janela (grade + painel + barra de projeto, mesmo padrão dos
  demais editores) — bateu de novo o gotcha de `Procedure` aninhada (PureBasic não permite), corrigido
  hoisteando as duas procedures de painel pro escopo de arquivo. Verificado por 2 harnesses novos
  (`editor/tools/SeeTrackerDriverTestCli.pb`: 784 bytes montados, os 6 vetores conferidos byte a byte;
  `editor/tools/SeeTrackerSynthTestCli.pb`: 22 asserções sobre `HALT`/`FOR`/`NEXT`/`RERUN`/geração de
  código/formato do blob) e verificação ao vivo na GUI real (Inserir pattern, Gerar código — 5399
  caracteres sem erro —, endereços do clipboard conferidos contra o harness, Tocar num efeito vazio).
  Versão embutida no executável atualizada para `7.16.0`.
- **2026-08-06 (mesma sessão) — Importar .SEE... (`v7.17.0`)**: "Podemos ter uma opção para ler arquivos
  SEE gerados pelo SEE original de MSX?". Três funções novas em `SeeTrackerSynth.pbi`:
  `SeeImp_IsValidHeader` (confere só os 4 bytes `SEE3`), `SeeImp_ListDefinedSfx` (varre os 256 slots da
  tabela de posições procurando o sentinela `$FF` — sem confiar no campo `HISFX`, que já mostrou um
  valor implausível no `QUARTH.SEE` de exemplo) e `SeeImp_ExtractSfxPatterns` (anda sequencialmente a
  partir do pattern inicial até o evento `END`). Botão **Importar .SEE...** na janela abre o arquivo,
  lista os SFX definidos numa janela auxiliar e substitui os patterns do SFX atual pelos importados.
  **Validado contra um arquivo real** (`see/FIREBIRD.SEE`, harness ad-hoc): 33 SFX encontrados, limites
  perfeitamente sequenciais (SFX #0 termina no pattern 7, SFX #1 já começa no 8) e o primeiro efeito
  extraído termina corretamente num `END` real (`$F0`). A automação da sessão não conseguiu dirigir o
  diálogo nativo de abrir arquivo (`BM_CLICK` sintético não entrega a digitação ao `OpenFileRequester`
  do Windows) — sem travar nada (o resto da janela respondeu normal logo depois), só uma limitação da
  automação, não do recurso; a confiança vem do teste direto das funções contra o arquivo real. Versão
  embutida no executável atualizada para `7.17.0`.
- **2026-08-06 (mesma sessão) — correção do "Tocar" no SEE Tracker (`v7.18.0`)**: "quando coloco tocar,
  não está tocando". Causa raiz real, reproduzida ao vivo: `SeeTrackerEditorGui.pbi` nunca chamava
  `InitSound()` (padrão `Global ..._SoundSystemReady.b` já usado por `PsgEditorGui.pbi`/
  `MmlEditorGui.pbi`, mas nunca copiado pra essa janela nova) — sem isso `LoadSound()` falha (devolve 0)
  **silenciosamente**, e como o `G_Play` não tinha `Else` nos 3 pontos onde podia falhar, "Tocar" não
  fazia literalmente nada visível, nem tocar nem avisar erro. Corrigido com o mesmo padrão
  `SeeEd_SoundSystemReady` + mensagens de erro reais nos 3 pontos. **Achado colateral corrigido junto**:
  um SFX novo (1 pattern, evento `END`) mais **Inserir pattern** (sempre inseria DEPOIS do selecionado)
  formava uma armadilha — o primeiro pattern editado ficava depois do `END` inicial, nunca alcançado no
  playback (que sempre começa no pattern 0). Corrigido em duas frentes: SFX novo já nasce com 2 patterns
  (`SeeEd_InitBlankSfx` — um em branco, um com `END` depois), e **Inserir pattern** agora insere ANTES do
  selecionado quando esse tem evento `END`. Terceiro ajuste, de ergonomia (o editor SEE original liga o
  canal implicitamente ao digitar uma frequência — nosso editor exigia marcar "Som" à parte): os campos
  de frequência/volume agora ligam sozinhos o checkbox "Som" daquele canal na primeira vez que o valor
  digitado fica diferente de zero (nunca desliga sozinho). Mensagem de "Nada pra tocar" também ficou
  diagnóstica quando a causa é um `END` no pattern 0. Verificado ao vivo depois da correção — status
  mostra "Reproduzindo..." de verdade, conferido via `GetWindowText` no controle (não só screenshot, que
  se mostrou pouco confiável pra conteúdo de `TextGadget` nesta automação — gotcha novo documentado no
  `docs/SPEC.md`). Versão embutida no executável atualizada para `7.18.0`.
- **2026-08-06 (mesma sessão) — grade do SEE Tracker ilegível, "fundo preto e letras escuras" (`v7.19.0`)**:
  usuário reportou baixo contraste nas linhas com dados da grade. Só foi possível achar a causa real com
  screenshot de verdade (`PrintWindow` + crop/zoom) — pelo código, `SeeEd_DrawGrid` parecia inofensivo
  (`Box()` branco de fundo, depois `DrawText()` colorido por cima). A screenshot mostrou cada valor
  preso numa caixinha preta opaca do tamanho exato do texto: nenhum `DrawText()` da função usava
  `DrawingMode(#PB_2DDrawing_Transparent)`, então o modo padrão pintava um retângulo opaco atrás de cada
  texto com `BackColor()` — nunca setada ali, portanto preta (padrão do PB) — por cima de qualquer fundo
  já desenhado. Presente nos dois temas, mais perceptível no Dark. Corrigido com
  `DrawingMode(#PB_2DDrawing_Transparent)` antes do bloco de `DrawText()` de cada linha. Aproveitado pra
  também tornar a grade sensível a `EditorCfg\Theme` (antes sempre desenhava fundo branco fixo): tema
  Light mantém a paleta original; tema Dark ganhou fundo cinza-azulado bem menos escuro que a janela
  (`RGB(48,51,60)`) com cores de texto claras/vivas (azul, vermelho, âmbar, magenta, quase-branco),
  atendendo ao pedido do usuário ("o fundo pode ser menos escuro e as letras mais brilhosas"). Verificado
  ao vivo nos dois temas via screenshot real antes/depois. Versão embutida no executável atualizada para
  `7.19.0`.
- **2026-08-06 (mesma sessão) — cursor de playback + seletor visual de forma do envelope (`v7.20.0`)**:
  dois pedidos - "faça o tocar mover uma espécie de cursor em cada pattern/linha para visualmente
  podermos ver onde estamos" e "na parte de Forma, você poderia fazer algo visual para podermos ver as
  formas do PSG?". `SeeSynth_Expand()` ganhou um novo parâmetro `List OutPatIdx.i()` (o pattern de
  origem de cada step, em paralelo a `OutSteps()`) - 2 novas asserções no harness conferem os valores
  reais produzidos pelos casos de `HALT`/`FOR`/`NEXT` já existentes, não só que "compila". A grade
  ganhou um `PlayCursor` (borda verde + faixa lateral, independente do realce de seleção) atualizado por
  um timer de 40ms que consulta `GetSoundPosition()` de verdade contra a linha do tempo do efeito, com
  auto-scroll se o cursor sair da área visível. Pro seletor de forma: um preview compacto ao lado do
  campo **Forma** (sempre visível) mais um botão **...** que abre uma grade 4x4 com as 16 formas reais
  do envelope do PSG (curva + rótulo hex), clicar já escolhe. Ambas as curvas reaproveitam
  `PsgSynth_ApplyEnvShape`/`PsgSynth_EnvTick` (o MESMO gerador usado na síntese de verdade), garantindo
  fidelidade ao som real. **Verificado ao vivo com screenshots reais**: as 16 formas batem exatamente
  com a tabela padrão do AY-3-8910/YM2149; o cursor de playback foi testado em duas configurações
  diferentes (dados no pattern 1, depois movidos pro pattern 0 via "Mover p/ cima") e apareceu na linha
  correta nas duas vezes, sumindo sozinho ao fim natural da reprodução. Versão embutida no executável
  atualizada para `7.20.0`.
- **2026-08-06 (mesma sessão) — Limpar / Limpar linha / Limpar bloco (`v7.21.0`)**: "crie um botão limpar
  para limpar totalmente os padrões já inseridos, e um botão para limpar uma linha em particular, e outro
  para limpar um bloco". Três botões novos numa linha própria no SEE Tracker: **Limpar** (volta ao estado
  inicial - 1 pattern em branco + `END` - mas mantém o número/tag do SFX, diferente de "Novo"; pede
  confirmação se houver alterações não registradas, mesmo padrão já usado por "Novo"/navegação de SFX)
  **Limpar linha** (zera os 15 bytes do pattern selecionado sem remover a linha, diferente de "Apagar
  pattern") e **Limpar bloco** (janela nova pedindo um intervalo De/Até, pré-preenchido com o pattern
  selecionado, zera todos daquele intervalo de uma vez - a própria janela já serve de confirmação).
  Nenhum dos três remove nenhuma linha da lista, só zeram dados no lugar. Verificado ao vivo via
  screenshot: inseridos patterns extras, "Limpar bloco" com intervalo 0-2 zerou os três numa tacada
  (inclusive um pattern `END`, sem quebrar nada - o motor já trata "sem `END` nenhum" como fim implícito),
  e "Limpar" mostrou a confirmação e voltou exatamente ao estado inicial ao confirmar. Versão embutida no
  executável atualizada para `7.21.0`.
- **2026-08-06 (mesma sessão) — cabeçalho da grade desalinhado (`v7.21.1`)**: "os títulos das colunas #,
  Evt, Snd1... está desalinhado com as colunas". Causa: o cabeçalho era um `TextGadget` com texto
  espaçado à mão numa fonte proporcional, nunca garantido bater com os offsets em pixel que
  `SeeEd_DrawGrid()` usa pra desenhar as colunas de dados. Trocado por um `CanvasGadget` desenhado uma
  vez (`SeeEd_DrawHeader()`) usando os MESMOS `#SeeEd_GridColXxx` e preenchimento de cada célula que a
  grade já usa - alinhamento garantido por construção. Verificado ao vivo via screenshot com zoom: cada
  rótulo cai exatamente sobre sua coluna. Versão embutida no executável atualizada para `7.21.1`.
- **2026-08-07 — Editor Hexa: mais formatos reconhecidos (`v7.22.0`)**: usuário pediu pra ampliar o
  reconhecimento de formato do módulo 17 (`editor/HexEditorGui.pbi`) além dos três nativos da IDE.
  Implementado: **executável MSX-DOS `.COM`** (extensão checada antes dos bytes mágicos `FEh`/`FFh` —
  código Z80 cru sem cabeçalho, convenção CP/M, carrega e executa sempre em `0100h`, então o primeiro
  byte real do programa poderia bater por coincidência com um cabeçalho BLOAD/BSAVE ou tokenizado se a
  extensão não fosse checada primeiro); e **texto ASCII puro vs. BASIC MSX clássico numerado**
  (`HexEd_LooksLikeBasicSource` — olha só o primeiro caractere visível do arquivo, dígito = linha
  numerada, mesma regra que o tokenizador exige de entrada). Pedido também incluía WordStar, MSX-Word,
  SuperCalc II e dBase II — **não implementados nesta sessão**: nenhum tem cabeçalho/layout binário
  confirmado a partir daqui (WordStar historicamente só liga o 8º bit no último caractere de cada
  palavra, sem cabeçalho fixo — heurística arriscada sem arquivo real pra validar; os outros três não
  têm formato documentado neste repositório), então ficaram como pendência aguardando arquivos de
  exemplo reais do usuário pra estudar antes de cravar qualquer detecção binária, mesmo padrão de
  trabalho já usado em `MSXDisk.pbi`/`GraphosNativeIO.pbi`/SEE Tracker. Ver módulo 17 em `docs/SPEC.md`.
  Versão embutida no executável atualizada para `7.22.0`.
- **2026-08-07 (mesma sessão) — Editor Hexa reconhece SuperCalc 2 MSX `.CAL` (`v7.23.0`)**: usuário
  forneceu `sc2/` (projeto Go pessoal dele, `sc2msx`, reescrita do SuperCalc 2) e 5 planilhas `.CAL`
  reais (`sc2/msx/*.CAL`) pra atacar a pendência de SuperCalc II deixada na entrada anterior. Achado
  que destravou o estudo sem precisar de emulador: o disco original `supercalc2L.dsk` tinha
  `EXEMPLO.CAL` **e** `EXEMPLO.SDI` (o formato texto intermediário) lado a lado — um par binário/texto
  verdadeiro, extraído com a própria `--diskmanipulator` desta IDE. Cruzando esse par com os outros 5
  `.CAL`, confirmado: assinatura de 22 bytes `"SuperCalc ver.  1.00\r\n"`, campo de título de 80 bytes
  em `000016h`, cabeçalho de tamanho fixo com a seção de dados sempre começando em `000300h` —
  validado contra os 6 arquivos reais via harness descartável antes de integrar. O layout célula a
  célula dentro da seção de dados ainda não foi decifrado (fica documentado como próximo passo em
  `docs/reference/supercalc2-cal-format.md`, novo arquivo). Achado colateral: `sc2/msx/msxdos1.dsk` tem
  `PESSOAL.DBF`, amostra real de dBase II pra quando essa pendência for atacada. Versão embutida no
  executável atualizada para `7.23.0`.
- **2026-08-07 (mesma sessão) — Editor Hexa reconhece dBase II `.DBF` (`v7.24.0`)**: usuário pediu pra
  aproveitar o achado colateral da entrada anterior (`PESSOAL.DBF`, de `sc2/msx/msxdos1.dsk`) e adicionar
  `.gitignore` pra `sc2/` (software original de terceiros, mesmo padrão já usado pra `see/`). Diferente
  do SuperCalc 2, o dBase II saiu **totalmente decifrado** — não só reconhecido: cabeçalho (versão,
  número de registros, tamanho do registro), descritores de campo (nome/tipo/tamanho, 16 bytes cada,
  até 32, terminados em `0Dh`) e os próprios registros de dados, validados um a um contra um harness
  descartável que reconstituiu os 6 registros reais do arquivo (nome/cargo/salário/data de admissão de 6
  funcionários) e bateu exatamente com o hexdump. Achado notável: dados sempre começam no offset fixo
  `000209h` (`8 + 32×16 + 1`) — o formato reserva espaço pra até 32 campos mesmo quando poucos estão em
  uso, e o mesmo byte `1Ah` de fim-de-arquivo do CP/M que já apareceu no `.CAL` do SuperCalc 2 marca o
  fim dos dados aqui também. Notas completas em `docs/reference/dbase2-dbf-format.md` (novo arquivo).
  Versão embutida no executável atualizada para `7.24.0`.
- **2026-08-07 (mesma sessão) — Editor Hexa reconhece os 4 formatos nativos do Graphos III (`v7.25.0`)**:
  usuário perguntou se dava pra identificar Tela/Alfabeto/Shape/Layout do Graphos III (`.SCR`/`.ALF`/
  `.SHP`/`.LAY`) usando o material de `graphos/`/`graphos-IV/` já no repositório. Diferente do SuperCalc
  2/dBase II, esses formatos já estavam **totalmente documentados** de uma sessão anterior
  (`editor/GraphosNativeIO.pbi`, módulo 14i) — só precisou portar o conhecimento já validado, não
  decifrar do zero. Validado em lote contra **todos os arquivos reais do repositório** (~4100 arquivos
  entre `graphos/` e `graphos-IV/`, não só uma amostra pequena): `.LAY` 234/234 (100%, decodifica o
  RLE+ofuscação de verdade e confere 6144 bytes exatos — achou e corrigiu um bug real no decodificador
  nesse processo), `.SCR` 86/86 (100%), `.ALF` 759/781 (97% — validação em lote revelou que o endereço
  de início nem sempre é `9200h` e que uma minoria real usa uma convenção de "fim exclusivo" no
  cabeçalho, ambos agora tolerados), `.SHP` 2920/3028 (96% — esse é o ganho real, não tinha NENHUM
  reconhecimento antes por não ter cabeçalho BLOAD/BSAVE; percorre a cadeia de blocos inteira até o
  terminador `FFh`, sem nenhum falso positivo encontrado nas falhas investigadas). Versão embutida no
  executável atualizada para `7.25.0`.
- **2026-08-07 (mesma sessão) — codinome `HEXORCIST` pra `7.25.0`, documentação consolidada e
  `RELEASE_NOTES.md`**: pedido explícito do usuário pra revisar toda a documentação da sessão (esta
  sessão inteira girou em torno do Editor Hexa aprendendo a reconhecer formato atrás de formato — `.COM`,
  `.CAL`, `.DBF`, `.ALF`/`.LAY`/`.SCR`/`.SHP`), consolidar o que já é identificado hoje no `docs/SPEC.md`
  (módulo 17 ganhou uma tabela única com todos os formatos + nível de confiança de cada um, em vez de só
  parágrafos cronológicos espalhados) e gerar `docs/RELEASE_NOTES.md` com notas de lançamento formais
  desta versão. Codinome escolhido seguindo o mesmo espírito de `BFG9200` (7.7.1): **"HEXORCIST"** — Hex
  (do Editor Hexa) + Exorcist, porque a sessão inteira foi literalmente sobre "esconjurar" arquivos
  binários que antes caíam em "dados crus"/fantasmas sem nome, dando um formato e um nome de verdade pra
  cada um. Sem mudança de código nesta entrada — só documentação.
- **2026-08-08 — painel de controle do openMSX com 6 abas, F5 unificado com o console, codinome
  `TORRE DE CONTROLE` (`7.27.3`)**: sessão pedida pelo usuário pra transformar o controle remoto do
  openMSX (até então um console de comando avulso) num painel completo. **`Executar → BASIC` (F5) parou
  de abrir uma janela nova do openMSX a cada execução** — `RunOnOpenMSX()` passou a chamar
  `OMSX_LoadDisk()` (novo, `OpenMSXBridge.pbi`), que reaproveita a instância já aberta (troca o disco +
  reset) em vez de lançar um processo novo, unificando o que antes eram dois fluxos deliberadamente
  separados. Nova tela `Configurar → openMSX...` com os mesmos campos da aba "Emulador" de
  `Configurar → Basic Dignified...`, compartilhando os mesmos 4 procedimentos de gadget pra nunca
  divergir. `Executar → openMSX...` virou um `PanelGadget` de 6 abas — Console, Outros comandos
  (velocidade com Turbo segurando o mouse, Power/Reset/Pause, firmware, portas de joystick, Ren Sha
  Turbo), Vídeo (renderer/escala/Modo TV com as 5 opções reais do openMSX, efeitos estilo CRT com
  reset pro padrão de fábrica real, screenshot com numeração sequencial, LEDs + STOP + FPS), Volume
  (mixer com **descoberta dinâmica de dispositivo de som** — os nomes reais variam por cartucho/ROM
  conectado, confirmado ao vivo contra um openMSX de verdade antes de implementar, ex.
  `"Konami SCC+ Cartridge with expanded RAM (1)"` —, MIDI in/out), Input Text (área grande + Type/
  Clear) e Status Info (log passivo de tudo que o openMSX reporta). Detalhe completo em
  `docs/RELEASE_NOTES.md` e `docs/SPEC.md` (módulo 12). Codinome **"TORRE DE CONTROLE"** — o usuário
  escolheu entre algumas opções temáticas de "sala de controle" propostas.
- **2026-08-08 (mesma sessão) — auto completar + Arquivo → Salvar Tudo, codinome `PALPITEIRO`
  (`7.29.5`)**: pedido do usuário em três rodadas. Primeiro, **auto completar em abas MSX-BASIC/
  Dignified**: mostra sugestões (palavras-chave clássicas, instruções do Basic Dignified e variáveis já
  usadas no documento, coletadas ao vivo do texto) assim que a palavra digitada atinge um mínimo de
  letras configurável, com uma tela nova `Configurar → Basic Options...` (habilitar, mínimo de letras,
  caixa das sugestões). Navegação inteira é comportamento nativo do popup do Scintilla (Enter aceita a
  primeira opção, setas navegam, Esc cancela) — nenhuma tecla nova precisou ser interceptada, e não há
  conflito com o teclado WordStar/JOE (que só intercepta combinações com Ctrl). Segundo, o usuário
  perguntou se dava pra detectar estatisticamente se o usuário digita em maiúsculas ou minúsculas; a
  alternativa escolhida foi um campo de configuração explícito ("Como digitado"/"Sempre maiúsculas"/
  "Sempre minúsculas") em vez de heurística sobre o documento inteiro — mais previsível, e "Como
  digitado" já cobre o caso comum (`pri` sugere `print`, `PRI` sugere `PRINT`) sem precisar escanear
  nada. Terceiro, dois pedidos numa mensagem só: **os 87 wrappers `.NB_*` do NestorBASIC** entraram na
  lista de sugestões (fonte única com `Ajuda → NestorBASIC...`, via `NBHelp_Topics()\Wrapper` — nunca
  diverge da ajuda), e **auto completar chegou também nas abas Assembly (`.asm`)** — mnemônicos/
  registradores/diretivas do Z80 (`Z80Asm.pbi` ganhou `MnemonicList()`/`RegisterList()`/
  `DirectiveList()`/`OperatorWordList()`, expondo pra fora do módulo o vocabulário que já alimentava o
  destaque de sintaxe) e rótulos já definidos no documento (mesma regra clássica MACRO-80/Z80 do
  highlighter: primeira palavra da linha que não é reservada = rótulo), com tela própria
  `Configurar → Assembly...` (mesmos três campos de `Basic Options...`, mas independente — cada modo
  guarda sua própria preferência de caixa). Por último, **Arquivo → Salvar Tudo** (`Ctrl+Alt+S`): salva
  todas as abas abertas (na ordem, pedindo "Salvar como..." só pras que ainda não têm nome, sem travar
  as demais se uma for cancelada) e o projeto atual numa ação só — só grava o projeto se ele já tiver
  arquivo permanente ou se o projeto temporário tiver conteúdo de verdade (mesmo critério de
  `OfferSaveProject()`, mas sem o diálogo de confirmação — pedir "Salvar Tudo" já é a confirmação).
  Codinome **"PALPITEIRO"** — gíria brasileira pra quem "dá palpite" sem ser convidado, exatamente o que
  um motor de auto completar faz (e de bom humor, já que ele acerta na maioria das vezes). Detalhe
  completo em `docs/RELEASE_NOTES.md` e `docs/SPEC.md` (módulo 25, mais 1b para o Salvar Tudo).
- **2026-08-08 (mesma sessão) — fim do teclado WordStar/JOE, codinome `APOSENTADORIA` (`7.31.0`)**:
  usuário pediu pra trocar o jeito de digitar do editor principal pelo padrão Scintilla/Windows (setas,
  `Ctrl+C/V/X/Z/Y`, `Home`/`End` etc.) — não usa mais WordStar/JOE/vim no dia a dia, prefere
  Helix/JetBrains/VSCode/Sublime/010 Editor. `editor/WordStarKeys.pbi` (subclass Win32, comandos de
  duas teclas, bloco marcado com destaque persistente, tela de ajuda em tela cheia) foi removido por
  completo, não só desligado por padrão. As únicas peças do modo antigo sem equivalente automático no
  Scintilla puro — Buscar, Buscar próxima, Substituir, Ir para linha — viraram um arquivo novo e
  portátil (`editor/EditorSearch.pbi`) com atalhos convencionais (`Ctrl+F`/`F3`/`Ctrl+H`/`Ctrl+G`,
  também no novo menu **Editar**). Arquivo/aba voltaram ao padrão (`Ctrl+N` novo, `Ctrl+S` salva,
  `Ctrl+W` fecha aba). `Ajuda → Editor...` (`editor/EditorHelpGui.pbi`) troca a antiga tela cheia por
  uma janela normal com a referência de atalhos, reaproveitando o motor de markdown de
  `GenericMdHelpGui.pbi`. Detalhe completo em `docs/RELEASE_NOTES.md`.
- **2026-08-08 (mesma sessão) — atalhos pro resto da IDE, codinome `ATALHO DE TUDO` (`7.31.1`)**:
  usuário pediu atalhos pras outras funções do editor pra não ficar preso navegando menu — 22 novos:
  `Ctrl+Alt+N`/`Ctrl+Alt+O` novo/abrir projeto; `Ctrl+Alt+I` caractere especial; `Ctrl+Alt+E`
  Configurar → Editor...; no menu **Executar**, `Shift+F5` Nestor Basic, `F6` renumerar,
  `Ctrl+Shift+F5` montar relocável, `Ctrl+Alt+F5` linkar, `F7` Editor Hexa, `F8` console openMSX,
  `F9`/`Shift+F9` ver MD/TXT; no menu **Criar**, `Ctrl+Shift+D` disco, `Ctrl+Shift+P` sprite,
  `Ctrl+Shift+A` alfabeto Graphos III, `Ctrl+Shift+G` som PSG, `Ctrl+Shift+T` SEE Tracker,
  `Ctrl+Shift+M` música, `Ctrl+Shift+2`/`0`/`1` Draw Screen 2/Screen 0/Screen 1; e `F1` abre
  `Ajuda → Editor...` (convenção universal de ajuda). Os itens menos usados do menu **Criar**
  (Alfabeto Aquarela, Graphos III Screen 2, Screen 1+2, Biblioteca Z80, Assembly Sub Project)
  ficaram só no menu — não valia um 3º/4º modificador só pra caber mais uma tecla. `Ajuda →
  Editor...` (`F1`) ganhou as seções novas e a janela cresceu (`680×760`). Detalhe completo em
  `docs/RELEASE_NOTES.md`.
- **2026-08-08 (mesma sessão) — de 2 pra 7 temas, codinome `CAMALEÃO` (`7.31.2`)**: usuário achou
  os temas Escuro/Claro atuais feios e pediu variações mais atraentes (azul escuro, rosa,
  vermelho, verde, bege). Paletas desenhadas e aprovadas num mockup HTML fora do PureBasic antes
  de virar código (iterar cor em CSS é muito mais rápido que recompilar o app a cada ajuste).
  Resultado: **Configurar → Editor...** agora tem 7 opções — **Grafite**/**Neve** (revisão dos
  dois atuais) mais **Azul Profundo** (Night Owl/Nord), **Rosé** (Rosé Pine), **Carmesim**
  (oxblood), **Floresta** (Everforest) e **Bege** (Solarized Light). `EditorCfg\Theme` virou um
  dos 7 IDs em vez de um booleano Dark/Light; `editor_settings.json` antigo migra sozinho. Também
  investigado (e documentado, sem implementar ainda): as outras janelas (SEE Tracker, editores de
  Alfabeto/Sprite/Som/Telas) usam cores próprias fixas e controles nativos do Windows — estender
  tema pra elas é um projeto à parte, arquivo por arquivo, separando cor de "chrome" de cor de
  "conteúdo" (ex.: paleta MSX real não pode mudar com o tema). Detalhe completo em
  `docs/RELEASE_NOTES.md`.
- **2026-08-08 (mesma sessão) — botões tematizados + ícones Nerd Font, codinome `NERD DE VERDADE`
  (`7.31.3`)**: usuário reclamou que os diálogos ainda pareciam "Windows 3.1" mesmo com os 7 temas
  — "aquele mar de botões cinza que estragam a aparência" (botão nativo do Windows ignora
  `Color_*`). Piloto no **Editor Hexa** (`F7`): os 16 botões da janela viraram imagens desenhadas
  na hora (fundo + borda na cor do tema, texto centralizado) em vez de chrome nativo. Usuário
  também pediu pra reaproveitar fontes `.ttf` baixadas/instaladas na interface, e ícones de verdade
  em vez de "ícones genéricos desenhados desleixadamente" — resultado: os botões já usam a mesma
  fonte escolhida em **Configurar → Editor...** em vez de "Segoe UI" fixo, e um novo combo **Fonte
  de ícones** (mesma tela) troca o texto dos botões por glifos reais de uma Nerd Font quando
  configurado (com tooltip mostrando o nome ao passar o mouse; sem fonte escolhida, continua
  mostrando texto normalmente). Os 15 codepoints usados foram conferidos ao vivo contra o
  `glyphnames.json` oficial do projeto Nerd Fonts antes de entrar no código — achado real no
  processo: um resumo de IA de uma busca web errou um codepoint (`fa-plus_square` como `U+F055` em
  vez do `U+F0FE` real), só pego porque o JSON bruto foi conferido depois. Vale só pro Editor Hexa
  por enquanto; as outras ~10 janelas de diálogo ficam pra uma próxima rodada. Detalhe completo em
  `docs/RELEASE_NOTES.md`.
- **2026-08-08 (mesma sessão) — o mesmo formato de botão em toda a IDE, codinome `ADEUS WINDOWS
  3.1` (`7.31.4`)**: usuário gostou do piloto no Editor Hexa e pediu pra replicar em todos os
  diálogos/módulos. 293 botões em 33 arquivos convertidos numa sessão só (267 mecanicamente de
  `ButtonGadget`→`ThemedButton`, mais de 140 deles ganhando ícone Nerd Font verificado e tooltip),
  40 janelas ganharam `SetWindowColor(Win, Color_AppBg)` (antes ficavam brancas/cinzas nativas
  destoando do editor tematizado). O que nasceu específico do Editor Hexa (`HexEd_*`, `7.31.3`)
  virou `editor/ThemedButtons.pbi` — módulo compartilhado (`Macro ThemedButton()`, constantes
  `#Icon_*`) usado por todos os 33 arquivos, incluindo o próprio Editor Hexa migrado pra ele (sem
  duplicar código). Achado real de arquitetura no processo: quase todos os diálogos são incluídos
  bem no topo de `BadigEditor.pb`, antes de `Global Color_*`/`Structure EditorSettings` existirem
  (`EnableExplicit` + `XIncludeFile` textual exige declaração antes do uso) — resolvido movendo só
  essas poucas linhas de `Structure`/`Global` pro topo do arquivo, mesmo idioma dos `Declare` de
  procedure que já ficavam lá por motivo parecido, sem precisar reordenar os 33 `XIncludeFile`
  existentes. Nenhuma das ~400 edições foi manual — três scripts Python descartáveis (parsing de
  parênteses balanceados, não regex ingênuo) fizeram a conversão mecânica, com recompilação a cada
  rodada pra pegar erro cedo. Detalhe completo em `docs/RELEASE_NOTES.md`.
- **2026-08-09 — revisão geral: bugs, coesão de módulos, performance e temas, codinome `PENTE FINO`
  (`7.33.1`)**: sessão de
  auditoria ampla (7 revisões paralelas por área do código) seguida de correção. 8 bugs reais
  corrigidos, entre eles: fechar uma aba não-ativa trocava o documento visível errado; vazamento de
  handles GDI em dois editores gráficos; `ProjectDB::SaveAs` podia abandonar o projeto silenciosamente
  se o reabrir falhasse; `MSXDisk::ExtractFile` reportava sucesso numa extração truncada; downloads
  parciais deixavam lixo no diretório temporário; vazamento de buffer em `Z80Lib::CreateOrAddLibrary`;
  thread do pipe do openMSX nunca fechada; loop labels aninhados sem limite no pré-processador podiam
  corromper heap. Coesão: helper de janela compartilhado (`OpenModelessChildWindow`/
  `CloseModelessChildWindow`) extraído e migrado em 35 arquivos, ~150 linhas de boilerplate repetido a
  menos; hit-test de paleta e `FontDownloader` desduplicados. Performance: tokenizer deixou de ser
  O(n²) por linha; redraw de glifo em Screen0/1/12 e o redraw do Graphos/Screen2 otimizados. **Achado
  maior da sessão**: os 7 temas (desde `7.31.2`) tinham o modo escuro nativo do Windows sempre
  desligado — 8 pontos comparavam contra um `"Dark"` legado que a própria migração pros 7 temas já
  tornava inatingível, deixando barra de título/rótulos/campos de texto sempre com chrome nativo claro
  do Windows, mesmo nos 5 temas escuros. Corrigido com `EditorCfg_ThemeIsDark()` (`EditorSettings.pbi`)
  e tratamento de `WM_CTLCOLORSTATIC` (rótulos ficavam sem essa cobertura desde sempre, achado
  documentado como "abandonado" no próprio código) — confirmado com screenshot real da IDE rodando
  contra um tema escuro, não só leitura de código.
- **2026-08-09 (mesma sessão) — `Configurar → MSXBas2Rom...` redesenhada (`7.33.2`)**: pedido explícito
  do usuário — reforçou que o `msxbas2rom` nunca é incorporado ao projeto, é sempre um `.exe` externo
  chamado por caminho. O único botão "Baixar" (que baixava executável + Ajuda juntos) virou três
  controles independentes: **"Baixar versão mais recente"** (`MsxBas2Rom_DownloadExe()`) baixa só o
  executável da release mais atual do GitHub pra `tools/msxbas2rom/` (subpasta da instalação do
  msxbasica); um **campo de caminho editável** com botão "..." cobre o caso de o usuário já ter o
  `msxbas2rom` instalado em outro lugar, pré-preenchido com o local onde a IDE baixou (ou, se ainda
  vazio, com o resultado de uma busca na pasta padrão) e só persistido no `Salvar`/`Cancelar` da janela;
  e **"Atualizar documentação"** é por ora um placeholder proposital que só mostra uma mensagem de
  status — a geração de Ajuda a partir da wiki oficial (extraída do botão único antigo) fica pro próximo
  passo.
- **2026-08-09 (mesma sessão) — "Atualizar documentação" implementado, guia de referência prático
  (`7.33.3`)**: pedido explícito do usuário — baixar o conteúdo de
  `github.com/amaurycarvalho/msxbas2rom/wiki/Documentation` e estruturar dentro de **Ajuda →
  MSXBas2Rom...** com a mesma organização da wiki real do projeto. Clonei
  `amaurycarvalho/msxbas2rom.wiki.git` pra ler a estrutura de verdade em vez de adivinhar: `Home.md`
  (tabela "Quick Reference") e `Documentation.md` (hub "Reference Guide", 12 sub-páginas) definiram os
  três grupos baixados — **Primeiros passos** (visão geral/instalação/primeiros passos/uso), **Guia de
  referência** (as 12 páginas do hub: limitações de compilação, diretivas de recursos, comandos/funções
  estendidos, suporte a música/MTF/nMSXTiles/Tiny Sprite, integração VSCode + manual de configuração
  manual, depuração com openMSX, arquitetura do compilador, como obter ajuda) e **Exemplos** — 19
  páginas no total, mais o `-h` do executável configurado. `Games`/`Contributing`/`Branding` ficaram de
  fora de propósito (conteúdo de comunidade/créditos, não guia de uso do dialeto, conforme pedido do
  usuário). Bug em potencial evitado antes de acontecer: links internos da wiki (`[Instalação](Install)`,
  forma normal de link relativo entre páginas do GitHub) são reescritos pra URL absoluta
  (`MsxBas2Rom_RewriteWikiLinks()`) antes de salvar — sem isso, o clique (que a janela de Ajuda genérica
  manda cru pro `explorer.exe`) tentaria abrir um arquivo local inexistente em vez da página real,
  inclusive pras páginas propositalmente não baixadas.
- **2026-08-09 (mesma sessão) — fonte grande/desalinhada em TODA janela de Ajuda (`7.33.4`)**: bug
  reportado pelo usuário testando a nova Ajuda do MSXBas2Rom ("a fonte do HELP está muito grande, o
  texto aparece desalinhado, quebra em linhas desconexas") — mas a causa era comum às **8** janelas de
  Ajuda da IDE, não só a nova. `NBHelpGui_SetupStyles()`/`GenMdHelp_SetupStyles()` (as duas bases
  compartilhadas por Nestor Basic/MSX BASIC/Basic Dignified/SEE Tracker/openMSX/Editor/MD Viewer/
  MSXBas2Rom+N80) renderizavam o corpo do texto (prosa) com a fonte do **editor de código** do usuário
  (`EditorCfg\FontName`/`FontSize`) — tipicamente monoespaçada por design, o que faz prosa parecer maior
  do que o tamanho configurado e quebrar linha (`SC_WRAP_WORD`) com muita mais frequência do que uma
  fonte proporcional do mesmo tamanho nominal. Só ficou óbvio agora porque o conteúdo baixado da wiki
  tem parágrafos de prosa de verdade, ao contrário da maioria dos outros Helps (escritos à mão, já mais
  compactos). Corrigido com Segoe UI 10pt fixo pro corpo do texto no Windows (desacoplado do
  `EditorCfg` do usuário), mesmo "toque moderno" já usado nos controles nativos de toda janela
  secundária (`App_ApplyWindowIcon()`).
- **2026-08-10 — cor própria pro vocabulário estendido do MSXBAS2ROM (`7.33.6`)**: pedido explícito do
  usuário — o destaque de sintaxe do MSXBAS2ROM (implementado em `2026-08-01`) reaproveitava as cores
  já existentes de statement/função/diretiva do MSX-BASIC/Dignified; agora as 3 categorias (`CMD
  TURBO`, `HEAP()`, `FILE`/`TEXT`...) caem todas na MESMA cor nova (`#Style_MsxBas2Rom`, negrito),
  numa família teal/ciano ajustada em cada um dos 7 temas pra não repetir nenhuma cor de sintaxe já
  usada. Só a cor mudou, o vocabulário reconhecido é o mesmo de antes. Pedido do usuário também deixou
  registrado o próximo passo (bem mais complexo, de propósito adiado): fazer o pré-processador Basic
  Dignified reconhecer as palavras-chave do MSXBAS2ROM como tal, em vez de deixá-las livres pra virar
  nome de variável.
- **2026-08-09 (mesma sessão) — exemplos reais de código em Ajuda → MSXBas2Rom..., codinome
  `BIBLIOTECA` (`7.33.5`)**: pedido explícito do usuário — baixar a pasta `demo/` oficial do
  `amaurycarvalho/msxbas2rom` (link direto `.../tree/master/demo`) e, se possível, também os jogos
  completos de `amaurycarvalho/msxbasic`, pro disco, navegáveis/legíveis dentro do Ajuda como exemplos
  de programação reais. Dois botões novos: **"Baixar exemplos (demo)"** baixa só a pasta `demo/` (zip
  do repositório inteiro filtrado por prefixo antes de extrair — código C++ do compilador nem chega a
  tocar o disco) pra `tools/msxbas2rom/demo/`; **"Baixar jogos completos"** baixa
  `amaurycarvalho/msxbasic` inteiro (zip pequeno, ~2,4 MB) pra `tools/msxbas2rom/games/` — 10 jogos MSX
  BASIC completos, cada um com seu próprio `README.md`. Ambos baixam TODOS os arquivos (imagens, ROMs,
  sprites, música), mas só `.bas`/`.md` entram na árvore de Ajuda, um grupo por pasta de jogo/demo
  (`"Demo: scroll1"`, `"Jogo: Fortknox"`...), preservando a estrutura real dos repositórios. Validei o
  algoritmo (extração filtrada + varredura recursiva) contra os zips reais dos dois repositórios num
  harness isolado antes de integrar: 81 arquivos/12 tópicos pro `demo/`, 317 arquivos/23 tópicos pro
  `msxbasic`, casos de borda conferidos (jogo sem `README.md`, arquivo `.bas` dentro de subpasta,
  extensão `.BAS` maiúscula). Abrir um `.bas` na Ajuda não passa mais pelo parser de markdown — um
  despachante novo (`GenMdHelp_RenderTopic()`) decide pela extensão e mostra código real verbatim
  (`GenMdHelp_RenderPlainCode()`), já que BASIC usa `**`/`` ` ``/`[]()` legitimamente e o parser de
  markdown corromperia a exibição. Três botões diferentes agora gravam tópicos no mesmo índice de Ajuda
  (`Atualizar documentação`/`Baixar exemplos`/`Baixar jogos`) sem se atropelarem
  (`GenMdHelp_MergeIndex()` — cada download só substitui os grupos que ele mesmo gera).
- **2026-08-10 — motor Dignified com modo MSXBAS2ROM, compilação pra ROM e config por projeto
  (`7.33.7`)**: pedido explícito do usuário — programas MSXBAS2ROM escritos em Dignified (labels,
  `DEFINE`, `FUNC`/`RET`) agora protegem o vocabulário exclusivo (`FILE`/`TEXT`, sub-comandos de `CMD`/
  `SET`/`GET`, `HEAP()`/`TILE()`/`TURBO()`...) contra o encurtamento automático de variáveis — antes,
  usar essas palavras como identificador virava candidato a renomeio (`TURBO` → `ZX`), corrompendo o
  programa. Decisão confirmada com o usuário: em vez de duplicar o motor Dignified inteiro (~2500 linhas
  testadas) num arquivo separado, ele ganhou um **modo** (`Dig_Preprocess(..., IsMsxBas2Rom)`) que
  reaproveita os mesmos 3 mapas de vocabulário já usados pelo destaque de sintaxe. `FILE`/`TEXT` (diretivas
  de recurso, confirmado na documentação oficial) saem sem número de linha, preservando a ordem que
  define o índice do recurso. Validado com um teste isolado: em modo clássico, `FILE`/`TURBO`/`HEAP`
  saíam renomeados e corrompiam o programa (bug real, confirmado); em modo novo, saem intactos. Novo
  **Executar → Compilar ROM (MSXBas2Rom)...** gera o `.bas` e chama o `msxbas2rom.exe` configurado de
  verdade (nenhum caminho existia antes pra isso — só o downloader). Também, pedido do usuário: nova
  **Configurar → Projeto...**, permitindo que Basic Dignified/N80/MSXBas2Rom usem uma configuração
  própria de cada projeto em vez da global — sem duplicar nenhuma das 3 telas existentes, só um
  parâmetro novo (`OverridePath`) que redireciona onde cada uma lê/grava.
- **2026-08-10 (mesma sessão) — projeto `.msxproject` autocontido/portátil (`7.33.8`)**: pedido explícito
  do usuário — levar só o arquivo de projeto de um PC pro outro e os fontes BASIC/Assembly "irem junto".
  O `.msxproject` já guardava uma cópia de cada aba salva, mas sem garantia de estar sempre fresca nem
  nada que reconstituísse os arquivos numa máquina nova. Agora, **"Salvar projeto"/"Salvar Tudo"/
  encerrar o programa** resincronizam o projeto com o conteúdo REAL do disco de todo fonte que ele
  conhece (`ResyncProjectDocumentsFromDisk()`); **abrir um projeto** cujo arquivo esperado não existe
  (o caso normal de outra máquina) extrai o conteúdo de volta pro disco, sempre ao lado do
  `.msxproject` sendo aberto — não do caminho absoluto antigo, que só fazia sentido na máquina original
  (`RestoreMissingDocumentsToDisk()`). Escopo intencionalmente limitado a fontes de texto (BASIC/
  Assembly) — sprites/telas/sons/músicas já vivem nativamente no SQLite. Dois helpers novos em
  `ProjectDB.pbi` (`ListDocumentPaths()`/`DeleteDocument()`), testados no harness de regressão do
  módulo (`ProjectDBTestCli.pb`) junto com todos os testes existentes.
- **2026-08-10 (mesma sessão) — opções de linha de comando do msxbas2rom na tela de configuração
  (`7.33.9`)**: pedido explícito do usuário, com a lista de flags colada direto de `msxbas2rom -h` —
  nova página "Opções de compilação" em `Configurar → MSXBas2Rom...` (e `Configurar → Projeto...`, de
  graça, já que é a mesma janela): modo de compilação (ROM simples/automático/4 variantes de MegaROM,
  `-c`/`-a`/`-x`/`-6`/`-7`/`-4`/`-k`), silencioso/debug (`-q`/`-d`), caminhos de entrada/saída (`-i`/
  `-o`), geração de símbolos de depuração em 4 formatos (`-s`/`--cdb`/`--symbol`/`--omds`), gravar
  números de linha no binário (`--lin`) e inicializar projeto VSCode (`--vscode`). "Compilar ROM" passa
  a montar esses argumentos de verdade (antes só passava o `.bas`, sem nenhuma flag). Os 4 flags só-leem-
  e-saem (`-h`/`-D`/`-H`/`-v`) ficaram de propósito como botões de ação única em vez de checkbox
  persistente — teriam como travar silenciosamente o botão de compilar se esquecidos ligados.
- **2026-08-10 (mesma sessão) — fim dos temas escuros, ícones por padrão, manifesto `/XP`, codinome
  `ADEUS ESCURIDÃO` (`7.33.10`)**: pedido explícito do usuário — a interface datada continuava
  incomodando mesmo depois de `PENTE FINO`/`ADEUS WINDOWS 3.1`, e o pior visual era justamente nos
  temas escuros: `ThemedButton` só recolore botões, então checkbox/combobox/listview/scrollbar
  nativos (chrome do Windows, sem como recolorir) ficavam com contraste ruim contra fundo escuro —
  contra fundo claro o mesmo cinza nativo passa despercebido. Três mudanças, todas reaproveitando
  infraestrutura que já existia:
  - **Só temas claros**: os 5 escuros (`Graphite`/`Navy`/`Rose`/`Crimson`/`Forest`) saíram; dois temas
    novos (`Mist` "Neblina", `Linen` "Linho") entraram ao lado dos 2 originais (`Snow`/`Paper`) pra
    manter 4 opções. `Snow` vira o novo padrão. `editor_settings.json` de instalações antigas migra
    sozinho: cada ID escuro removido mapeia pro claro de "família" mais parecida (`Navy`→`Mist`,
    `Rose`→`Linen`, `Crimson`/`Forest`→`Paper`, `Graphite`/legado→`Snow`) — `EditorCfg_ThemeIsDark()`
    fica sempre `#False` em vez de excluída (2 outros arquivos ainda chamam ela pra decidir quando
    acionar as APIs de modo escuro do Windows; sem tema escuro nenhum, esse código fica
    permanentemente inerte, o que é o comportamento certo).
  - **Ícone por padrão, sem configurar nada**: os 311 `ThemedButton()` da IDE já usavam uma Nerd Font
    quando uma estava configurada, mas isso sempre foi opt-in — `IconFontName` vinha vazio por padrão
    e ninguém tropeçava na tela que ativa isso. Agora `editor/fonts/SymbolsNerdFontMono-Regular.ttf`
    (Nerd Fonts, licença SIL OFL, só os glifos de ícone — sem letras, sobra a fonte de código
    escolhida) vem empacotado junto do executável (`build.ps1 -D` copia a pasta, igual `sample/`) e é
    registrado em memória (`AddFontResourceEx`, privado ao processo) automaticamente na inicialização,
    reaproveitando a mesma função que já carregava a pasta de fontes customizadas do usuário
    (`EditorCfg_LoadCustomFonts()`, agora fatorada em `EditorCfg_LoadFontsFromFolder()` chamada duas
    vezes: pasta empacotada + pasta do usuário). Novo campo `IconsEnabled` (booleano, separado de
    `IconFontName`) faz a distinção entre "sem preferência salva" (`IconFontName=""` → usa a fonte
    embutida) e "usuário pediu pra desligar de propósito" (`IconsEnabled=#False`) — sem isso não dava
    pra represenar "não, eu realmente não quero ícone" depois que vazio passou a significar "usa o
    padrão". Combo **Fonte de ícones** ganhou a opção **"(Padrão - ícones embutidos)"** ao lado de
    **"(Nenhuma - usa texto)"** e da lista de Nerd Fonts já instaladas.
  - **Manifesto `/XP` no `build.ps1`**: flag do `pbcompiler.exe` que embute a dependência do
    `comctl32` v6 (mesmo mecanismo por trás do antigo "Windows XP visual styles") — sem ela, os
    controles nativos não-tematizáveis citados acima renderizavam no estilo antigo/sem tema mesmo no
    Windows 10/11; não muda nada nos botões (já desenhados à mão, ver acima), só o resto.
  - Investigação prévia (não implementada agora, registrada aqui pra não se perder): PureBasic 6.10+
    tem um `WebViewGadget()` nativo (Chromium/WebView2 no Windows, cross-platform) com
    `BindWebViewCallback()`/`WebViewExecuteScript()` pra IPC bidirecional com HTML/CSS/JS — daria pra
    reconstruir a apresentação em HTML mantendo toda a lógica em PureBasic, sem DLL nem processo
    separado, mas é um esforço grande (~40 arquivos `.pbi` de diálogo virariam HTML) pro ganho
    puramente visual perseguido aqui; descartado a favor das 3 mudanças acima, bem mais baratas.

## Ferramentas e ambiente

Projeto desenvolvido com:

- **[PureBasic](https://www.purebasic.com/) 6.4** — linguagem/compilador da IDE (Windows e Linux).
- **Windows** e **Ubuntu** — desenvolvido e testado nos dois sistemas.
- **PowerShell** — automação, build e scripts no ambiente Windows.
- **[Helix](https://helix-editor.com/)** — editor de texto modal usado no dia a dia de edição de
  código.
- **[Claude](https://claude.com/claude-code)** (Anthropic) — par de programação via Claude Code,
  usado para boa parte da implementação, revisão e documentação do projeto.
- **[GitHub](https://github.com/)** — versionamento e hospedagem do repositório.

## Agradecimentos

Este projeto não existiria sem o trabalho de:

- **[Fred Rique (farique1)](https://github.com/farique1)**, autor do
  [**Basic Dignified Suite**](https://github.com/farique1/basic-dignified) — o dialeto Dignified, o
  motor de pré-processamento e o tokenizador MSX-BASIC originais (em Python) foram a especificação de
  comportamento e a maior fonte de inspiração para tudo que foi reescrito nativamente aqui. O código de
  teste de regressão do projeto (`sample/teste.dmx`, "Change Graph Kit") também é obra dele.
- **[Amaury Carvalho](https://github.com/amaurycarvalho)**, autor do
  [**msxbas2rom**](https://github.com/amaurycarvalho/msxbas2rom) — compilador MSX BASIC → ROM que
  inspira o back-end de geração de ROM planejado para esta IDE.
- **Nestor Soriano ([Konamiman](https://github.com/Konamiman))**, autor do
  [**Nestor80**](https://github.com/Konamiman/Nestor80) (assembler/linker/gerenciador de biblioteca
  Z80 100% compatível com o M80/L80 da Microsoft) — especificação de comportamento e oráculo de teste
  (`N80.exe`/`LK80.exe`/`LB80.exe`, compilados localmente a partir do código-fonte C# aberto) para o
  assembler Z80 nativo desta IDE, tanto o vocabulário de syntax highlight quanto o motor de montagem em
  si (tabela de opcodes, avaliador de expressão, formato `.REL`).
- **Fuzzy Logic** (R. v/d Meulen e A. v/d Wal, Holanda), autores do **SEE (Sound Effect Editor) v3.10**
  (1991/95), editor shareware de efeitos sonoros PSG para MSX — o formato de arquivo `.SEE` e o driver de
  replay original (`SEE3PLAY.ASC`) foram a especificação de comportamento (estudada por engenharia
  reversa do driver, campo a campo) para o editor **SEE Tracker** nativo desta IDE (`Criar → SEE
  Tracker...`) e seu driver de replay Z80 embutido, uma porta própria do driver original.

## Licença

[GNU GPL v3](LICENSE).
